<?php
define('ROOT_ABSOLUTE_PATH',dirname(__FILE__));
define('JBROWSE_USERDATA_PATH','/var/www/JBrowse/JBrowse-1.11.6/data/userData/');
define('JBROWSE_RELATIVE_PATH','/JBrowse/JBrowse-1.11.6/');

define('JBROWSE_DATA_PATH','/var/www/JBrowse/JBrowse-1.11.6/data/');

define('JBROWSE_USERDATA_RELATIVE_PATH','../../JBrowse/JBrowse-1.11.6/data/userData/');

define('JBROWSE_DATA_RELATIVE_PATH','../../JBrowse/JBrowse-1.11.6/data/');

define('bowtie2db_PATH','/var/www/CRISPR-RT/bowtie2db/');

?>
