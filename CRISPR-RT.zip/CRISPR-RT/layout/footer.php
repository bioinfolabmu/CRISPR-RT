	<!-- end of main content --></div>
	<!-- This clearing element should immediately follow the #mainContent div in order to force the #container div to contain all child floats --><br class="clearfloat" />
  <div id="footer">
    <p><div align="center" class="normalfont">Copyright</a> © 2016 Liang Lab.&nbsp; &nbsp; All rights reserved.&nbsp; &nbsp;</div></p>
  <!-- end of footer --></div>
<!-- end of main container --></div>
</body>
</html>
