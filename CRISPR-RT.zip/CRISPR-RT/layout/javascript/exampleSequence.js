function inputexamplesequence()
{
    	 //Total Number of Sequences in SequenceArray
	    var NUMBER_OF_SEQUENCES=11;
	 
	  
	    var sequenceArray=[
                              ">AT1G01270.1 TAIR10.33\nGGUUCCAUGGUCUAGCGGUUAGGACACUAGACUCUGAAUCUAGUAACCCGAGUUCAAGUCUCGGUGGAACCU",
                              ">ENST00000408492 GRCh38.86\nGUUGUGCUGUCCAGGUGCUGGAUCAGUGGUUCGAGUCUGAGCCUUUAAAAGCCACUCUAGCCACAGAUGCAGUGAUUGGAGCCAUGACAA",
                              ">ENSMUST00000083060 GRCm38.86\nCUGCAGCCAAUUAAGCCGACCAGGUUCCUUUCCUCAUAGGAGUCUGGUGUGCAAUGGUUGCAAACAGCAUCCUCCUUGCUAGUGUAUGCAGCCUGCUGAAUGUGCAGGCUGCCCAAAGGGACCUUGGAGACAGUC",
                              ">ENSGALT00000029021 Gallus_gallus-5.0.86\nCUGUGGUCUGGCUCUGUGUGGAAGACUAGUGAUUUUGUUGUUAUGAUUUAUAAAGGUGACAACAAAUCAUAGCCUGCCAUACAGCACAGAUCUUC",
                              ">ENSDART00000118660 GRCz10.86\nCGCUGCAGGCUGAGGUAGUUGGUUGUAUGGUUUUGCAUCAUAAUCAGCCUGGAGUUAACUGUACAACCUUCUAGCUUUCCCUGCGGUG",
                              ">ENSFCAT00000022289 Felis_catus_6.2.86\nAUGUGUAUAUAUGUGUGUAUAUAUAUAUAUAUAUAUAUAUAUAUAUAUAUACACACACACACACACACGUGUGUAUGUAUAUACA",
                              ">EPlOSAT00000001531 IRGSP-1.0.33\nGUUGAGAUGGCCGAGUUGGUCUAAGGCGCCAGAUUAAGGUUCUGGUCCGAAAGGGCGUGGGUUCAAAUCCCACUCUCAACA",
                              ">FBtr0085637 BDGP6.86\nGGCAGCGUGGCCGAGCGGUCUAAGGCGCUGGUUUUAGGCACCAGUCCGAAAGGGCGUGGGUUCGAAUCCCACCGCUGUCA",
                              ">R06C1.12 WBcel235.86\nAAGCCUCAGCCUAAGCCUGAGCUUGAGCCUAAGCCUAAGCCGAAGCUUAAGCUUAAGCCUAAGCCUAAGCCUA",
                              ">Zm00001d002355_T001 AGPv4.33\nGGGGGUGUAGCUCAUAUGGUAGAGCGCUCGCUUCGCAUGCGAGAGGCACGGGGUUCGAUUCCCCGCACCUCCA",
                              ">AT1G02490.1 TAIR10_phytozome\nAUGGAGAUGAUGAUGUUAACUGGAACAGAGGCAGCAGUAAUUGAUGAUCUAACAGACAUUGACAUCAGGCAACCAAUCCUAGUCUGCGUGUGGGAGAUAGAAGCGGCCUGGUUAUGA"
                              
                               ];

	    var sequence = document.getElementById("sequence");
		
            var n = Math.floor((Math.random() * NUMBER_OF_SEQUENCES));
		
            console.log(n)
            sequence.value=sequenceArray[n];

            var db = document.getElementById("db");
            
            if (n == 0) {
               db.value="TAIR10.33";
            }else if (n == 1) {
               db.value="GRCh38.86";
            }else if (n == 2) {
               db.value="GRCm38.86";
            }else if (n == 3) {
               db.value="Gallus_gallus-5.0.86";
            }else if (n == 4) {
               db.value="GRCz10.86";
            }else if (n == 5) {
               db.value="Felis_catus_6.2.86";
            }else if (n == 6) {
               db.value="IRGSP-1.0.33";
            }else if (n == 7) {
               db.value="BDGP6.86";
            }else if (n == 8) {
               db.value="WBcel235.86";
            }else if (n == 9) {
               db.value="AGPv4.33";
            }else if (n == 10) {
               db.value="TAIR10_phytozome";
            }


} 

