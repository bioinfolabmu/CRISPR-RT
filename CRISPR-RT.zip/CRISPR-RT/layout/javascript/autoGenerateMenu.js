dojo.require("dojo.parser");
dojo.require("dijit.Menu");

/*
 * autoGenerates HTML for menuObject
 * @return HTML generated.
 */
function generateHTML() {
		var html="";
		html+='<li id="'+this.linkName+'"><a href="'+this.linkPath+'">'+this.displayName+"</a>\n";
		if(this.subMenu!=null){
			html+='<ul>\n';

		for(var i=0;i<this.subMenu.length;i++) {
			html+=this.subMenu[i].generateHTML();
		console.log(this.subMenu.length);
		}
			html+='</ul>\n';

		}
		html+='</li>';
		console.log(html);
	return html;
}
function generateLinkAndBreadCrumbs(){
	//console.log("making bread crumbs");
	var currentLocation=document.URL;
	//currentLocation=currentLocation.replace(projectURL, "");
	currentLocation=currentLocation.substring(currentLocation.lastIndexOf("/"));
	var splitLocation=currentLocation.split("/");
	var breadCrumbs="";
	currentLocation="";
	for(var i=0;i<splitLocation.length;i++){
					if(splitLocation[i].indexOf(".php")<0){
						currentLocation+=splitLocation[i]+"/";
					}
					else{
						currentLocation+=splitLocation[i];

					}
				}

	//console.log("currentLocation: "+currentLocation+" "+this.linkPath);
	if(this.linkPath.indexOf(currentLocation)>0&&currentLocation!="/"){
		//console.log(this.linkName);
		var obj=document.getElementById(this.linkName);
		//console.log("obj: "+obj);
		obj.style.background= '#CCCCCC';
		document.getElementById("breadCrumbs").innerHTML="<strong>"+this.displayName+"</strong>";
		return this.displayName;
	}else{
		if(this.subMenu!=null){
			//console.log("has sub menu");
			for(var i=0;i<this.subMenu.length;i++){
					tempBread=this.subMenu[i].generateLinkAndBreadCrumbs();
					if(tempBread!=null){
							//console.log(this.subMenu[i].displayName);
							var obj=document.getElementById(this.linkName);
							obj.style.background= '#CCCCCC';
				    		document.getElementById("breadCrumbs").innerHTML="<strong>"+this.displayName+" :: "+tempBread+"</strong>";
							return this.displayName+" :: "+tempBread;
					}
				
				
			}
		}
	}
	return null;
	

}
/*
 * MenuObject
 * @param linkName string name of link
 * @param linkPath string path of link
 * @param submenu array array of menuObjects
 */
function menuObject(linkName,displayName, linkPath, submenu) {
	this.linkName=linkName;
	this.displayName=displayName;
	this.linkPath=linkPath;
	this.subMenu=submenu;
	this.generateHTML=generateHTML;
	this.generateLinkAndBreadCrumbs=generateLinkAndBreadCrumbs;
}
