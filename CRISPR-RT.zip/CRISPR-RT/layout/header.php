<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>CRISPR-RT</title>
	<link href="<?php echo ROOT_PATH.'/layout/css/main.css'?>" rel="stylesheet" type="text/css">
	<link href="<?php echo ROOT_PATH.'/layout/css/menu.css'?>" rel="stylesheet" type="text/css">
	<script type="text/javascript" src="<?php echo ROOT_PATH ?>/layout/javascript/autoGenerateMenu.js"> </script>
	<script type="text/javascript" src="<?php echo ROOT_PATH ?>/layout/javascript/exampleSequence.js"> </script>
</head>
<body class="twoColFixLtHdr claro">
	<div id="container">
		<div id="header">
			<div id="mainImage">
				<img src="<?php echo ROOT_PATH .'/layout/images/header_banner.png'?>" width="1200px" height="160px">
			</div>
			<!-- end of header-->
		</div>
		<div id="sidebar1">
			<br>
			<ul>
			<script type="text/javascript">
				var projectURL="<?php echo ROOT_PATH ?>";
				//Contains the the items to be displayed in the menu.
				var menu =[new menuObject("home", "Home", projectURL+"/index.php", null),             
                                
				new menuObject("c2c2", "C2c2", projectURL+"/interface/C2c2.php", null),

                                new menuObject("retrieve", "Retrieve Jobs", projectURL+"/interface/Jobs.php", null),
				new menuObject("installation", "Installation", projectURL+"/interface/Installation.php", null),
                                new menuObject("help", "Help", projectURL+"/interface/Help.php", null),

                                new menuObject("contact", "Contact", projectURL+"/interface/Contact.php", null)
				];
				for(var i = 0; i < menu.length; i++) {
					document.writeln(menu[i].generateHTML());
				}
			</script>
			</ul>
			<!--end of Menu -->
		</div>
		<div id="mainContent" class="claro">
			
