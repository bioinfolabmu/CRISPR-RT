
<?php 
define('ROOT_PATH','.');
include("layout/header.php"); 

?>
<br/>
<strong style="color:#763ca5"><h1>RNA-Targeting Prediction and Visualization with the CRISPR System</h1></strong>
<br/>
<font size="3">CRISPR-RT is a web service that allows a user to upload an RNA sequence, set specifications according to experimental goals, and recieve target candidates for the CRISPR System. Optimal candidates are suggested through consideration of predicted off-target effects. A visualization of on- and off-target matches against the chosen reference transcriptome is provided in JBrowse.<br/><br/>



<?php include("layout/footer.php"); ?>
