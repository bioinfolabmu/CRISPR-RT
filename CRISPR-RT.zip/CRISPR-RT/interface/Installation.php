<?php 
define('ROOT_PATH','..');
include ROOT_PATH."/layout/header.php"; 
?>


<html>

<head>
  <meta charset='utf-8'>
  <meta name='Description' content='This manual outlines the installation process if you wish to install CRISPR-RT locally.'>
  <title>CRISPR-RT | Installation manual</title>
  <!--<link rel='shortcut icon' href='../static/images/favicon.ico'>
  <link rel=stylesheet href='../static/css/gt-scan.css'>
  <script src='../static/js/jquery.min.js'></script>
  <script src='../static/js/menu.js'></script>
  <script>var online = true;</script>-->
</head>

<body>

<!-- Main content -->
    <div id=main>
<div id=documentation>
    <h1 id=top>Installation manual</h1>
    <h3>Table of contents:</h3>
    <ul>
      
      <li><a href=#intro>Introduction</a>
      
      
         <li><a href=#prereqs>Prerequisite</a>
         <li><a href=#install>Install CT-Finder</a>
         <li><a href=#add_transcriptome>Add reference transcriptomes</a>
      
    </ul>
    <hr>
    
    
    <h2 id=intro>Introduction</h2>
    <p>CRISPR-RT is a web service that allows a user to upload an RNA sequence, set specifications according to experimental goals, and recieve target candidates for the CRISPR System. Optimal candidates are suggested through consideration of predicted off-target effects. A visualization of on- and off-target matches against the chosen reference transcriptome is provided in JBrowse. </p>

    

    
    <h2 id=prereqs>Prerequisite</h2>
    
     <ul>
      <li>Linux System (<a href=http://www.ubuntu.com/ target=_blank>Ubuntu 14.04.2</a> was used for this manual)
      
     

     </ul>

      <ul><li><a href=https://httpd.apache.org/ target=_blank>Apache</a> (version: 2.4.7)<br>
     After installing, Type <p style="color: #2B1B17; background-color: #FBF6D9;display:inline;">/usr/sbin/apache2 -v</p> into the command line to find out which version.
     </ul>

     <ul><li><a href=http://www.perl.org/ target=_blank>Perl</a> (version: 5.18.2)<br>
     You most likely already have perl installed. Type <p style="color: #2B1B17; background-color: #FBF6D9;display:inline;">perl -v</p> into the command line to find out which version.
     </ul>

     <ul><li><a href=https://www.php.net/ target=_blank>PHP</a> (version: 5.5.9)<br>
         <ul><li><p style="color: #2B1B17; background-color: #FBF6D9;display:inline;">sudo apt-get install libapache2-mod-php5</p>
 
         </ul>

         <ul><li><p style="color: #2B1B17; background-color: #FBF6D9;display:inline;">sudo a2enmod php5</p>
 
         </ul>

         <ul><li><p style="color: #2B1B17; background-color: #FBF6D9;display:inline;">sudo service apache2 restart</p>
 
         </ul>
     </ul>

     

     <ul><li><a href=http://bowtie-bio.sourceforge.net/bowtie2/index.shtml target=_blank>Bowtie2</a> (version: 2.2.6)<br>
         <ul><li><a href=http://bowtie-bio.sourceforge.net/bowtie2/manual.shtml#building-from-source target=_blank>Building from source</a>
 
         </ul>
         <ul><li><a href=http://bowtie-bio.sourceforge.net/bowtie2/manual.shtml#adding-to-path target=_blank>Adding to PATH</a>
 
         </ul>
     
     After installing, Type <p style="color: #2B1B17; background-color: #FBF6D9;display:inline;">bowtie2</p> into the command line to check if you have installed bowtie2 successfully.
     </ul>

     <ul><li><a href=http://www.htslib.org/download/ target=_blank>Samtools</a> (version: 1.2)<br>
     After building and installing, don't forget to add the installing directory to your $PATH with the command <p style="color: #2B1B17; background-color: #FBF6D9;display:inline;">export PATH=/where/to/install/bin:$PATH</p>. <br>Type <p style="color: #2B1B17; background-color: #FBF6D9;display:inline;">samtools</p> into the command line to check if you have installed samtools successfully.
     </ul>

     <ul><li><a href=https://deweylab.github.io/RSEM/ target=_blank>RSEM</a> <br>
     
     </ul>

     <ul><li><a href=http://jbrowse.org/ target=_blank>JBrowse</a> (version: 1.11.6)<br>
     Setting up:<br>
         <ul><li>Create a folder called “JBrowse”  by the following commands under the root directory of the apache server (may be found at, for example, /var/www/ on Debian or Ubuntu systems, /var/www/html on Red Hat, Fedora, or SUSE. /var/www is used as an example in this guide). Enter the following commands into the command line: <br>
       <p style="color: #2B1B17; background-color: #FBF6D9;display:inline;">sudo chmod o+w /var/www</p> <br>
       <p style="color: #2B1B17; background-color: #FBF6D9;display:inline;">cd /var/www</p> <br>

       <p style="color: #2B1B17; background-color: #FBF6D9;display:inline;">mkdir JBrowse</p> <br>
 
         </ul>

         <ul><li>After downloading <a href=http://jbrowse.org/wordpress/wp-content/plugins/download-monitor/download.php?id=99 target=_blank>JBrowse-1.11.6.zip</a>, put the unzipped folder “JBrowse-1.11.6” into /var/www/JBrowse. 
 
         </ul>

         <ul><li>Enter the following commands into the command line:<br>
            <p style="color: #2B1B17; background-color: #FBF6D9;display:inline;">cd /var/www/JBrowse/JBrowse-1.11.6</p> <br>
            <p style="color: #2B1B17; background-color: #FBF6D9;display:inline;">./setup.sh</p> <br>
  
         </ul>
         
         <ul><li>If you are not able to install JBrowse successfully, you may try deleting the .cpanm file under your account using the following commands:<br>
            <p style="color: #2B1B17; background-color: #FBF6D9;display:inline;">cd /home/username</p> <br>
            <p style="color: #2B1B17; background-color: #FBF6D9;display:inline;">sudo rm -Rf .cpanm</p> <br>
            <p style="color: #2B1B17; background-color: #FBF6D9;display:inline;">cd /var/www/JBrowse/JBrowse-1.11.6</p> <br>
            <p style="color: #2B1B17; background-color: #FBF6D9;display:inline;">./setup.sh</p> <br>
  
         </ul>

         <ul><li>Create a folder called “data” under /var/www/JBrowse/JBrowse-1.11.6
 
         </ul>

         <ul><li>Create a folder called “userData” under /var/www/JBrowse/JBrowse-1.11.6/data. 
 
         </ul>
         
          
         <ul><li>Enter the following commands into the command line:<br>
            <p style="color: #2B1B17; background-color: #FBF6D9;display:inline;">cd /var/www/JBrowse/JBrowse-1.11.6/data/</p> <br>
            <p style="color: #2B1B17; background-color: #FBF6D9;display:inline;">sudo chgrp www-data userData/</p> <br>
            <p style="color: #2B1B17; background-color: #FBF6D9;display:inline;">sudo chmod g+rwx userData/</p> <br>
            <p style="color: #2B1B17; background-color: #FBF6D9;display:inline;">sudo chmod o-w /var/www</p> <br>
  
         </ul>

     </ul>

    




    <h2 id=install>Install CT-Finder</h2>
    
      <ul>
        
        <li>Download <a href=https://sourceforge.net/projects/crispr-rt/files/latest/download?source=files target=_blank>CRISPR-RT</a> and unzip it. Put it into the root directory of the apache server (e.g. /var/www/ on Debian or Ubuntu systems, /var/www/html on Red Hat, Fedora, or SUSE. /var/www/ is used as an example in this guide).
        
       <li>Go to /var/www/ct-finder/ folder to edit “root_path.php” file. Open it and Configure the following parameters to reflect the actual location paths in your setup:
         <ul><li>JBROWSE_USERDATA_PATH: set the absolute path for folder “userData” in JBrowse.
         </ul>
          <ul><li>JBROWSE_RELATIVE_PATH: set the relative path for folder “JBrowse-1.11.6” in JBrowse. Here it is relative to /var/www/ (the default apache root directory).
         </ul>
         <ul><li>JBROWSE_DATA_PATH: set the absolute path for folder “Data” in JBrowse.
         </ul>
         <ul><li>JBROWSE_USERDATA_RELATIVE_PATH: set the relative path for folder “userData” in JBrowse. Here it is relative to /var/www/ct-finder/proc/.
         </ul>
         <ul><li>JBROWSE_DATA_RELATIVE_PATH: set the relative path for folder “data” in JBrowse. Here it is relative to /var/www/ct-finder/proc/.
         </ul>
         <ul><li>bowtie2db_PATH: set the absolute path for folder “bowtie2db” in CRISPR-RT.
         </ul>

         </ul>
         
 
         


      </ul>
    
    
    
    <h2 id=add_transcriptome>Add reference transcriptomes</h2>
<ul>
<li>Add a reference transcriptome from <a href=ftp://ftp.ensemblgenomes.org/pub/plants/release-27/gff3/arabidopsis_thaliana/ target=_blank>Ensembl</a>. TAIR10 will be used as the example reference in this manual. Change names of folders and files as appropriate for the reference transcriptome you are using.

    <ul><li>Create a folder named according to the genome name that you want to add under /var/www/ct-finder/bowtie2db/. E.g. “TAIR10.33” under /var/www/ct-finder/bowtie2db/.</ul>
    <ul><li>Download the TAIR10.33 genome (or any reference genome) from <a href=ftp://ftp.ensemblgenomes.org/pub/plants/release-27/fasta/arabidopsis_thaliana/dna/ target=_blank>Ensembl</a>. Download each chromosome separately, and then unzip them and put into the appropriate reference genome folder, e.g. /var/www/CRISPR-RT/bowtie2db/TAIR10.33 (Note: only unzipped chromosome files should be put in the /var/www/CRISPR-RT/bowtie2db/TAIR10.33 folder).</ul>
    <ul><li>Download the TAIR10.33 (or other reference genome) gtf file from <a href=ftp://ftp.ensemblgenomes.org/pub/plants/release-27/gff3/arabidopsis_thaliana/ target=_blank>Ensembl</a>. Unzip and rename it to “TAIR10.33.gtf” and put the file into /var/www/CRISPR-RT/bowtie2db/TAIR10.33</ul>
    <ul><li>Concatenate the genome into a single FASTA file. Model your commands after the following example:<br> <p style="color: #2B1B17; background-color: #FBF6D9;display:inline;">cd /var/www/CRISPR-RT/bowtie2db/TAIR10.33</p> <br>
            <p style="color: #2B1B17; background-color: #FBF6D9;display:inline;">cat *.fa > TAIR10.33.fa</p> <br></ul>
    <ul><li>Copy "gtf2gff3.pl" and "transcriptID.pl" in the "tools" folder of CRISPR-RT into /var/www/CRISPR-RT/bowtie2db/TAIR10.33</ul>
    <ul><li>Create a chromosome list file "chr_list.txt" in the /var/www/CRISPR-RT/bowtie2db/TAIR10.33 folder according to the example list format in the "example" folder of CRISPR-RT</ul>
    <ul><li>Go to the /var/www/CRISPR-RT/bowtie2db/TAIR10.33 folder in command line <p style="color: #2B1B17; background-color: #FBF6D9;display:inline;">cd /var/www/CRISPR-RT/bowtie2db/TAIR10.33</p></ul>
    <ul><li>Enter <p style="color: #2B1B17; background-color: #FBF6D9;display:inline;">perl gtf2gff3.pl TAIR10.33.gtf chr_list.txt > TAIR10.33.gff3</p> to generate TAIR10.33.gff3 for JBrowse</ul>
    <ul><li>Enter <p style="color: #2B1B17; background-color: #FBF6D9;display:inline;">perl transcriptID.pl TAIR10.33.gtf</p> to generate the transcript, gene ID and Name of TAIR10.33 which are stored in the "TranscriptID.txt" file</ul>
    <ul><li>Enter <p style="color: #2B1B17; background-color: #FBF6D9;display:inline;">rsem-prepare-reference --gtf TAIR10.33.gtf TAIR10.33.fa TAIR10.33</p> to get the TAIR10.33 transcripts file "TAIR10.33.transcripts.fa"</ul>
    <ul><li>Enter <p style="color: #2B1B17; background-color: #FBF6D9;display:inline;">bowtie2-build TAIR10.33.transcripts.fa TAIR10.33.transcripts</p> to build the transprits biowtie2 index</ul>
    <ul><li>Create a folder called “TAIR10.33” under /var/www/JBrowse/JBrowse-1.11.6/data. Then create two folders - “genome” and “gff” - under the reference genome folder (/var/www/JBrowse/JBrowse-1.11.6/data/TAIR10.33).</ul>
    <ul><li>Copy "TAIR10.33.fa" from /var/www/CRISPR-RT/bowtie2db/TAIR10.33 to /var/www/JBrowse/JBrowse-1.11.6/data/TAIR10.33/genome</ul>
    <ul><li>Copy "TAIR10.33.gff3" from /var/www/CRISPR-RT/bowtie2db/TAIR10.33 to /var/www/JBrowse/JBrowse-1.11.6/data/TAIR10.33/gff</ul>
    <ul><li>Configure JBrowse with your reference genome. Model your commands after the following example:<br>
            <p style="color: #2B1B17; background-color: #FBF6D9;display:inline;">cd /var/www/JBrowse/JBrowse-1.11.6</p> <br>
            <p style="color: #2B1B17; background-color: #FBF6D9;display:inline;">./bin/prepare-refseqs.pl --fasta data/TAIR10.33/genome/TAIR10.33.fa --out data/TAIR10.33/</p> <br>
            <p style="color: #2B1B17; background-color: #FBF6D9;display:inline;">./bin/flatfile-to-json.pl --gff data/TAIR10.33/gff/TAIR10.33.gff3 --type mRNA --trackLabel Transcript --out data/TAIR10.33</p> <br></ul>
    <ul><li>Access <a href=http://localhost/JBrowse/JBrowse-1.11.6/?data=data/TAIR10.33 target=_blank>http://localhost/JBrowse/JBrowse-1.11.6/?data=data/TAIR10.33</a> to check that you have sucessfully added TAIR10.33 genome to JBrowse</ul>
    <ul><li>Go to /var/www/ct-finder/interface folder to edit the file “C2c2.php”. Open “C2c2.php”, and then add one line of code <br>“<code>&lt;option value=TAIR10.33 &gt;Ensembl Thale cress (Arabidopsis thaliana) transcriptome TAIR10.33&lt;/option&gt;</code>” <br> below “<code>&lt;option value=none&gt;Choose an organism&lt;/option&gt;</code>” (Note: the "TAIR10.33" in "value=TAIR10.33" is the name of your reference transcriptome folder).</ul>
    <ul><li>Go to /var/www/CRISPR-RT/bowtie2db/ in command line <p style="color: #2B1B17; background-color: #FBF6D9;display:inline;">cd /var/www/CRISPR-RT/bowtie2db/</p></ul>
    <ul><li>Enter <p style="color: #2B1B17; background-color: #FBF6D9;display:inline;">sudo chmod a+rwx -R TAIR10.33</p> to change the access permissions of the "TAIR10.33" folder </ul>

    <li>Add a reference transcriptome from <a href=https://phytozome.jgi.doe.gov/pz/portal.html target=_blank>Phytozome</a>. TAIR10 will be used as the example reference in this manual. Change names of folders and files as appropriate for the reference transcriptome you are using.

    <ul><li>Create a folder named according to the genome name that you want to add under /var/www/ct-finder/bowtie2db/. E.g. “TAIR10_phytozome” under /var/www/ct-finder/bowtie2db/. (Note: the folder name must be ending with "_phytozome")</ul>

    <ul><li>Download the TAIR10_phytozome genome (or any reference genome) from <a href=https://phytozome.jgi.doe.gov/pz/portal.html target=_blank>Phytozome</a> to /var/www/CRISPR-RT/bowtie2db/TAIR10_phytozome and Unzip it and rename it to TAIR10_phytozome.fa.</ul>

    <ul><li>Download the TAIR10_phytozome (or other reference genome) gff3 file from <a href=https://phytozome.jgi.doe.gov/pz/portal.html target=_blank>Phytozome</a>. Unzip and rename it to “TAIR10_phytozome.gff3” and put the file into /var/www/CRISPR-RT/bowtie2db/TAIR10_phytozome</ul>
    
    <ul><li>Copy "transcriptID_phytozome.pl" in the "tools" folder of CRISPR-RT into /var/www/CRISPR-RT/bowtie2db/TAIR10_phytozome</ul>

    <ul><li>Go to the /var/www/CRISPR-RT/bowtie2db/TAIR10_phytozome folder in command line <p style="color: #2B1B17; background-color: #FBF6D9;display:inline;">cd /var/www/CRISPR-RT/bowtie2db/TAIR10_phytozome</p></ul>
    
    <ul><li>Enter <p style="color: #2B1B17; background-color: #FBF6D9;display:inline;">perl transcriptID_phytozome.pl TAIR10_phytozome.gtf</p> to generate the transcript, gene ID and Name of TAIR10_phytozome which are stored in the "TranscriptID.txt" file</ul>

    <ul><li>Enter <p style="color: #2B1B17; background-color: #FBF6D9;display:inline;">rsem-prepare-reference --gff3 TAIR10_phytozome.gff3 TAIR10_phytozome.fa TAIR10_phytozome</p> to get the TAIR10_phytozome transcripts file "TAIR10_phytozome.transcripts.fa"</ul>

    <ul><li>Enter <p style="color: #2B1B17; background-color: #FBF6D9;display:inline;">bowtie2-build TAIR10_phytozome.transcripts.fa TAIR10_phytozome.transcripts</p> to build the transprits biowtie2 index</ul>

    <ul><li>Create a folder called “TAIR10_phytozome” under /var/www/JBrowse/JBrowse-1.11.6/data. Then create two folders - “genome” and “gff” - under the reference genome folder (/var/www/JBrowse/JBrowse-1.11.6/data/TAIR10_phytozome).</ul>

    <ul><li>Copy "TAIR10_phytozome.fa" from /var/www/CRISPR-RT/bowtie2db/TAIR10_phytozome to /var/www/JBrowse/JBrowse-1.11.6/data/TAIR10_phytozome/genome</ul>

    <ul><li>Copy "TAIR10_phytozome.gff3" from /var/www/CRISPR-RT/bowtie2db/TAIR10_phytozome to /var/www/JBrowse/JBrowse-1.11.6/data/TAIR10_phytozome/gff</ul>

    <ul><li>Configure JBrowse with your reference genome. Model your commands after the following example:<br>
            <p style="color: #2B1B17; background-color: #FBF6D9;display:inline;">cd /var/www/JBrowse/JBrowse-1.11.6</p> <br>
            <p style="color: #2B1B17; background-color: #FBF6D9;display:inline;">./bin/prepare-refseqs.pl --fasta data/TAIR10_phytozome/genome/TAIR10_phytozome.fa --out data/TAIR10_phytozome/</p> <br>
            <p style="color: #2B1B17; background-color: #FBF6D9;display:inline;">./bin/flatfile-to-json.pl --gff data/TAIR10_phytozome/gff/TAIR10_phytozome.gff3 --type mRNA --trackLabel Transcript --out data/TAIR10_phytozome</p> <br></ul>

    <ul><li>Access <a href=http://localhost/JBrowse/JBrowse-1.11.6/?data=data/TAIR10_phytozome target=_blank>http://localhost/JBrowse/JBrowse-1.11.6/?data=data/TAIR10_phytozome</a> to check that you have sucessfully added TAIR10_phytozome genome to JBrowse</ul>

    <ul><li>Go to /var/www/ct-finder/interface folder to edit the file “C2c2.php”. Open “C2c2.php”, and then add one line of code <br>“<code>&lt;option value=TAIR10_phytozome &gt;Phytozome Thale cress (Arabidopsis thaliana) transcriptome TAIR10_phytozome&lt;/option&gt;</code>” <br> below “<code>&lt;option value=none&gt;Choose an organism&lt;/option&gt;</code>” (Note: the "TAIR10_phytozome" in "value=TAIR10_phytozome" is the name of your reference transcriptome folder).</ul>

    <ul><li>Go to /var/www/CRISPR-RT/bowtie2db/ in command line <p style="color: #2B1B17; background-color: #FBF6D9;display:inline;">cd /var/www/CRISPR-RT/bowtie2db/</p></ul>
    <ul><li>Enter <p style="color: #2B1B17; background-color: #FBF6D9;display:inline;">sudo chmod a+rwx -R TAIR10_phytozome</p> to change the access permissions of the "TAIR10_phytozome" folder </ul>   
         
         
         




    
  
  
</div>
<br>
</div>

</body>
</html>

<?php 
include ROOT_PATH."/layout/footer.php"; 
?>
