<!DOCTYPE html>
<html>
  <head lang="en">
  <meta charset="UTF-8">
  <script language="JavaScript">

    function converter() {
       
        var cDNA = document.getElementById("cDNA").value;
        
        if(cDNA.match(/\>/g)){
          alert("Please enter only sequence, not fasta format");
          return;
        }

        var cDNA_array = cDNA.split('\n');
        var new_cDNA = cDNA_array.join('');
        
        new_cDNA = new_cDNA.toUpperCase(); 
        
        var RNA ='';

        var new_cDNA_array = new_cDNA.split('');

        var array_length = new_cDNA_array.length;

        for (i = 0; i < array_length; i++) {
            if (new_cDNA_array[i] == 'A'){
               RNA = RNA + 'A'; 

            } else if (new_cDNA_array[i] == 'T'){
               RNA = RNA + 'U';

            } else if (new_cDNA_array[i] == 'G'){
               RNA = RNA + 'G';

            } else if (new_cDNA_array[i] == 'C'){
               RNA = RNA + 'C';

            } else {
               RNA = RNA + new_cDNA_array[i];

            }
        }


         //RNA =  RNA.split("").reverse().join("");

        document.getElementById('RNA').value = RNA;
        document.getElementById('RNA_seq').style.display = "block";
        
    }
  </script>

  </head>
  <body>

    <form>
      <label>Enter a cDNA sequence:</label><br>
      <textarea id=cDNA name=cDNA rows=15 cols=90></textarea>
    </form>
    <br>
    <button type="button" onclick="converter()">cDNAtoRNA</button>
    
    <br><br>
    <div id = RNA_seq  style="display:none">
    <label>RNA sequence: </label><br>
    <textarea id=RNA name=RNA rows=15 cols=90></textarea>
    </div>
  </body>
</html>
