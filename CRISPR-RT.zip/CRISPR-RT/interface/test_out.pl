#! /usr/bin/perl
system ("perl ../proc/test_final.pl")
#print "hello";
