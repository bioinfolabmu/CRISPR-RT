<?php 
define('ROOT_PATH','..');
include ROOT_PATH."/layout/header.php";
?>


<form name=CRISPR-RT method=POST action='../proc/uploader.php' enctype='multipart/form-data' onsubmit="return myFunction()">
<b><p style="font-size:249%; color:#3f3f3f">CRISPR-C2c2 System</p></b>

	
<h2><font color='#763ca5'>Step 1: Provide an RNA sequence to target</font></h2>
	<p style="display:inline">Input an RNA sequence in FASTA format:
     <span class=helper title="
     Paste a single RNA sequence in FASTA format or convert a cDNA sequence and paste it into the text field (standard RNA characters only: A, C, U, G). CRISPR-RT will find target candidates within this sequence.
     ">?</span></p>
     
     
     <a href="cDNAtoRNA.php" target="_blank">(cDNA?)</a>

     <p style="padding-left:337px; display:inline">
     <input name="Example" class=examplebutton type="button" value="Example Sequence"
                onClick="inputexamplesequence()"/><br>
    </p>
	<textarea id=sequence name=userseq rows=15 cols=90 class=mono></textarea>
	
<h2><font color='#763ca5'>Step 2: Choose the reference transcriptome</font></h2>
	<p>Reference transcriptome:
	<select id=db name=db>
	<option value=none>Choose an organism</option>
        
        <option value=TAIR10.32 >Thale cress (Arabidopsis thaliana) transcriptome TAIR10.32 Ensembl</option>
        <option value=GRCh38.86>Human (Homo sapiens) transcriptome GRCh38.86 Ensembl</option>
        <option value=GRCm38.86>Mouse (Mus musculus) transcriptome GRCm38.86 Ensembl</option>
        <option value=Gallus_gallus-5.0.86>Chicken (Gallus gallus) transcriptome Gallus_gallus-5.0.86 Ensembl</option>
        <option value=GRCz10.86>Zebrafish (Danio rerio) transcriptome GRCz10.86 Ensembl</option>
        <option value=Felis_catus_6.2.86>Domestic cat (Felis catus) transcriptome Felis_catus_6.2.86 Ensembl</option>
        <option value=IRGSP-1.0.33>Rice (Oryza sativa) transcriptome IRGSP-1.0.33 Ensembl</option>
        <option value=BDGP6.86>Fruit fly (Drosophila melanogaster) transcriptome BDGP6.86 Ensembl</option>
        <option value=WBcel235.86>Roundworm (Caenorhabditis elegans) transcriptome WBcel235.86 Ensembl</option>
        <option value=AGPv4.33>Zea mays (Zea mays) transcriptome AGPv4.33 Ensembl</option>
        <!--<option value=ASM242v1.27>Moss (Physcomitrella patens) genome</option>-->
		
		<!--<option value=R64-1-1.85>Ensembl Budding yeast (Saccharomyces cerevisiae) genome R64-1-1.85</option>-->
		<!--<option value=HIV-1.ncbi>NCBI Human immunodeficiency virus 1 (HIV-1) genome</option>-->
		<!--<option value=Rnor_6.0.81>Rat (Rattus norvegicus) genome</option>-->
		<!--<option value=C_jacchus3.2.1.81>Marmoset (Callithrix jacchus) genome</option>-->
		<!--<option value=Sscrofa10.2.81>Pig (Sus scrofa) genome</option>-->
		
		<!--<option value=JGI_4.2.81>Frog (Xenopus tropicalis) genome</option>-->
		<!--<option value=Xenla7>Frog (Xenopus laevis) genome, JGI 7.1/Xenla7 (Dec, 2013)</option> -->
		<!--<option value=GRCz10.81>Zebrafish (Danio rerio) genome</option>-->
		<!--<option value=KH.81>Sea squirt (Ciona intestinalis) genome</option>-->
		
		
		
		<!--<option value=Sorbi1.27>Sorghum (Sorghum bicolor) genome</option>-->
		<!--<option value=bmor1  >Silkworm (Bombyx mori) genome</option>-->
		
		<!--<option value=pombe  >Fission yeast (Schizosaccharomyces pombe) (972h-) genome, ASM294v2 (Nov, 2007)</option>-->
		<!--<option value=CanFam3.1.81>Domestic dog (Canis familiaris) genome</option>-->
		<!--<option value=cavPor3.81>Guinea pig (Cavia procellus) genome</option>-->
		
		<!--<option value=Oar_v3.1.81>Sheep (Ovis aries) genome</option>-->
		<!--<option value=CHIMP2.1.4.81>Chimpanzee (Pan troglodytes) genome</option>-->
                
	</select> 
	<span class=helper title="
     This is the organism you wish to perform transcriptome editing on. A selection of model organisms is available; if your organism is not listed here, contact us so we may add it to the database.
     ">?</span><a href="add_transcriptome.php" target="_blank">(others?)</a><br/>
      
	</p>


<h2><font color='#763ca5'>Step 3: Describe the PFS and crRNA requirements</font></h2>
	<p style="display:inline">PFS sequence
	<span class=helper title="
     The PFS sequence is adjacent to the protospacer target at the 3' end of the protospacer which is required for C2c2 targeting. The PFS affects the efficacy of C2c2 targeting. The default is H on-target PFS sequence and H off-target PFS sequcnce. H stands for A, C, or U.
     ">?</span><br/><br/>
	On Target:
	<input type=text id=target_pfs name=target_pfs size=10 maxlength=10
		value='H'>
	<span style='vertical-align:-0.4ex'>
	
	</span>
	Off target:
	<input type=text id=offtarget_pfs name=offtarget_pfs size=10 maxlength=10
		value='H'> (e.g. H)
	<span style='vertical-align:-0.4ex'>
	
	</span>
	</p><br/><br/>

        <p style="display:inline">Length of the target complementarity region of crRNA:
	<input type=text id=gRNA_length name=gRNA_length size=10 maxlength=2
		value='28'> <span class=helper title="
     This is the length of the target complementarity region of crRNA, which binds to a specific RNA target site. The default length here is 28 nt, but the range of permissibly effective lengths varies between 22-28 nt.
     ">?</span>
	<span style='vertical-align:-0.4ex'>
	
	</span><br/><br/>
        <p style="display:inline">Length of the seed region:
	<input type=text id=seed_length name=seed_length size=10 maxlength=2
		value='10'> 
	<span style='vertical-align:-0.4ex'>
	
	</span>
	<span class=helper title="
     The seed region is at the center of the target complementarity region of crRNA. Mutations in the seed region are expected to have dramatic effects on the activity of C2c2. The seed region is mismatch sensitive. 
     ">?</span><br/>
	</p>
        
	
<h2><font color='#763ca5'>Step 4: Choose an off-target setting</font></h2>

		<script type="text/javascript">
		function toggle(element) {
		    document.getElementById(element).style.display = (document.getElementById(element).style.display == "none") ? "" : "none";
		}
		</script>
 
        <input type="radio" name="offtarget_setting" id="offtarget_setting_General" value="General" checked="checked">&nbsp;<b>Basic settings</b>
        <a href="javascript:toggle('general_opt')">(show options)</a><br/>
      <div id="general_opt" style="display: none;">
      <p style="display:inline"><br/>&nbsp;&nbsp;&nbsp;&nbsp;Maximum total number of mismatches and gaps tolerated by off targets:
	  <input type=text id=num_MisAndGap name=num_MisAndGap size=10 maxlength=1
		value='3'> 
	  <span style='vertical-align:-0.4ex'>
	
	  </span>
	  <span class=helper title="
          Relative to the target candidate sequence, sequences with more than this number of combined mismatches and gaps will be excluded from consideration of off-target effects. Abudayyeh, O. O. et al (2016) has reported that 3 or less mismatches in an off target usually result in detectable cleavage activity, resulting in a default value of 3. Note: This value can be set up to 5. 
     ">?</span>
	  </p>

          <p style="display:inline"><br/>&nbsp;&nbsp;&nbsp;&nbsp;Maximum number of gaps tolerated by off targets:
	  <input type=text id=num_Gap name=num_Gap size=10 maxlength=1
		value='0'> 
	  <span style='vertical-align:-0.4ex'>
	
	  </span>
	  <span class=helper title="
          Relative to the target candidate sequence, sequences with more than this number of gaps will be excluded from consideration of off-target effects. Currently, there is no research about gaps, resulting in a default value of 0. 
     ">?</span><br/>
	  </p>

          <p style="display:inline">&nbsp;&nbsp;&nbsp;&nbsp;Maximum total number of mismatches and gaps in the seed region tolerated by off targets:
	  <input type=text id=num_seed_MisID name=num_seed_MisID size=10 maxlength=1
		value='1'> 
	  <span style='vertical-align:-0.4ex'>
	
	  </span>
	  <span class=helper title="
          Relative to the target candidate sequence, sequences with more than this number of combined mismatches and gaps in the seed region will be excluded from consideration of off-target effects. As a general rule, mismatches and gaps are poorly tolerated in the seed region, so this number should be low. Abudayyeh, O. O. et al (2016) has reported that single mismatches in the seed region can be fully tolerated by C2c2, but if double mismatches are located in the seed region, C2c2 is unable to cleave the single strand RNA, resulting in a default value of 1. 
     ">?</span><br/>
	  </p>
          
          <p style="display:inline">&nbsp;&nbsp;&nbsp;&nbsp;Maximum number of gaps in the seed region tolerated by off targets:
	  <input type=text id=num_seed_Gap name=num_seed_Gap size=10 maxlength=1
		value='0'> 
	  <span style='vertical-align:-0.4ex'>
	
	  </span>
	  <span class=helper title="
          Relative to the target candidate sequence, sequences with more than this number of gaps in the seed region will be excluded from consideration of off-target effects. Currently, there is no research about gaps, resulting in a default value of 0. 
     ">?</span><br/>
	  </p>

          <p style="display:inline">&nbsp;&nbsp;&nbsp;&nbsp;Maximum number of consecutive mismatches or gaps in the seed region tolerated by off targets:
	  <input type=text id=num_seed_consec name=num_seed_consec size=10 maxlength=1
		value='1'> 
	  <span style='vertical-align:-0.4ex'>
	
	  </span>
	  <span class=helper title="
          Relative to the target candidate sequence, sequences with more than this number of consecutive combined mismatches or gaps in the seed region will be excluded from consideration of off-target effects. Abudayyeh, O. O. et al (2016) has reported that single mismatches in the seed region can be fully tolerated by C2c2, but if double consecutive mismatches are located in the seed region, C2c2 is unable to cleave the single strand RNA, resulting in a default value of 1. 
     ">?</span><br/>
	  </p>


          <p style="display:inline">&nbsp;&nbsp;&nbsp;&nbsp;Maximum number of consecutive mismatches or gaps in the non-seed region tolerated by off targets:
	  <input type=text id=num_nonseed_consec name=num_nonseed_consec size=10 maxlength=1
		value='3'> 
	  <span style='vertical-align:-0.4ex'>
	
	  </span>
	  <span class=helper title="
          Relative to the target candidate sequence, sequences with more than this number of consectuive combined mismatches or gaps in the non-seed region will be excluded from consideration of off-target effects. Abudayyeh, O. O. et al (2016) has reported that C2c2 is even tolerant to triple consecutive mismatches in the non-seed region (3' or 5' ends), resulting in a default value of 3.  
     ">?</span><br/>
	  </p>


</div><br/>
        
        <input type="radio" name="offtarget_setting" id="offtarget_setting_Specific" value="Specific">&nbsp;<b>Specific settings</b>
        <a href="javascript:toggle('specific_opt')">(show options)</a>
        <div id="specific_opt" style="display: none;">
        <h4>Seed region</h4>
          <p style="display:inline">&nbsp;&nbsp;&nbsp;&nbsp;Maximum number of mismatches in the seed region tolerated by off targets:
	  <input type=text id=seed_mismatch name=seed_mismatch size=10 maxlength=1
		value=1> 
	  <span style='vertical-align:-0.4ex'>
	
	  </span>
	  	<span class=helper title="
     Relative to the target candidate sequence, sequences with more than this number of mismatches in the seed region will be excluded from consideration of off-target effects. As a general rule, mismatches are poorly tolerated in the seed region, so this number should be low. Abudayyeh, O. O. et al (2016) has reported that single mismatches in the seed region can be fully tolerated by C2c2, but if double mismatches are located in the seed region, C2c2 is unable to cleave the single strand RNA, resulting in a default value of 1. 
     ">?</span><br/>
	  </p>
          <p style="display:inline">&nbsp;&nbsp;&nbsp;&nbsp;Maximum number of insertions in the seed region tolerated by off targets:
	  <input type=text id=seed_insertion name=seed_insertion size=10 maxlength=1
		value=0> 
	  <span style='vertical-align:-0.4ex'>
	
	  </span>
	  <span class=helper title="
     Relative to the target candidate sequence, sequences with more than this number of insertions in the seed region will be excluded from consideration of off-target effects. Currently, there is no research about insertions, resulting in a default value of 0. 
     ">?</span><br/>
	  </p>
          <p style="display:inline">&nbsp;&nbsp;&nbsp;&nbsp;Maximum number of deletions in the seed region tolerated by off targets:
	  <input type=text id=seed_deletion name=seed_deletion size=10 maxlength=1
		value=0> 
	  <span style='vertical-align:-0.4ex'>
	
	  </span>
	  <span class=helper title="
     Relative to the target candidate sequence, sequences with more than this number of deletions in the seed region will be excluded from consideration of off-target effects. Currently, there is no research about deletions, resulting in a default value of 0. 
     ">?</span><br/>
	  </p>

          <p style="display:inline">&nbsp;&nbsp;&nbsp;&nbsp;Maximum number of consecutive mismatches or gaps in the seed region tolerated by off targets:
	  <input type=text id=num_seed_consec_specific name=num_seed_consec_specific size=10 maxlength=1
		value='1'> 
	  <span style='vertical-align:-0.4ex'>
	
	  </span>
	  <span class=helper title="
          Relative to the target candidate sequence, sequences with more than this number of consecutive combined mismatches or gaps in the seed region will be excluded from consideration of off-target effects. Abudayyeh, O. O. et al (2016) has reported that single mismatches in the seed region can be fully tolerated by C2c2, but if double consecutive mismatches are located in the seed region, C2c2 is unable to cleave the single strand RNA, resulting in a default value of 1. 
     ">?</span><br/>
	  </p>


	  
	  <h4>Non-seed region</h4>
          <p style="display:inline">&nbsp;&nbsp;&nbsp;&nbsp;Maximum number of mismatches in the non-seed region tolerated by off targets:
	  <input type=text id=nonseed_mismatch name=nonseed_mismatch size=10 maxlength=1
		value=2> 
	  <span style='vertical-align:-0.4ex'>
	
	  </span>
	  <span class=helper title="
     Relative to the target candidate sequence, sequences with more than this number of mismatches in the non-seed region will be excluded from consideration of off-target effects. Mismatches are, as a general rule, better tolerated in the non-seed region than the seed region. Abudayyeh, O. O. et al (2016) has reported that 3 or less mismatches in an off target can be fully tolerated by C2c2 and the maximum number of mismatches in the seed region tolerated by off targets has already been set to 1, resulting in a default value of 2.  		
     ">?</span><br/>
	  </p>
          <p style="display:inline">&nbsp;&nbsp;&nbsp;&nbsp;Maximum number of insertions in the non-seed region tolerated by off targets:
	  <input type=text id=nonseed_insertion name=nonseed_insertion size=10 maxlength=1
		value=0> 
	  <span style='vertical-align:-0.4ex'>
	
	  </span>
	  <span class=helper title="
     Relative to the target candidate sequence, sequences with more than this number of insertions in the non-seed region will be excluded from consideration of off-target effects. Currently, there is no research about insertions, resulting in a default value of 0. 
     ">?</span><br/>
	  </p>
          <p style="display:inline">&nbsp;&nbsp;&nbsp;&nbsp;Maximum number of deletions in the non-seed region tolerated by off targets:
	  <input type=text id=nonseed_deletion name=nonseed_deletion size=10 maxlength=1
		value=0> 
	  <span style='vertical-align:-0.4ex'>
	
	  </span>
	  <span class=helper title="
     Relative to the target candidate sequence, sequences with more than this number of deletions in the non-seed region will be excluded from consideration of off-target effects. Currently, there is no research about deletions, resulting in a default value of 0. 
     ">?</span><br/>
	  </p>


           <p style="display:inline">&nbsp;&nbsp;&nbsp;&nbsp;Maximum number of consecutive mismatches or gaps in the non-seed region tolerated by off targets:
	  <input type=text id=num_nonseed_consec_specific name=num_nonseed_consec_specific size=10 maxlength=1
		value='2'> 
	  <span style='vertical-align:-0.4ex'>
	
	  </span>
	  <span class=helper title="
          Relative to the target candidate sequence, sequences with more than this number of consective combined mismatches or gaps in the non-seed region will be excluded from consideration of off-target effects. As a general rule, mismatches or gaps are better tolerated in the non-seed region. Abudayyeh, O. O. et al (2016) has reported that C2c2 is even tolerant to triple consecutive mismatches in the non-seed region (3' or 5' ends) and the maximum number of mismatches in the non-seed region tolerated by off targets has already been set to 2, resulting in a default value of 2. 
     ">?</span><br/>
	  </p>



</div><br/><br/>
         <div>
	<input type=hidden id=mode_name name=mode_name value="C2c2">
	
	</div>
        <div>
	<input type=hidden id=min_offset name=min_offset value=0>
	
	</div>

        <div>
	<input type=hidden id=max_offset name=max_offset value=0>
	
	</div>
     
        <div>
	<input type=hidden id=num_BulgeStrand name=num_BulgeStrand value=0>
	
	</div>

         &nbsp;&nbsp;&nbsp;<a href="javascript:toggle('Advanced')">Advanced Options</a>
        <div id="Advanced" style="display: none;">
            <p>&nbsp;&nbsp;&nbsp;Search sensitivity:
	<select id=sensitivity name=sensitivity>
		
        <option value=16 >Low</option>
        <option selected="selected" value=14>Medium</option>
        <option value=12 >High</option>
        <!--<option value=10 >Extremely High</option>-->
                       
	</select> 
	<span class=helper title="
     This is the search sensitive parameter of Bowtie2 for finding target sites in the transcriptome. Higher sensitivity usually results in a slower search time.
     ">?</span>
	</p>


        </div><br/><br/>
        


	<div>
	<!--<input type=hidden id=acc2 name=accession value="">-->
	<p><input type=submit class=findtargetsbutton value="Find targets!"></p>
	</div>

</form>

<script>
function myFunction() {
   
   
    var letters = /^[A-Za-z]+$/;
    var numbers = /^[0-9]+$/;
     
    var sequence = document.getElementById("sequence");
    var sequence_value = sequence.value;

    var db = document.getElementById("db");
    var db_value = db.value;


    var target_pfs = document.getElementById("target_pfs");
    var target_pfs_value = target_pfs.value;
    
    var offtarget_pfs = document.getElementById("offtarget_pfs");
    var offtarget_pfs_value = offtarget_pfs.value;

    var gRNA_length = document.getElementById("gRNA_length");
    var gRNA_length_value = gRNA_length.value;

    var seed_length = document.getElementById("seed_length");
    var seed_length_value = seed_length.value;

    
    var offtarget_setting_value = document.querySelector('input[name="offtarget_setting"]:checked').value;
   

    var num_MisAndGap = document.getElementById("num_MisAndGap");
    var num_MisAndGap_value = num_MisAndGap.value;

    var num_Gap = document.getElementById("num_Gap");
    var num_Gap_value = num_Gap.value;    //add

    var num_seed_MisID = document.getElementById("num_seed_MisID");
    var num_seed_MisID_value = num_seed_MisID.value;

    var num_seed_Gap = document.getElementById("num_seed_Gap");
    var num_seed_Gap_value = num_seed_Gap.value; //add

    var num_seed_consec = document.getElementById("num_seed_consec");
    var num_seed_consec_value = num_seed_consec.value; //add

    var num_nonseed_consec = document.getElementById("num_nonseed_consec");
    var num_nonseed_consec_value = num_nonseed_consec.value; //add



    var seed_mismatch = document.getElementById("seed_mismatch");
    var seed_mismatch_value = seed_mismatch.value;

    var seed_insertion = document.getElementById("seed_insertion");
    var seed_insertion_value = seed_insertion.value;

    var seed_deletion = document.getElementById("seed_deletion");
    var seed_deletion_value = seed_deletion.value;

    var num_seed_consec_specific = document.getElementById("num_seed_consec_specific");
    var num_seed_consec_specific_value = num_seed_consec_specific.value; //add

    var nonseed_mismatch = document.getElementById("nonseed_mismatch");
    var nonseed_mismatch_value = nonseed_mismatch.value;

    var nonseed_insertion = document.getElementById("nonseed_insertion");
    var nonseed_insertion_value = nonseed_insertion.value;

    var nonseed_deletion = document.getElementById("nonseed_deletion");
    var nonseed_deletion_value = nonseed_deletion.value;

    var num_nonseed_consec_specific = document.getElementById("num_nonseed_consec_specific");
    var num_nonseed_consec_specific_value = num_nonseed_consec_specific.value; //add


    submitOK = "true";

    if (sequence_value == "") {
        sequence.style.backgroundColor = "#FF9999";
        alert("Please input an RNA sequence in FASTA format!");        
        submitOK = "false";        
    }  

    if (db_value == "none") {
        db.style.backgroundColor = "#FF9999";
        alert("Please choose the reference transcriptome!");        
        submitOK = "false";        
    }  

   if (!target_pfs_value.match(letters) ) {
        target_pfs.style.backgroundColor = "#FF9999";
        alert("The input of on target PFS must be only letters!");        
        submitOK = "false";         
    }
    if (!offtarget_pfs_value.match(letters) ) {
        offtarget_pfs.style.backgroundColor = "#FF9999";
        alert("The input of off target PFS must be only letters!");       
        submitOK = "false";        
    }

    if (!gRNA_length_value.match(numbers) ) {
        gRNA_length.style.backgroundColor = "#FF9999";
        alert("The length of the target complementarity region of crRNA must be positive integer!");       
        submitOK = "false";    

    }  

    if (!seed_length_value.match(numbers) ) {
        seed_length.style.backgroundColor = "#FF9999";
        alert("The length of the seed region must be positive integer!");       
        submitOK = "false";    

    }

    if (Number(seed_length_value) > Number(gRNA_length_value)) {
        seed_length.style.backgroundColor = "#FF9999";
        alert("The length of seed region must be not greater than the length of the target complementarity region of crRNA!");       
        submitOK = "false";            
    }

    if (offtarget_setting_value == 'General'){
        if (!num_MisAndGap_value.match(numbers) || Number(num_MisAndGap_value) > 5) {
           num_MisAndGap.style.backgroundColor = "#FF9999";
           alert("The total number of mismatches and gaps tolerated by off targets must be positive integer and not greater than 5!");       
           submitOK = "false";    

        }

        /////////////add
        if (!num_Gap_value.match(numbers) || Number(num_Gap_value) > Number(num_MisAndGap_value)) {
           num_Gap.style.backgroundColor = "#FF9999";
           alert("The number of gaps tolerated by off targets must be positive integer and not greater than the total number of mismatches and gaps tolerated by off targets!");       
           submitOK = "false";    

        }
        ///////////////

        if (!num_seed_MisID_value.match(numbers) || Number(num_seed_MisID_value) > Number(num_MisAndGap_value)) {
           num_seed_MisID.style.backgroundColor = "#FF9999";
           alert("The total number of mismatches and gaps in the seed region tolerated by off targets must be positive integer and not greater than the total number of mismatches and gaps tolerated by off targets!");       
           submitOK = "false";    

        }

        /////////////add
        if (!num_seed_Gap_value.match(numbers) || Number(num_seed_Gap_value) > Number(num_Gap_value) || Number(num_seed_Gap_value) > Number(num_seed_MisID_value)) {
           num_seed_Gap.style.backgroundColor = "#FF9999";
           alert("The number of gaps in the seed region tolerated by off targets must be positive integer and not greater than the number of gaps tolerated by off targets and not greater than the total number of mismatches and gaps in the seed region tolerated by off targets!");       
           submitOK = "false";    

        }

        ///////////////

        /////////////add
        if (!num_seed_consec_value.match(numbers) || Number(num_seed_consec_value) > Number(num_seed_MisID_value)) {
           num_seed_consec.style.backgroundColor = "#FF9999";
           alert("The number of consecutive mismatches or gaps in the seed region tolerated by off targets must be positive integer and not greater than the total number of mismatches and gaps in the seed region tolerated by off targets!");       
           submitOK = "false";    

        }

        ///////////////
   
    } else if (offtarget_setting_value == 'Specific'){
        if (!seed_mismatch_value.match(numbers) ) {
           seed_mismatch.style.backgroundColor = "#FF9999";
           alert("The number of mismatches in seed region tolerated by off targets must be integer!");       
           submitOK = "false";    

        }

        if (!seed_insertion_value.match(numbers) ) {
           seed_insertion.style.backgroundColor = "#FF9999";
           alert("The number of insertions in seed region tolerated by off targets must be integer!");       
           submitOK = "false";    

        }

        if (!seed_deletion_value.match(numbers) ) {
           seed_deletion.style.backgroundColor = "#FF9999";
           alert("The number of deletions in seed region tolerated by off targets must be integer!");       
           submitOK = "false";    

        }
        if (!nonseed_mismatch_value.match(numbers) ) {
           nonseed_mismatch.style.backgroundColor = "#FF9999";
           alert("The number of mismatches in nonseed region tolerated by off targets must be integer!");       
           submitOK = "false";    

        }

        if (!nonseed_insertion_value.match(numbers) ) {
           nonseed_insertion.style.backgroundColor = "#FF9999";
           alert("The number of insertions in nonseed region tolerated by off targets must be integer!");       
           submitOK = "false";    

        }

        if (!nonseed_deletion_value.match(numbers) ) {
           nonseed_deletion.style.backgroundColor = "#FF9999";
           alert("The number of deletions in nonseed region tolerated by off targets must be integer!");       
           submitOK = "false";    

        }
        var total_MID= Number(seed_mismatch_value)+Number(seed_insertion_value)+Number(seed_deletion_value)+Number(nonseed_mismatch_value)+Number(nonseed_insertion_value)+Number(nonseed_deletion_value);
        if (total_MID > 5 ){
            seed_mismatch.style.backgroundColor = "#FF9999";
            seed_insertion.style.backgroundColor = "#FF9999";
            seed_deletion.style.backgroundColor = "#FF9999";
            nonseed_mismatch.style.backgroundColor = "#FF9999";
            nonseed_insertion.style.backgroundColor = "#FF9999";
            nonseed_deletion.style.backgroundColor = "#FF9999";
           alert("The total number of mismatches, insertions and deletions in seed and non-seed regions must not be greater than 5!");       
           submitOK = "false"; 

         }

    }

    if (submitOK == "false") {
        return false;
    }
}

</script>














<?php include ROOT_PATH."/layout/footer.php"; ?>
