<?php 
define('ROOT_PATH','..');
include ROOT_PATH."/layout/header.php";
?>


<form name=ct-finder method=POST action='../proc/uploader.php' enctype='multipart/form-data' onsubmit="return myFunction()">
<b><p style="font-size:200%; color:#4D6277">CRISPR/Cas System</p></b>

	
<h2>Step 1: Provide a genomic region to search for candidate CRISPR targets</h2>
	<p style="display:inline">Input a DNA sequence in FASTA format:
     <span class=helper title="
     Paste a single DNA sequence in FASTA format into the text field (standard DNA characters only: A, C, T, G). CT-Finder will find candidate targets within this sequence.
     ">?</span></p>
     <p style="padding-left:385px; display:inline">
     <input name="Example" class=examplebutton type="button" value="Example Sequence"
                onClick="inputexamplesequence()"/><br>
    </p>
	<textarea id=sequence name=userseq rows=15 cols=90 class=mono></textarea>

	<p>or upload a DNA sequence file:
	<span style='vertical-align:-0.4ex'>	
	</span>
	<input type=file id=userfile name=userfile size=40>
	</p>
	
        <!--p>or enter a genome location (e.g. TAIR10.27_chr1:6437-7069): 
	<input type=text id=gene_location name=gene_location size=20 maxlength=100
		value=''--> 
	<span style='vertical-align:-0.4ex'>
	
	</span>
	</p>
	
<h2>Step 2: Choose your reference genome</h2>
	<p>Reference genome:
	<select id=db name=db>
		<option value=none>Choose an organism</option>
        <option value=TAIR10.27 >Ensembl Thale cress (Arabidopsis thaliana) genome TAIR10.27</option>
        <!--<option value=TAIR10.ncbi>Thale cress (Arabidopsis thaliana NCBI) genome</option>-->
        <option value=IRGSP-1.0.27>Ensembl Rice (Oryza sativa) genome IRGSP-1.0.27</option>
        <!--<option value=ASM242v1.27>Moss (Physcomitrella patens) genome</option>-->
		<option value=GRCh38.81>Ensembl Human (Homo sapiens) genome GRCh38.81</option>
		<option value=GRCm38.81>Ensembl Mouse (Mus musculus) genome GRCm38.81</option>
		<option value=HIV-1.ncbi>NCBI Human immunodeficiency virus 1 (HIV-1) genome</option>
		<!--<option value=Rnor_6.0.81>Rat (Rattus norvegicus) genome</option>-->
		<!--<option value=C_jacchus3.2.1.81>Marmoset (Callithrix jacchus) genome</option>-->
		<!--<option value=Sscrofa10.2.81>Pig (Sus scrofa) genome</option>-->
		<option value=Galgal4.81>Ensembl Chicken (Gallus gallus) genome</option>
		<!--<option value=JGI_4.2.81>Frog (Xenopus tropicalis) genome</option>-->
		<!--<option value=Xenla7>Frog (Xenopus laevis) genome, JGI 7.1/Xenla7 (Dec, 2013)</option> -->
		<!--<option value=GRCz10.81>Zebrafish (Danio rerio) genome</option>-->
		<!--<option value=KH.81>Sea squirt (Ciona intestinalis) genome</option>-->
		<!--<option value=BDGP6.81>Fruit fly (Drosophila melanogaster) genome</option>-->
		<!--<option value=WBcel235.81>Roundworm (Caenorhabditis elegans) genome</option>-->
		
		<!--<option value=Sorbi1.27>Sorghum (Sorghum bicolor) genome</option>-->
		<!--<option value=bmor1  >Silkworm (Bombyx mori) genome</option>-->
		<!--<option value=R64-1-1.81>Budding yeast (Saccharomyces cerevisiae) genome</option>-->
		<!--<option value=pombe  >Fission yeast (Schizosaccharomyces pombe) (972h-) genome, ASM294v2 (Nov, 2007)</option>-->
		<!--<option value=CanFam3.1.81>Domestic dog (Canis familiaris) genome</option>-->
		<!--<option value=cavPor3.81>Guinea pig (Cavia procellus) genome</option>-->
		<!--<option value=Felis_catus_6.2.81>Domestic cat (Felis catus) genome</option>-->
		<!--<option value=Oar_v3.1.81>Sheep (Ovis aries) genome</option>-->
		<!--<option value=CHIMP2.1.4.81>Chimpanzee (Pan troglodytes) genome</option>-->
                
	</select> 
	<span class=helper title="
     This is the organism you wish to perform genome editing on. A selection of model organisms is available; if your organism is not listed here, contact us so we may add it to the database.
     ">?</span><a href="add_genome.php" target="_blank">(Other genome?)</a><br/>
      
	</p>


<h2>Step 3: Describe the guide RNA for your system</h2>
	<p style="display:inline"><b>PAM sequence</b>
	<span class=helper title="
     The PAM sequence is a motif at the 3' end of the DNA target sequence required for Cas9 to bind to the target. The PAM sequence varies between different types of CRISPR systems used by different species. S. pyogenes Cas9 (SpCas9) is the most common CRISPR system used in research applications; the PAM sequence of SpCas9 is NGG. SpCas9 can also bind to a NAG PAM sequence, but much less efficiently than the canonical NGG. The default is a NGG on-target PAM sequence and a NGG off-target PAM sequence.
     ">?</span><br/><br/>
	On Target:
	<input type=text id=target_pam name=target_pam size=10 maxlength=10
		value='NGG'>
	<span style='vertical-align:-0.4ex'>
	
	</span>
	Off target:
	<input type=text id=offtarget_pam name=offtarget_pam size=10 maxlength=10
		value='NGG'> (e.g. NGG, NRG)
	<span style='vertical-align:-0.4ex'>
	
	</span>
	</p><br/><br/>
	
	
	<!--
	<p style="display:inline"><b>Length of guide RNA, excluding the PAM sequence:</b>
	<span class=helper title="
     This is the length of the variable portion of the guide RNA (also called the offset), in nucleotides. The preferred length of guide RNA varies betweeen different CRISPR systems. In SpCas9, offset lengths are reported to be most efficient in the range of 14-17 nt.
     ">?</span><br/><br/>
        Minimum:
	<input type=text id=min_offset name=min_offset size=10 maxlength=3
		value='14'> 
	<span style='vertical-align:-0.4ex'>
	
	</span>
	Maximum:
	<input type=text id=max_offset name=max_offset size=10 maxlength=3
		value='17'> 
	<span style='vertical-align:-0.4ex'>
	
	</span>
	</p><br/><br/>
        -->
        <p style="display:inline">Length of guide RNA:
	<input type=text id=gRNA_length name=gRNA_length size=10 maxlength=2
		value='20'> <span class=helper title="
     This is the length guide RNA, The natural length of an SpCas9 gRNA is 20 nt, but the range of permissibly effective lengths varies between 17-20 nt.
     ">?</span>
	<span style='vertical-align:-0.4ex'>
	
	</span><br/><br/>
        <p style="display:inline">Length of seed region:
	<input type=text id=seed_length name=seed_length size=10 maxlength=2
		value='8'> 
	<span style='vertical-align:-0.4ex'>
	
	</span>
	<span class=helper title="
     The seed region (core region) is a portion of the target site proximal to the PAM sequence which is critical for binding specificity of Cas9. Mutations in the seed region are expected to have dramatic effects on the activity of Cas9.
     ">?</span><br/>
	</p>
        
	
<h2>Step 4: Choose a setting</h2>

		<script type="text/javascript">
		function toggle(element) {
		    document.getElementById(element).style.display = (document.getElementById(element).style.display == "none") ? "" : "none";
		}
		</script>
 
        <input type="radio" name="seed_setting" id="seed_setting" value="General" checked="checked">&nbsp;<b>Basic settings</b>
        <a href="javascript:toggle('general_opt')">(show options)</a><br/>
      <div id="general_opt" style="display: none;">
      <p style="display:inline"><br/>&nbsp;&nbsp;&nbsp;&nbsp;Maximum number of mismatches and gaps tolerated by off targets:
	  <input type=text id=num_MisAndGap name=num_MisAndGap size=10 maxlength=1
		value='5'> 
	  <span style='vertical-align:-0.4ex'>
	
	  </span>
	  <span class=helper title="
          Relative to the candidate target sequence, sequences with more than this number of combined mismatches and gaps will be excluded from consideration of off-target effects. Using the SpCas9 system, it has beeen reported that 3 or more mismatches in an off-target site usually result in no detectable cleavage activity, but in rare cases cleavage activity has been detected at off-target sites with up to 5 mismatches. Note: This value can be set up to 5.
     ">?</span><br/>
	  </p>
          <p style="display:inline">&nbsp;&nbsp;&nbsp;&nbsp;Maximum number of mismatches and gaps in seed region tolerated by off targets:
	  <input type=text id=num_seed_MisID name=num_seed_MisID size=10 maxlength=1
		value='1'> 
	  <span style='vertical-align:-0.4ex'>
	
	  </span>
	  <span class=helper title="
          Relative to the candidate target sequence, sequences with more than this number of combined mismatches and gaps in the seed region will be excluded from consideration of off-target effects. As a general rule, mismatches and gaps are poorly tolerated in the seed region, so this number should be low.
     ">?</span><br/>
	  </p></div><br/>
        
        <input type="radio" name="seed_setting" id="seed_setting" value="Specific">&nbsp;<b>Specific settings</b>
        <a href="javascript:toggle('specific_opt')">(show options)</a>
        <div id="specific_opt" style="display: none;">
        <h4>Seed region</h4>
          <p style="display:inline">&nbsp;&nbsp;&nbsp;&nbsp;Maximum number of mismatches in seed region tolerated by off targets:
	  <input type=text id=seed_mismatch name=seed_mismatch size=10 maxlength=1
		value=1> 
	  <span style='vertical-align:-0.4ex'>
	
	  </span>
	  	<span class=helper title="
     Relative to the candidate target sequence, sequences with more than this number of mismatches in the seed region will be excluded from consideration of off-target effects. As a general rule, mismatches are poorly tolerated in the seed region, so this number should be low. Note: When setting this value, please note that the total number of mismatches and gaps in seed region and non-seed region is up to 5.
     ">?</span><br/>
	  </p>
          <p style="display:inline">&nbsp;&nbsp;&nbsp;&nbsp;Maximum number of insertions in seed region tolerated by off targets:
	  <input type=text id=seed_insertion name=seed_insertion size=10 maxlength=1
		value=0> 
	  <span style='vertical-align:-0.4ex'>
	
	  </span>
	  <span class=helper title="
     Relative to the candidate target sequence, sequences with more than this number of insertions (or DNA bulges) in the seed region will be excluded from consideration of off-target effects. As a general rule, insertions are poorly tolerated in the seed region, so this number should be low. DNA bulges are typically less well tolerated than RNA bulges. Note: When setting this value, please note that the total number of mismatches and gaps in seed region and non-seed region is up to 5.
     ">?</span><br/>
	  </p>
          <p style="display:inline">&nbsp;&nbsp;&nbsp;&nbsp;Maximum number of deletions in seed region tolerated by off targets:
	  <input type=text id=seed_deletion name=seed_deletion size=10 maxlength=1
		value=0> 
	  <span style='vertical-align:-0.4ex'>
	
	  </span>
	  <span class=helper title="
     Relative to the candidate target sequence, sequences with more than this number of deletions (or RNA bulges) in the seed region will be excluded from consideration of off-target effects. As a general rule, deletions are poorly tolerated in the seed region, so this number should be low. RNA bulges are typically better tolerated than DNA bulges. Note: When setting this value, please note that the total number of mismatches and gaps in seed region and non-seed region is up to 5.
     ">?</span><br/>
	  </p>
	  
	  <h4>Non-seed region</h4>
          <p style="display:inline">&nbsp;&nbsp;&nbsp;&nbsp;Maximum number of mismatches in non-seed region tolerated by off targets:
	  <input type=text id=nonseed_mismatch name=nonseed_mismatch size=10 maxlength=1
		value=2> 
	  <span style='vertical-align:-0.4ex'>
	
	  </span>
	  <span class=helper title="
     Relative to the candidate target sequence, sequences with more than this number of mismatches in the non-seed region will be excluded from consideration of off-target effects. This number should be higher than the corresponding threshold for the seed region; mismatches are, as a general rule, better tolerated in the non-seed region than the seed region. Note: When setting this value, please note that the total number of mismatches and gaps in seed region and non-seed region is up to 5.
     ">?</span><br/>
	  </p>
          <p style="display:inline">&nbsp;&nbsp;&nbsp;&nbsp;Maximum number of insertions in non-seed region tolerated by off targets:
	  <input type=text id=nonseed_insertion name=nonseed_insertion size=10 maxlength=1
		value=1> 
	  <span style='vertical-align:-0.4ex'>
	
	  </span>
	  <span class=helper title="
     Relative to the candidate target sequence, sequences with more than this number of insertions (or DNA bulges) in the non-seed region will be excluded from consideration of off-target effects.This number should be higher than the corresponding threshold for the seed region; insertions are, as a general rule, better tolerated in the non-seed region than the seed region. DNA bulges are typically less well tolerated than RNA bulges. Note: When setting this value, please note that the total number of mismatches and gaps in seed region and non-seed region is up to 5.
     ">?</span><br/>
	  </p>
          <p style="display:inline">&nbsp;&nbsp;&nbsp;&nbsp;Maximum number of deletions in non-seed region tolerated by off targets:
	  <input type=text id=nonseed_deletion name=nonseed_deletion size=10 maxlength=1
		value=1> 
	  <span style='vertical-align:-0.4ex'>
	
	  </span>
	  <span class=helper title="
     Relative to the candidate target sequence, sequences with more than this number of deletions (or RNA bulges) in the non-seed region will be excluded from consideration of off-target effects. This number should be higher than the corresponding threshold for the seed region; deletions are, as a general rule, better tolerated in the non-seed region than the seed region. RNA bulges are typically better tolerated than DNA bulges. Note: When setting this value, please note that the total number of mismatches and gaps in seed region and non-seed region is up to 5.
     ">?</span><br/>
	  </p></div><br/><br/>
         <div>
	<input type=hidden id=mode_name name=mode_name value="Cas9">
	
	</div>
        <div>
	<input type=hidden id=min_offset name=min_offset value=0>
	
	</div>

        <div>
	<input type=hidden id=max_offset name=max_offset value=0>
	
	</div>
     
        <div>
	<input type=hidden id=num_BulgeStrand name=num_BulgeStrand value=0>
	
	</div>

         &nbsp;&nbsp;&nbsp;<a href="javascript:toggle('Advanced')">Advanced Options</a>
        <div id="Advanced" style="display: none;">
            <p>&nbsp;&nbsp;&nbsp;Search sensitivity:
	<select id=sensitivity name=sensitivity>
		
        <option value=16 >Low</option>
        <option selected="selected" value=14>Medium</option>
        <option value=12 >High</option>
        <option value=10 >Extremely High</option>
                       
	</select> 
	<span class=helper title="
     Set the sensitive parameter for Bowtie2 to search off targets in the genome.
     ">?</span>
	</p>


        </div><br/><br/>
        


	<div>
	<!--<input type=hidden id=acc2 name=accession value="">-->
	<p><input type=submit class=findtargetsbutton value="Find optimal targets!" onclick="window.location.reload()"></p>
	</div>

</form>
<!--
<a href="javascript:toggle('add_genome')">(Other genome?)</a><br/>
      <div id="add_genome" style="display: none;">
        <form action="save-to-log.php" method="POST">
          <fieldset>
            <legend>Genome that you want to add:</legend><br>
             Genome Name: <input type="text" name="genome"><br><br>
             Your Name: <input type="text" name="name"><br><br>
             Email Adress: <input type="text" name="email"><br><br>
             
            <input type="submit" value="submit" />
          </fieldset>
        </form>
       </div>
-->

<script>
function myFunction() {
   
   
    var letters = /^[A-Za-z]+$/;

    var numbers = /^[0-9]+$/;
     
    var sequence = document.getElementById("sequence");
    var sequence_value = sequence.value;

    var userfile = document.getElementById("userfile");
    var userfile_value = userfile.value;

    var db = document.getElementById("db");
    var db_value = db.value;


    var target_pam = document.getElementById("target_pam");
    var target_pam_value = target_pam.value;
    
    var offtarget_pam = document.getElementById("offtarget_pam");
    var offtarget_pam_value = offtarget_pam.value;

    var gRNA_length = document.getElementById("gRNA_length");
    var gRNA_length_value = gRNA_length.value;

    var seed_length = document.getElementById("seed_length");
    var seed_length_value = seed_length.value;

    
    var seed_setting_value = seed_setting.value=document.querySelector('input[name="seed_setting"]:checked').value;
   

    var num_MisAndGap = document.getElementById("num_MisAndGap");
    var num_MisAndGap_value = num_MisAndGap.value;

    var num_seed_MisID = document.getElementById("num_seed_MisID");
    var num_seed_MisID_value = num_seed_MisID.value;

    var seed_mismatch = document.getElementById("seed_mismatch");
    var seed_mismatch_value = seed_mismatch.value;

    var seed_insertion = document.getElementById("seed_insertion");
    var seed_insertion_value = seed_insertion.value;

    var seed_deletion = document.getElementById("seed_deletion");
    var seed_deletion_value = seed_deletion.value;

    var nonseed_mismatch = document.getElementById("nonseed_mismatch");
    var nonseed_mismatch_value = nonseed_mismatch.value;

    var nonseed_insertion = document.getElementById("nonseed_insertion");
    var nonseed_insertion_value = nonseed_insertion.value;

    var nonseed_deletion = document.getElementById("nonseed_deletion");
    var nonseed_deletion_value = nonseed_deletion.value;

    submitOK = "true";

    if (sequence_value == "" && userfile_value == "") {
        sequence.style.backgroundColor = "#FF9999";
        alert("Please input a DNA sequence or upload a DNA sequence file in FASTA format!");        
        submitOK = "false";        
    }  

    if (db_value == "none") {
        db.style.backgroundColor = "#FF9999";
        alert("Please choose your reference genome!");        
        submitOK = "false";        
    }  

  //  if (target_pam_value.length != 3) {
  //      target_pam.style.backgroundColor = "#FF9999";
  //      alert("The length of on target PAM must be 3!");        
  //      submitOK = "false";        
  // } else 
   if (!target_pam_value.match(letters) ) {
        target_pam.style.backgroundColor = "#FF9999";
        alert("The input of on target PAM must be only letters!");        
        submitOK = "false";         
    }


   // if (offtarget_pam_value.length != 3) {
   //     offtarget_pam.style.backgroundColor = "#FF9999";
   //     alert("The length of off target PAM must be 3!");       
   //     submitOK = "false";        
   // } else 
    if (!offtarget_pam_value.match(letters) ) {
        offtarget_pam.style.backgroundColor = "#FF9999";
        alert("The input of off target PAM must be only letters!");       
        submitOK = "false";        
    }

    if (!gRNA_length_value.match(numbers) ) {
        gRNA_length.style.backgroundColor = "#FF9999";
        alert("The length of guide RNA must be positive integer!");       
        submitOK = "false";    

    }  

    if (!seed_length_value.match(numbers) ) {
        seed_length.style.backgroundColor = "#FF9999";
        alert("The length of seed region of guide RNA must be positive integer!");       
        submitOK = "false";    

    }

    if (Number(seed_length_value) > Number(gRNA_length_value)) {
        seed_length.style.backgroundColor = "#FF9999";
        alert("The length of seed region must be not greater than length guide RNA!");       
        submitOK = "false";            
    }

    if (seed_setting_value == 'General'){
        if (!num_MisAndGap_value.match(numbers) || Number(num_MisAndGap_value) > 5) {
           num_MisAndGap.style.backgroundColor = "#FF9999";
           alert("The number of mismatches and gaps tolerated by off targets must be integer and not greater than 5!");       
           submitOK = "false";    

        }

        if (!num_seed_MisID_value.match(numbers) || Number(num_seed_MisID_value) > Number(num_MisAndGap_value)) {
           num_seed_MisID.style.backgroundColor = "#FF9999";
           alert("The number of mismatches and gaps in seed region tolerated by off targets must be integer and not greater than the number of mismatches and gaps tolerated by off targets!");       
           submitOK = "false";    

        }
   
    } else if (seed_setting_value == 'Specific'){
        if (!seed_mismatch_value.match(numbers) ) {
           seed_mismatch.style.backgroundColor = "#FF9999";
           alert("The number of mismatches in seed region tolerated by off targets must be integer!");       
           submitOK = "false";    

        }

        if (!seed_insertion_value.match(numbers) ) {
           seed_insertion.style.backgroundColor = "#FF9999";
           alert("The number of insertions in seed region tolerated by off targets must be integer!");       
           submitOK = "false";    

        }

        if (!seed_deletion_value.match(numbers) ) {
           seed_deletion.style.backgroundColor = "#FF9999";
           alert("The number of deletions in seed region tolerated by off targets must be integer!");       
           submitOK = "false";    

        }
        if (!nonseed_mismatch_value.match(numbers) ) {
           nonseed_mismatch.style.backgroundColor = "#FF9999";
           alert("The number of mismatches in nonseed region tolerated by off targets must be integer!");       
           submitOK = "false";    

        }

        if (!nonseed_insertion_value.match(numbers) ) {
           nonseed_insertion.style.backgroundColor = "#FF9999";
           alert("The number of insertions in nonseed region tolerated by off targets must be integer!");       
           submitOK = "false";    

        }

        if (!nonseed_deletion_value.match(numbers) ) {
           nonseed_deletion.style.backgroundColor = "#FF9999";
           alert("The number of deletions in nonseed region tolerated by off targets must be integer!");       
           submitOK = "false";    

        }
        var total_MID= Number(seed_mismatch_value)+Number(seed_insertion_value)+Number(seed_deletion_value)+Number(nonseed_mismatch_value)+Number(nonseed_insertion_value)+Number(nonseed_deletion_value);
        if (total_MID > 5 ){
            seed_mismatch.style.backgroundColor = "#FF9999";
            seed_insertion.style.backgroundColor = "#FF9999";
            seed_deletion.style.backgroundColor = "#FF9999";
            nonseed_mismatch.style.backgroundColor = "#FF9999";
            nonseed_insertion.style.backgroundColor = "#FF9999";
            nonseed_deletion.style.backgroundColor = "#FF9999";
           alert("The total number of mismatches, insertions and deletions in seed and non-seed regions must not be greater than 5!");       
           submitOK = "false"; 

         }

    }

    if (submitOK == "false") {
        return false;
    }
}

</script>














<?php include ROOT_PATH."/layout/footer.php"; ?>
