<?php include "../layout/header.php" ?>
  <h1 class="bold">About</h1>
  <div>
    <p class="normalfont"><strong class="title2">Coming Soon</strong><br /> </div>
<?php include "../layout/footer.php" ?>
