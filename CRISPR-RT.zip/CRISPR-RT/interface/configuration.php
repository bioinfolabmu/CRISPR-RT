<?php 
include("../webseqviewer/configuration/configFiles/sysConfig.php"); 
$forceBread="Configure";
include("../layout/header.php"); ?>
	<link href="../libraries/dijit/themes/dijit.css" rel="stylesheet" />
	<link href="../libraries/dijit/themes/claro/Common.css" rel="stylesheet" />
	<link href="../libraries/dijit/themes/claro/form/Common.css" rel="stylesheet" />
	<link href="../libraries/dijit/themes/claro/form/Button.css" rel="stylesheet" />
	<link href="../libraries/dojox/form/resources/UploaderFileList.css" rel="stylesheet" />

	<style>
	div.divloading {
    width:500px;
	top:50%;
	left:50%;
	position:absolute;
	display:none;
    }
	</style>
	<script type="text/javascript">
                var installPath = "<?php  echo $installationPath ?>";
		var filename1="<?php echo $_POST["filename"] ?>";
		var querySeq1="<?php echo $_POST["querySequence"]?>";
		var projectname="<?php echo $_POST["projectname"]?>";
	</script>
  <script src="../javascript/webphobos.js" type="text/javascript" language="JavaScript" ></script>
	<div id="upload_body">
   <h1>Detect Simple Sequence Repeat</h1>
   		<br>
<br>
<hr>
  <div>
<br>
  <b>Search Modes:</b>
   <select dojoType="dijit.form.FilteringSelect" id="modes"
		invalidMessage = "Invalid search model"
		autoComplete = "true">
		<option value="imperfect" >Imperfect search</option>
	    <option value="exact" >Perfect search</option>
	    <option value="extendExact" >Extend exact search</option>
   </select>
   </div>
<br>
   <hr>
   <div>
<br>
   <b>Mismatch score:(typical -3 to -6)</b>
    <input id="misScore" type="text" dojoType="dijit.form.TextBox" style="width:30px" value="-5"/><br>
    <b>Gap score:(typical -3 to -6)</b>
    <input id="gapScore" type="text" dojoType="dijit.form.TextBox" style="width:30px" value="-5"/><br>
    <b>Recursion depth:</b>
    <input id="recursion" type="text" dojoType="dijit.form.TextBox" style="width:30px" value="5"/><br>
    <b>Maximum score reduce:</b>
    <input id="reduce" type="text" dojoType="dijit.form.TextBox" style="width:30px" value="30"/><br>
<br>  
 </div><hr>
    <div>
	<br>    
<b>Analyze sequence range(blank for first/last):</b> from <input id="start" type="text" dojoType="dijit.form.TextBox" style="width:30px" value="1"/> to<input id="end" type="text" dojoType="dijit.form.TextBox" style="width:30px" value=""/><br>
    <b>Repeat unit size range:</b> from <input id="minunit" type="text" dojoType="dijit.form.TextBox" style="width:30px" value="1"/> to<input id="maxunit" type="text" dojoType="dijit.form.TextBox" style="width:30px" value="10"/><br>
	<label for="treat_N_chk">Treat N's as missense instead of neutral: </label><input type="checkbox" id="treat_N_chk"  dojoType="dijit.form.CheckBox" ><br>
    <b>Maximum number of successive N's allowed in a repeat:</b> <input id="succN" type="text" dojoType="dijit.form.TextBox" style="width:30px" value="2"/>	
<br>
<br>   
 </div>
<hr>
    <div>
<br>
    <b>Minimum length of a satellite:</b><br>
    <input id="minLength_a" type="text" dojoType="dijit.form.TextBox" style="width:30px" value="0"/>+<input id="minLength_b" type="text" dojoType="dijit.form.TextBox" style="width:30px" value="0"/>*(unit-length),but not less than<input id="minLength" type="text" dojoType="dijit.form.TextBox" style="width:30px" value="0"/><br>
    <b>Minimum score of a satellite:</b><br>
    <input id="minScore_a" type="text" dojoType="dijit.form.TextBox" style="width:30px" value="0"/>+<input id="minScore_b" type="text" dojoType="dijit.form.TextBox" style="width:30px" value="1"/>*(unit-length),but not less than<input id="minScore" type="text" dojoType="dijit.form.TextBox" style="width:30px" value="6"/><br>
    <b>Minimum and maximum percentage perfection:</b><br>
    Minimum:<input id="minPerfection" type="text" dojoType="dijit.form.TextBox" style="width:30px" value="0"/>%&nbsp;&nbsp;&nbsp;&nbsp;Maximum<input id="maxPerfection" type="text" dojoType="dijit.form.TextBox" style="width:30px" value="100"/>%
<br> 
<br>  
 </div><hr>
    <div>
<br>    
<b>Treating N's when computing perfection:</b>
    <select dojoType="dijit.form.FilteringSelect" style="width:110px"  id="treat"
		invalidMessage = "Invalid treat"
		autoComplete = "true">
		<option value="0" >as mismatch</option>
	    <option value="1" >neutral</option>
	    <option value="2" >as match</option>
    </select>  <br> 
    <label for ="treat_N_chk">Remove Hidden Repeats: </label><input type="checkbox" id="remove"  dojoType="dijit.form.CheckBox" >
<br>
<br>    
</div>
<hr>
    <div>
<br>
    <button id="Analyze"dojoType="dijit.form.Button" onclick="organizeCommand()">Analyse</button>	
    </div>
    <div id="datagrid"></div>
     <div id="seqviewer"></div>
     <div class="divloading" id="divloading">
                <img src="../images/Loading.gif"/>
    </div>  
  </div>
<?php include("../layout/footer.php"); ?>
