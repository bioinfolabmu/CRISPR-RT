<!DOCTYPE html>
<html>
<body>

<form action="save-to-log.php" method="POST">
          <fieldset>
            <legend><b>Transcriptome that you want to add:</b></legend><br>
             Transcriptome Name*: <input type="text" name="genome"><br><br>
             <!--Genome Database: <input type="text" name="genome_db"><br><br>-->
             Your Name: <input type="text" name="name"><br><br>
             Email Adress: <input type="text" name="email"><br><br>
             
            <input type="submit" value="submit" />
          </fieldset>
</form>

</body>
</html>
