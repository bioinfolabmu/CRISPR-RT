<?php 
define('ROOT_PATH','..');
include ROOT_PATH."/layout/header.php"; 
?>


<html>

<head>
  <meta charset='utf-8'>
  <meta name='Description' content="This help section guides the user through the submission process and explains the meaning of output">
  <title>CRISPR-RT | Help</title>
  <!--<link rel='shortcut icon' href='../static/images/favicon.ico'>
  <link rel=stylesheet href='../static/css/gt-scan.css'>
  <script src='../static/js/jquery.min.js'></script>
  <script src='../static/js/menu.js'></script>
  <script>var online = true;</script>-->
</head>

<body>

<!-- Main content -->
    <div id=main>
<div id=documentation>
    <h1 id=top>Help Topics</h1>
    
    <ul>
      
      <li><h3><a href=#intro>Introduction</a></h3>
      <li><h3><a href=#input>Input of CRISPR-RT</a></h3>
      <li><h3><a href=#output>Output of CRISPR-RT</a></h3>
      
    </ul>
    <hr>
    
    <br>
    <font id=intro color="#763ca5" size="5"><b>Introduction</b></font>
    <p>CRISPR-RT (CRISPR <b>R</b>NA-<b>T</b>argeting) is a web service to help biologists design the optimal crRNA for the CRISPR-C2c2 system. CRISPR-RT is essentially composed of many interfaces and a backend pipeline. Interfaces are implemented by PHP and JavaScript code, which are used to accept user inputs and interactively display the results. The backend pipeline is implemented by Perl code, which is used to process user input data and generate multiple result files. </p>

    <font id=input color="#763ca5" size="5"><b>Input of CRISPR-RT</b></font>
    
     <ul>
      <li><font color="black" size="3">Step 1: Provide an RNA sequence to target</font><br>
      <br>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<img src="../layout/images/step1.jpg" alt="Step 1" style="width:659px;height:237px;">
         <ul><li><p>Input an RNA sequence that users want to target in FASTA format into the text area.
         </ul>
      
         <ul><li><p><b>cDNA?:</b> Users can convert a cDNA sequence to the corresponding RNA sequence by clicking the “cDNA?” link. After converting, they then copy the converted RNA sequence back into the text area for inputting a sequence.    
 
         </ul>

         <ul><li><b>Example Sequence:</b> Users can click the “Example Sequence” button to use an example sequence.
         </ul>

     </ul>

     <ul><li><font color="black" size="3">Step 2: Choose the reference transcriptome</font><br>
         <br>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<img src="../layout/images/step2.jpg" alt="Step 2" style="width:653px;height:36px;">
         <ul><li><p>Select a reference transcriptome from the drop-down menu.
         </ul>
      
         <ul><li><p><b>others?:</b> If the transcriptome that users want to choose does not show up in the drop-down menu, they can click the “others?” link to submit a requirement, and the transcriptome will be added to the web server as soon as possible.    
 
         </ul>
     </ul>

     <ul><li><font color="black" size="3">Step 3: Describe the PFS and crRNA requirements</font><br>
         <br>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<img src="../layout/images/step3.jpg" alt="Step 3" style="width:400px;height:138px;">
         <ul><li><p><b>PFS sequence:</b> PFS stands for protospacer flanking site. The PFS sequence is adjacent to the 3' end of the protospacer. PFS affects the efficacy of CRISPR-C2c2 targeting. The CRISPR-C2c2 system prefers H (A, U, or C) for the PFS sequence of one single base length to mediate single-strand RNA cleavage.
         </ul>
      
         <ul><li><p><b>On Target:</b> Set up the on-target PFS sequence, which accepts any single letter or combination of the international union of pure and applied chemistry (IUPAC) nucleotide codes except “T” and “Z”.  
 
         </ul>

         <ul><li><p><b>Off Target:</b> Set up the off-target PFS sequence, which accepts any single letter or combination of the international union of pure and applied chemistry (IUPAC) nucleotide codes except “T” and “Z”.  
 
         </ul>

         <ul><li><p><b>Length of the target complementarity region of crRNA:</b> This is the length of the target complementarity region of crRNA, which binds to a specific RNA target site. The range of permissibly effective lengths varies between 22-28 nt.
 
         </ul>

         <ul><li><p><b>Length of the seed region:</b> The seed region is located in the center of the crRNA-target duplex, where is more sensitive to mismatches than the non-seed region. Its length should not be greater than the length of the target complementarity region of crRNA.
 
         </ul>
     </ul>

     <ul><li><font color="black" size="3">Step 4: Choose an off-target setting</font><br>
         <br>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<img src="../layout/images/step4.jpg" alt="Step 4" style="width:664px;height:490px;">
         <ul><li><p>Users can choose an off-target setting (“Basic settings” or “Specific settings”).
         </ul>
      
         <ul><li><p>Basic settings 
               <ul><li><p><b>Maximum total number of mismatches and gaps tolerated by off targets:</b> Relative to the target candidate sequence, sequences with more than this number of combined mismatches and gaps will be excluded from consideration of off-target effects. Abudayyeh et al (2016) has reported that 3 or less mismatches in an off target usually result in detectable cleavage activity, resulting in a default value of 3. Note: This value can be set up to 5. 
               </ul>

               <ul><li><p><b>Maximum number of gaps tolerated by off targets:</b> Relative to the target candidate sequence, sequences with more than this number of gaps will be excluded from consideration of off-target effects. Currently, there is no research about gaps, resulting in a default value of 0. 
               </ul>

               <ul><li><p><b>Maximum total number of mismatches and gaps in the seed region tolerated by off targets:</b> Relative to the target candidate sequence, sequences with more than this number of combined mismatches and gaps in the seed region will be excluded from consideration of off-target effects. As a general rule, mismatches and gaps are poorly tolerated in the seed region, so this number should be low. Abudayyeh et al (2016) has reported that single mismatches in the seed region can be fully tolerated by C2c2, but if double mismatches are located in the seed region, C2c2 is unable to cleave the single strand RNA, resulting in a default value of 1.
               </ul>

               <ul><li><p><b>Maximum number of gaps in the seed region tolerated by off targets:</b> Relative to the target candidate sequence, sequences with more than this number of gaps in the seed region will be excluded from consideration of off-target effects. Currently, there is no research about gaps, resulting in a default value of 0.  
               </ul>

               <ul><li><p><b>Maximum number of consecutive mismatches or gaps in the seed region tolerated by off targets:</b> Relative to the target candidate sequence, sequences with more than this number of consecutive combined mismatches or gaps in the seed region will be excluded from consideration of off-target effects. Abudayyeh et al (2016) has reported that single mismatches in the seed region can be fully tolerated by C2c2, but if double consecutive mismatches are located in the seed region, C2c2 is unable to cleave the single strand RNA, resulting in a default value of 1.   
               </ul>

               <ul><li><p><b>Maximum number of consecutive mismatches or gaps in the non-seed region tolerated by off targets:</b> Relative to the target candidate sequence, sequences with more than this number of consectuive combined mismatches or gaps in the non-seed region will be excluded from consideration of off-target effects. Abudayyeh et al (2016) has reported that C2c2 is even tolerant to triple consecutive mismatches in the non-seed region (3' or 5' ends), resulting in a default value of 3.
               </ul>
         </ul>
    
         <ul><li><p>Specific settings
               <ul><li><p><b>Maximum number of mismatches in the seed region tolerated by off targets:</b> Relative to the target candidate sequence, sequences with more than this number of mismatches in the seed region will be excluded from consideration of off-target effects. As a general rule, mismatches are poorly tolerated in the seed region, so this number should be low. Abudayyeh et al (2016) has reported that single mismatches in the seed region can be fully tolerated by C2c2, but if double mismatches are located in the seed region, C2c2 is unable to cleave the single strand RNA, resulting in a default value of 1.

               </ul>

               <ul><li><p><b>Maximum number of insertions in the seed region tolerated by off targets:</b> Relative to the target candidate sequence, sequences with more than this number of insertions in the seed region will be excluded from consideration of off-target effects. Currently, there is no research about insertions, resulting in a default value of 0. 

               </ul>

               <ul><li><p><b>Maximum number of deletions in the seed region tolerated by off targets:</b> Relative to the target candidate sequence, sequences with more than this number of deletions in the seed region will be excluded from consideration of off-target effects. Currently, there is no research about deletions, resulting in a default value of 0.  

               </ul>

               <ul><li><p><b>Maximum number of consecutive mismatches or gaps in the seed region tolerated by off targets:</b> Relative to the target candidate sequence, sequences with more than this number of consecutive combined mismatches or gaps in the seed region will be excluded from consideration of off-target effects. Abudayyeh et al (2016) has reported that single mismatches in the seed region can be fully tolerated by C2c2, but if double consecutive mismatches are located in the seed region, C2c2 is unable to cleave the single strand RNA, resulting in a default value of 1.  

               </ul>

               <ul><li><p><b>Maximum number of mismatches in the non-seed region tolerated by off targets:</b> Relative to the target candidate sequence, sequences with more than this number of mismatches in the non-seed region will be excluded from consideration of off-target effects. Mismatches are, as a general rule, better tolerated in the non-seed region than the seed region. Abudayyeh et al (2016) has reported that 3 or less mismatches in an off target can be fully tolerated by C2c2 and the maximum number of mismatches in the seed region tolerated by off targets has already been set to 1, resulting in a default value of 2.  

               </ul>

               <ul><li><p><b>Maximum number of insertions in the non-seed region tolerated by off targets:</b> Relative to the target candidate sequence, sequences with more than this number of insertions in the non-seed region will be excluded from consideration of off-target effects. Currently, there is no research about insertions, resulting in a default value of 0.

               </ul>

               <ul><li><p><b>Maximum number of deletions in the non-seed region tolerated by off targets:</b> Relative to the target candidate sequence, sequences with more than this number of deletions in the non-seed region will be excluded from consideration of off-target effects. Currently, there is no research about deletions, resulting in a default value of 0.

               </ul>
 
               <ul><li><p><b>Maximum number of consecutive mismatches or gaps in the non-seed region tolerated by off targets:</b> Relative to the target candidate sequence, sequences with more than this number of consective combined mismatches or gaps in the non-seed region will be excluded from consideration of off-target effects. As a general rule, mismatches or gaps are better tolerated in the non-seed region. Abudayyeh et al (2016) has reported that C2c2 is even tolerant to triple consecutive mismatches in the non-seed region (3' or 5' ends) and the maximum number of mismatches in the non-seed region tolerated by off targets has already been set to 2, resulting in a default value of 2. 

               </ul>
         </ul>

         
     </ul>

     <ul><li><font color="black" size="3">Advanced options</font><br>
         <br>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<img src="../layout/images/Advanced.jpg" alt="Advanced options" style="width:215px;height:39px;">
         <ul><li><p><b>Search sensitivity:</b> Users can set up the search sensitivity of Bowtie2, which is related to the alignment options setting of Bowtie2, to search target sites in the reference transcriptome. Higher sensitivity setting causes alignments to be more sensitive, but it usually results in a slower search time.
         </ul>
     </ul>

     <ul><li><font color="black" size="3">Submit</font><br>
         <br>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<img src="../layout/images/submit.jpg" alt="Advanced options" style="width:138px;height:46px;">
         <ul><li><p>After setting up all the parameters, users click the “Find targets!” button which will run programs in the background to get the results. 
         </ul>
     </ul>


    

    <font id=output color="#763ca5" size="5"><b>Output of CRISPR-RT</b></font>
     <ul><li><font color="black" size="3">Target candidates and relevant information for the user input RNA sequence </font><a href="../proc/Help_example.php" target="_blank">(dynamic output example)</a> <br>
         <br>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<img src="../layout/images/result1.jpg" alt="result1" style="width:722px;height:276px;">
         <ul><li><p><b>Input Sequence Viewer:</b> Users can view the input sequence by clicking the “Input Sequence Viewer” button.<br>
             <br>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<img src="../layout/images/result1_1.jpg" alt="result1_1" style="width:722px;height:135px;">
             <ul><li><p>In the sequence viewer, users can search and highlight any subsequence such as the target candidate sequence.
            </ul>
         </ul>

         <ul><li><p><b>Job ID:</b> The “Job ID” can be used to retrieve users’ recent jobs from CRISPR-RT and the jobs will be stored for a week in our server.<br>
             
         </ul>
        
         <ul><li><p><b>Download:</b> Users can download the target candidates file by clicking the “Download” link.<br>
             
         </ul>

         <ul><li><p><b>Protospacer+PFS:</b> The protospacer sequence and PFS of each target candidate, which are labeled by different colors.<br>
             
         </ul>

         <ul><li><p><b>crRNA:</b> The corresponding crRNA of each target candidate can be accessed by clicking “crRNA”; a graph will appear to help users design their own crRNAs<br>
             <br>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<img src="../layout/images/result1_2.jpg" alt="result1_2" style="width:629px;height:542px;">
             <ul><li><p>The target complementarity sequence of crRNA is labled by purple. The stem-loop sequence of crRNA comes from  Abudayyeh et al's research. The designed crRNA binds to C2c2 to form a crRNA-C2c2 complex for RNA targeting.
             </ul>
         </ul>

         <ul><li><p><b>Start:</b> The start position of the target candidate sequence in the user input RNA sequence.<br>
             
         </ul>
         
         <ul><li><p><b>End:</b> The end position of the target candidate sequence in the user input RNA sequence.<br>
             
         </ul>

         <ul><li><p><b>GC:</b> The GC content of the target candidate sequence excluding PFS<br>
             
         </ul>
   
         <ul><li><p><b>#Targets:</b> By clicking the “#Targets” header users are able to rank all the target candidates based on the number of target sites. Target candidates with fewer number of target sites have higher target specificity in the transcriptome. If the number of target sites is 1 the corresponding table cell will be highlighted, indicating that the target candidate is highly specific in the whole transcriptome. By clicking the number of target sites users can view the detailed information of target sites for each target candidate <br>
             <br>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<img src="../layout/images/result1_3.jpg" alt="result1_3" style="width:722px;height:273px;">
             <ul><li><p>Because CRISPR-RT has converted the transcriptome mapping result to a genome mapping result, the information of target sites are displayed in genomic context with genomic coordinates and gene annotations.
             </ul>

             <ul><li><p><b>Download:</b> Users can download the target sites file for the target candidate by clicking the “Download” link.
             </ul>

             <ul><li><p><b>cDNA Seq:</b> The complementarity cDNA sequence of the target site in the transcriptome.
             </ul>

             <ul><li><p><b>Transcript ID:</b> The corresponding transcript ID of the target site in the transcriptome. Users can click the “transcript ID” link of each target site to view the detailed description of transcript where the target site located.<br>
                 <br>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<img src="../layout/images/result1_3_1.jpg" alt="result1_3_1" style="width:722px;height:305px;">
             </ul>

             <ul><li><p><b>Transcript Name:</b> The corresponding transcript name of the target site in the transcriptome.
             </ul>

             <ul><li><p><b>Gene ID:</b> The corresponding gene ID of the target site. Users can click the “gene ID” link of each target site to view the detailed description of gene where the target site located.<br>
                 <br>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<img src="../layout/images/result1_3_2.jpg" alt="result1_3_2" style="width:722px;height:448px;">
             </ul>

             <ul><li><p><b>Gene Name:</b> The corresponding gene name of the target site.
             </ul>

             <ul><li><p><b>Chr:</b> The chromosome number of the corresponding gene of the target site.
             </ul>

             <ul><li><p><b>Pos:</b> The position of the corresponding gene sequence of the target site in the chromosome.
             </ul>

             <ul><li><p><b>Str:</b> The strand of the corresponding gene of the target site in the chromosome. "+" is the forward strand; "-" is the reverse strand.
             </ul>

             <ul><li><p><b>M&G:</b> The total number of mismatches and gaps between the target complementarity region of crRNA and the target site in the transcriptome.
             </ul>

             <ul><li><p><b>M:</b> The number of mismatches between the target complementarity region of crRNA and the target site in the transcriptome.
             </ul>

             <ul><li><p><b>G:</b> The number of gaps between the target complementarity region of crRNA and the target site in the transcriptome.
             </ul>

             <ul><li><p><b>JB:</b> Users can click the “JBrowse” link to visualize each target site in the background of genome and transcript features.<br>
                 <br>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<img src="../layout/images/result1_3_3.jpg" alt="result1_3_3" style="width:722px;height:235px;">
             </ul>

         </ul>

     </ul>
    





    
  
  
</div>
<br>
</div>

</body>
</html>

<?php 
include ROOT_PATH."/layout/footer.php"; 
?>
