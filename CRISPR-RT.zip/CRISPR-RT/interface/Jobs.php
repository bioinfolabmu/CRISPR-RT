<?php 
define('ROOT_PATH','..');
include ROOT_PATH."/layout/header.php";
?>


<form name=CRISPR-RT method=POST action='../proc/retrieve.php' enctype='multipart/form-data' onsubmit="return myFunction()">
<b><p style="font-size:200%; color:#763ca5">Retrieve Jobs</p></b>

	
  
<h3>Job ID:
	<input type=text id=job name=job size=30 maxlength=50
		value=''>
	

	<div>
	<!--<input type=hidden id=acc2 name=accession value="">-->
	<p><input type=submit class=findtargetsbutton value="Retrieve!"></p>
	</div>

</form>

<script>
function myFunction() {
   
   
    
    var job = document.getElementById("job");
    var job_value = job.value;

    

    submitOK = "true";

    if (job_value == "") {
        job.style.backgroundColor = "#FF9999";
        alert("Please input a job ID!");        
        submitOK = "false";        
    }  


    if (submitOK == "false") {
        return false;
    }
}

</script>

  
         
















<?php include ROOT_PATH."/layout/footer.php"; ?>
