<?php 
include "../layout/header.php";
?>

<script type="text/javascript" src="js/inputexamplesequence.js"></script>


<form name=ct-finder method=POST action='./uploader.php' enctype='multipart/form-data'>
<b><p style="font-size:200%; color:#4D6277">Cas9 Nickase (Cas9n) System</p></b>
<h2>Step 1: Choose your reference genome</h2>
	<p>Reference genome:
	<select name=db>
		<option value=none   >Choose an organism</option>
		<option value=hg19    >Human (Homo sapiens) genome, GRCh37/hg19 (Feb, 2009)</option>
		<option value=mm10   >Mouse (Mus musculus) genome, GRCm38/mm10 (Dec, 2011)</option>
		<option value=rn5    >Rat (Rattus norvegicus) genome, RGSC 5.0/rn5 (Mar, 2012)</option>
		<option value=calJac3>Marmoset (Callithrix jacchus) genome, WUGSC 3.2/calJac3 (Mar, 2009)</option>
		<option value=susScr3>Pig (Sus scrofa) genome, SGSC Sscrofa10.2/susScr3 (Aug, 2011)</option>
		<option value=galGal4>Chicken (Gallus gallus) genome, ICGSC Gallus_gallus-4.0/galGal4 (Nov, 2011)</option>
		<option value=xenTro3>Frog (Xenopus tropicalis) genome, JGI 4.2/xenTro3 (Nov, 2009)</option>
		<option value=Xenla7 >Frog (Xenopus laevis) genome, JGI 7.1/Xenla7 (Dec, 2013)</option>
		<option value=danRer7>Zebrafish (Danio rerio) genome, Zv9/danRer7 (Jul, 2010)</option>
		<option value=ci2    >Sea squirt (Ciona intestinalis) genome, JGI 2.1/ci2 (Mar, 2005)</option>
		<option value=dm3    >Fruit fly (Drosophila melanogaster) genome, BDGP R5/dm3 (Apr, 2006)</option>
		<option value=ce10   >Roundworm (Caenorhabditis elegans) genome, WS220/ce10 (Oct, 2010)</option>
		<option value=Tair10 >Thale cress (Arabidopsis thaliana) genome, TAIR10 (Nov, 2010)</option>
		<option value=rice   >Rice (Oryza sativa) genome, Os-Nipponbare-Reference-IRGSP-1.0 (Oct, 2011)</option>
		<option value=sorBic >Sorghum (Sorghum bicolor) genome, Sorghum bicolor v2.1 (May, 2013)</option>
		<option value=bmor1  >Silkworm (Bombyx mori) genome, Bmor1 (Apr, 2008)</option>
		<option value=sacCer3>Budding yeast (Saccharomyces cerevisiae) (S288C) genome, sacCer3 (Apr, 2011)</option>
		<option value=pombe  >Fission yeast (Schizosaccharomyces pombe) (972h-) genome, ASM294v2 (Nov, 2007)</option>
	</select> 
	<span class=helper title="
     This is the organism you wish to perform genome editing on. A selection of model organisms is available; if your organism is not listed here, contact us so we may add it to the database.
     ">?</span>
	</p>
	
<h2>Step 2: Provide a genomic region to search for candidate CRISPR targets</h2>
	<p style="display:inline">Input a DNA sequence in FASTA format:
     <span class=helper title="
     Paste a single DNA sequence in FASTA format into the text field (standard DNA characters only: A, C, T, G). CT-Finder will find candidate targets within this sequence.
     ">?</span></p>
     <p style="padding-left:385px; display:inline">
     <input name="Example" class=examplebutton type="button" value="Example Sequence"
                onClick="inputexamplesequence()"/><br>
    </p>
	<textarea id=sequence name=userseq rows=15 cols=90 class=mono></textarea>

	<p>or upload a DNA sequence file:
	<span style='vertical-align:-0.4ex'>	
	</span>
	<input type=file name=userfile size=40>
	</p>
	
        <p>or enter a genome location (e.g. TAIR10_chr1:6437-7069): 
	<input type=text id=gene_location name=gene_location size=20 maxlength=100
		value=''> 
	<span style='vertical-align:-0.4ex'>
	
	</span>
	</p>
	

<h2>Step 3: Describe the guide RNA for your system</h2>
        <p>Minimum length of guide RNA (excluding the PAM sequence):
	<input type=text id=min_offset name=min_offset size=10 maxlength=3
		value='14'> 
	<span style='vertical-align:-0.4ex'>
	
	</span>
	</p>

        <p>Maximum length of guide RNA (excluding the PAM sequence):
	<input type=text id=max_offset name=max_offset size=10 maxlength=3
		value='17'> 
	<span style='vertical-align:-0.4ex'>
	
	</span>
	</p>

	<p>Target PAM sequence:
	<input type=text id=target_pam name=target_pam size=10 maxlength=20
		value='NGG'> (e.g. NGG, NRG)
	<span style='vertical-align:-0.4ex'>
	
	</span>
	</p>
        
        <p>Off-target PAM sequence:
	<input type=text id=offtarget_pam name=offtarget_pam size=10 maxlength=20
		value='NRG'> (e.g. NGG or NRG)
	<span style='vertical-align:-0.4ex'>
	
	</span>
	</p>
        
        <p>The length of the seed region:
	<input type=text id=seed_length name=seed_length size=10 maxlength=2
		value='8'> 
	<span style='vertical-align:-0.4ex'>
	
	</span>
	</p>
        
        <p>Maximum number of strands that can tolerate bulges:
	<input type=text id=num_BulgeStrand name=num_BulgeStrand size=10 maxlength=2
		value='2'> 
	<span style='vertical-align:-0.4ex'>
	
	</span>
	</p>
	
<h2>Step 4: Choose a setting</h2>

		<script type="text/javascript">
		function toggle(element) {
		    document.getElementById(element).style.display = (document.getElementById(element).style.display == "none") ? "" : "none";
		}
		</script>

        <input type="radio" name="seed_setting" value="General">&nbsp;Basic settings
        <a href="javascript:toggle('general_opt')">(show options)</a><br/>
      <div id="general_opt" style="display: none;">
      <p>&nbsp;&nbsp;&nbsp;&nbsp;Maximum number of mismatches and gaps tolerated by off targets:
	  <input type=text id=num_MisAndGap name=num_MisAndGap size=10 maxlength=1
		value='5'> 
	  <span style='vertical-align:-0.4ex'>
	
	  </span>
	  </p>
          <p>&nbsp;&nbsp;&nbsp;&nbsp;Maximum number of mismatches and gaps in seed region tolerated by off targets:
	  <input type=text id=num_seed_MisID name=num_seed_MisID size=10 maxlength=2
		value='1'> 
	  <span style='vertical-align:-0.4ex'>
	
	  </span>
	  </p></div><br/>
        
        <input type="radio" name="seed_setting" value="Specific">&nbsp;Specific settings
        <a href="javascript:toggle('specific_opt')">(show options)</a>
        <div id="specific_opt" style="display: none;">
        <h4>Seed region</h4>
          <p>&nbsp;&nbsp;&nbsp;&nbsp;Maximum number of mismatches in seed region tolerated by off targets:
	  <input type=text id=seed_mismatch name=seed_mismatch size=10 maxlength=1
		value='1'> 
	  <span style='vertical-align:-0.4ex'>
	
	  </span>
	  </p>
          <p>&nbsp;&nbsp;&nbsp;&nbsp;Maximum number of insertions in seed region tolerated by off targets:
	  <input type=text id=seed_insertion name=seed_insertion size=10 maxlength=1
		value='0'> 
	  <span style='vertical-align:-0.4ex'>
	
	  </span>
	  </p>
          <p>&nbsp;&nbsp;&nbsp;&nbsp;Maximum number of deletions in seed region tolerated by off targets:
	  <input type=text id=seed_deletion name=seed_deletion size=10 maxlength=1
		value='0'> 
	  <span style='vertical-align:-0.4ex'>
	
	  </span>
	  </p>
	  
	  <h4>Non-seed region</h4>
          <p>&nbsp;&nbsp;&nbsp;&nbsp;Maximum number of mismatches in non-seed region tolerated by off targets:
	  <input type=text id=nonseed_mismatch name=nonseed_mismatch size=10 maxlength=1
		value='2'> 
	  <span style='vertical-align:-0.4ex'>
	
	  </span>
	  </p>
          <p>&nbsp;&nbsp;&nbsp;&nbsp;Maximum number of insertions in non-seed region tolerated by off targets:
	  <input type=text id=nonseed_insertion name=nonseed_insertion size=10 maxlength=1
		value='1'> 
	  <span style='vertical-align:-0.4ex'>
	
	  </span>
	  </p>
          <p>&nbsp;&nbsp;&nbsp;&nbsp;Maximum number of deletions in non-seed region tolerated by off targets:
	  <input type=text id=nonseed_deletion name=nonseed_deletion size=10 maxlength=1
		value='1'> 
	  <span style='vertical-align:-0.4ex'>
	
	  </span>
	  </p></div><br/><br/>

	<div>
	<input type=hidden id=acc2 name=accession value="">
	<p><input type=submit class=findtargetsbutton value='Find optimal targets!'></p>
	</div>

</form>

<?php 

include "../layout/footer.php";

 ?>
