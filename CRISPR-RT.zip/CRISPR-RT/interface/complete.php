<?php 
$forceBread="Results";
session_start();
$_SESSION['fileName'] = $_GET['name'];
$_SESSION['projectName']=$_GET['project_name'];
include("../layout/header.php"); 

?>

Your data processing is just finished. <br/><br/>

You can examine the result through: <br/><br/>
(1) Seqviewer: <br/><br/>
     <ul>
     <li><a href="../webseqviewer/modules/fastaFile/index.php?switchTag=norm&projectname=<?php echo $_SESSION["projectName"]?>">Normal</a> <br/></li>
     <li><a href="../webseqviewer/modules/fastaFile/index.php?switchTag=revc&projectname=<?php echo $_SESSION["projectName"]?>">Reverse Complement</a> <br/></li>
     </ul>
(2) <a href="ssrview.php?data=<?php echo $_SESSION["projectName"]?>/<?php echo $_SESSION["fileName"]?>_ssr.json">Data Grid Viewer</a><br/><br/>
     <ul>
     <li><a href="ssrview.php?switchTag=norm&data=<?php echo $_SESSION["projectName"]?>/seq_norm/<?php echo $_SESSION["fileName"]?>_ssr.json">Normal</a> <br/></li>
     <li><a href="ssrview.php?switchTag=revc&data=<?php echo $_SESSION["projectName"]?>/seq_revc/<?php echo $_SESSION["fileName"]?>_ssr.json">Reverse Complement</a> <br/></li>
     </ul>

If you want to retrieve your data in the future, please write down your project name: <font color="red"><?php echo $_GET["project_name"]?></font>.<br/><br/>

To retrieve your previous data, please click the menu item "Retrieve Project". Warning: we only keep users' data in our server for a week! <br><br/>

<?php include("../layout/footer.php"); ?>


