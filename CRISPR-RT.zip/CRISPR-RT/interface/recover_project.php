<?php 
session_start();
$project_name="";
$success=false;
if(isset($_POST["project_name"])&&$_POST["project_name"]!=""){
	$project_name=trim($_POST["project_name"]);
	$_SESSION['projectName']=$project_name;
	$dir = "../upload/$project_name/";
	if (is_dir($dir)) {
	    if ($dh = opendir($dir)) {
	        while (($file = readdir($dh)) !== false) {
	        	if(pathinfo($file, PATHINFO_EXTENSION)=="fasta"){
					$_SESSION['fileName']=basename($file, ".fasta");
					break;
				}
			}
		}
		$success=true;
	}
	else{
		$errorMessage= "<font color='red'><strong>Error: Project doesn't exist</font><br>";	
	}
		
}
else{
	//$errorMessage= "<font color='red'><strong>Error: Please enter a Project ID</font><br>";	
	
}
include("../layout/header.php"); 
if(isset($_POST["project_name"])&&$success){
?>
<script type="text/javascript">
var installationPath="/var/www/webssr/";
var projectname="<?php echo $_SESSION["projectName"]?>";
var nameBase="<?php echo $_SESSION["fileName"]?>";

window.onload=function(){
	if(projectname!=""){
		var xhrPostArgs2 = {
			url:"../webseqviewer/configuration/overallConfigGen.php",
			content:{file: installationPath+"upload/"+projectname+"/"+nameBase+".fasta", 
					 maxSeq_FASTA: 10, 
					 file_gffType: "file", 
					 file_gffFile: installationPath+"upload/"+projectname+"/"+nameBase+"_ssr.gff"},
			load: function(txt){},
			error:function(){alert("Tabix has failed for  "+filename+". Please make sure file is in GFF Format.")},
			handleAs: "text",
			preventCache:true,
			sync:false
		};
		var deferred2 = dojo.xhrPost(xhrPostArgs2);
	}
};
</script>
<font color="green"><b>Project Successfully Recovered</b></font>
<p>
Please keep the following Project ID for your records: <?php echo $_POST["project_name"]?>

<?php
}else{
	
	echo $errorMessage;
?>
<p>
<form action="recover_project.php" method="post">
	<label>Project ID: </label> <input type="text" name="project_name">
	<input type="submit" value="Submit">
</form>
<?php
}
 include("../layout/footer.php"); ?>
