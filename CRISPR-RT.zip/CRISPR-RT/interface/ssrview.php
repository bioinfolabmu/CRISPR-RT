<?php 
include "../layout/header.php" ?>
<script type="text/javascript">
	dojo.require("dojo.parser");
    dojo.require("dijit.form.NumberTextBox");
    dojo.require("dijit.form.TextBox");
	dojo.require("dojox.grid.EnhancedGrid");  
	dojo.require("dojox.grid.enhanced.plugins.Pagination"); 
	dojo.require("dojo.data.ItemFileReadStore");
	dojo.require("dojox.grid.enhanced.plugins.Filter");
	dojo.require("dojox.grid.enhanced.plugins.exporter.CSVWriter");
	dojo.require("dojox.grid.enhanced.plugins.Printer");
	dojo.require("dojox.grid.enhanced.plugins.Cookie");
	dojo.require("dijit.Tooltip");
</script>
<title>Repeat Viewer</title>
<style type="text/css">
    @import "../libraries/dojox/grid/enhanced/resources/claro/EnhancedGrid.css";
    @import "../libraries/dojox/grid/enhanced/resources/EnhancedGrid_rtl.css";
</style>

<style>

#gridId { 
    border: 1px solid #333;
    margin: 10px;
    width: 82%;
    font-size: 1em;
    font-family: Geneva, Arial, Helvetica, sans-serif;
}

.pos_top{
    position:relative;
    top:10px;
    left:10px;
}
a {color:#5fb28a;text-decoration:none; }

</style>
<script>
	var ssrFile = "<?php echo $_GET['data'];?>";
</script>
<script type="text/javascript" src="../javascript/ssrview.js"></script>
<!--<div id="search">
	<b>Sequence</b>
	<input id="sequence" name="sequence" type="text" 
	dojoType="dijit.form.TextBox" value="t3352.cdna.v1.contig1" readonly="true" style="background-color:#dcffd1;"/>
</div>-->
<strong style="color:#236E6E">Project Name: <?php echo $_SESSION['projectName']?></strong>
<div>
<img src="../images/excelIcon.gif" id="gridExport" name="export" class="pos_top"/>
<img src="../images/print-preview.png" width="16" height="16" id="gridPreview" name="preview" class="pos_top"/>
<img src="../images/printer.png" width="16" height="16" id="gridPrint" name="print" class="pos_top"/>
<div jsId="gridId" id="gridId" dojoType="dojox.grid.EnhancedGrid"  plugins="{pagination:{pageSizes:['5','10', '25', '50', '100', 'All'],gotoButton:true}, filter: true, exporter: true, printer: true, cookie: true}" query="{ ID: '*' }" autoheight=true store="dataStore"  structure="layout" escapeHTMLInDatarow=false Selector="20px"></div>
<input id="userIp" type="hidden" name="userIp" value="<?php echo $_SERVER['REMOTE_ADDR'];?>"/>
</div>
<?php include "../layout/footer.php" ?>
