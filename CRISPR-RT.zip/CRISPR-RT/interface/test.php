<?php 
define('ROOT_PATH','..');
include ROOT_PATH."/layout/header.php"; 
?>

Test page

<?php 
include ROOT_PATH."/layout/footer.php"; 
?>
