<?php
  $log_file_name = 'TranscriptomeToAdd.txt'; 
  $date=date('Y-m-d').PHP_EOL;
  $genome = $_POST['genome'].PHP_EOL; // incoming message
  //$genome_db = $_POST['genome_db'].PHP_EOL; // incoming message
  $name = $_POST['name'].PHP_EOL;
  $email = $_POST['email'].PHP_EOL.PHP_EOL;
  file_put_contents($log_file_name, $date, FILE_APPEND);
  file_put_contents($log_file_name, $genome, FILE_APPEND);
  //file_put_contents($log_file_name, $genome_db, FILE_APPEND);
  file_put_contents($log_file_name, $name, FILE_APPEND);
  file_put_contents($log_file_name, $email, FILE_APPEND);
  //header('Location: ../index.php'); // redirect back to the main site
?>

<html>
<body>

We will add this transcriptome for you as soon as possible! Thank you!

</body>
</html>
