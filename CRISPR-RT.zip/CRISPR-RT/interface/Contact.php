<?php 
define('ROOT_PATH','..');
include ROOT_PATH."/layout/header.php"; 
?>
<br>
<font id=input color="#763ca5" size="5"><b>Contact Us</b></font>
<p><font color="black" size="3">Please email us if you have any suggestions or comments about CRISPR-RT.</font></p>
Houxiang Zhu<br>

E-mail: <a href="mailto:zhuh4@miamioh.edu">zhuh4@miamioh.edu</a><br><br>

Chun Liang<br>

E-mail: <a href="mailto:liangc@miamioh.edu">liangc@miamioh.edu </a><br>

Lab: <a href="http://bioinfolab.miamioh.edu" target="_blank">http://bioinfolab.miamioh.edu </a>
<?php 
include ROOT_PATH."/layout/footer.php"; 
?>
