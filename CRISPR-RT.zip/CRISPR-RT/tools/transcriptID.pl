#! /usr/bin/perl -w
use strict;

my $gtf_file=shift;

my $out="TranscriptID.txt";
open(OUT,">$out");

print OUT "transcript_id\ttranscript_name\tgene_id\tgene_name\n";

open(IN,"<$gtf_file") or die "Can't open file: $gtf_file\n";

while (my $line=<IN>) {
      chomp($line);
      $line =~ s/\r$//;
      if($line =~ /^#/){
                   
      }else{
         my @array=split(/\t/,$line);
         if ($array[2] eq 'transcript'){

             my $transcript_id = '';
             my $transcript_name = '';
             my $gene_id = '';
             my $gene_name = '';

             if ($array[8] =~ /transcript_id\s\"(\S+)\"/ ){
                 $transcript_id = $1;
             }else{
                 $transcript_id = "N/A";
             }

             if ($array[8] =~ /transcript_name\s"(\S+)"/ ){
                 $transcript_name = $1;
             }else{
                 $transcript_name = "N/A";
             }

             if ($array[8] =~ /gene_id\s\"(\S+)\"/ ){
                 $gene_id = $1;
             }else{
                 $gene_id = "N/A";
             }

             if ($array[8] =~ /gene_name\s\"(\S+)\"/ ){
                 $gene_name = $1;
             }else{
                 $gene_name = "N/A";
             }

             print OUT "$transcript_id\t$transcript_name\t$gene_id\t$gene_name\n";
        
    

         }

                   
                    
      }

}
              

close IN;
close OUT;

