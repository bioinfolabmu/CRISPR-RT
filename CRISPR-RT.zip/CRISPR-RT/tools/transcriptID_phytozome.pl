#! /usr/bin/perl -w
use strict;

my $gff_file=shift;

my $out="TranscriptID.txt";
open(OUT,">$out");

print OUT "transcript_id\ttranscript_name\tgene_id\tgene_name\n";

open(IN,"<$gff_file") or die "Can't open file: $gff_file\n";

while (my $line=<IN>) {
      chomp($line);
      $line =~ s/\r$//;
      if($line =~ /^#/){
                   
      }else{
         my @array=split(/\t/,$line);
         if ($array[2] eq 'mRNA'){

             my $transcript_id = '';
             my $transcript_name = 'N/A';
             my $gene_id = '';
             my $gene_name = 'N/A';

             my @array_ID = split(/;/, $array[8]);
             


             if ($array_ID[0] =~ /ID=(.+)/ ){
                 $transcript_id = $1;
             }else{
                 $transcript_id = "N/A";
             }

             
             if ($array_ID[$#array_ID] =~ /Parent=(.+)/){
                 $gene_id = $1;
             }else{
                 $gene_id = "N/A";
             }

             

             print OUT "$transcript_id\t$transcript_name\t$gene_id\t$gene_name\n";
        
    

         }

                   
                    
      }

}
              

close IN;
close OUT;

