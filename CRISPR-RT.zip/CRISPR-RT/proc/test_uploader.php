<?php

$output =shell_exec("/home/peil/anaconda2/bin/python2.7 rs2_score_calculator.py --seq TCGATGATCTCGAGTTTAAAGAAGCGGAAA");
#$output =shell_exec("/home/peil/anaconda2/bin/python2.7 testpython.py");
echo "<pre>$output</pre>";

?>
