<?php
include_once '../root_path.php';
define('ROOT_PATH','..');

$mode_name = $_POST['mode_name']; 
$userseq = $_POST['userseq']; 
$userseq = strtoupper($userseq);  
$userseq = strtr($userseq, "T", "U"); //REVIEW8

$db = $_POST['db']; 

$min_offset = $_POST['min_offset']; 
$max_offset = $_POST['max_offset']; 
$target_pfs = $_POST['target_pfs']; 
$target_pfs = strtoupper($target_pfs);
$target_pfs_length = strlen($target_pfs);
$offtarget_pfs = $_POST['offtarget_pfs']; 
$offtarget_pfs = strtoupper($offtarget_pfs);
$gRNA_length = $_POST['gRNA_length']; 
$seed_length = $_POST['seed_length']; 

$radio = $_POST['seed_setting']; 

$num_MisAndGap = $_POST['num_MisAndGap'];
$num_Gap = $_POST['num_Gap'];  //ADD
$num_seed_MisID = $_POST['num_seed_MisID']; 
$num_seed_Gap = $_POST['num_seed_Gap']; //ADD 
$num_seed_consec = $_POST['num_seed_consec']; //ADD 
$num_nonseed_consec = $_POST['num_nonseed_consec']; //ADD 


$num_BulgeStrand = $_POST['num_BulgeStrand']; 


$seed_mismatch = $_POST['seed_mismatch']; 
$seed_insertion = $_POST['seed_insertion']; 
$seed_deletion = $_POST['seed_deletion']; 
$num_seed_consec_specific = $_POST['num_seed_consec_specific']; 


$nonseed_mismatch = $_POST['nonseed_mismatch']; 
$nonseed_insertion = $_POST['nonseed_insertion']; 
$nonseed_deletion = $_POST['nonseed_deletion']; 
$num_nonseed_consec_specific = $_POST['num_nonseed_consec_specific']; 

$sensitivity = $_POST['sensitivity']; 

$jbowse_data_path = JBROWSE_DATA_PATH;

$random_num = mt_rand(0, 100);

$nameOfFolder=$mode_name."_".$db."_".date("mdy_His")."_".$random_num; #the name of user upload foler
########make new directory permission seeting!!!very important!!!!!!!!!!!!!!!!!!!!!!!!! 
$oldmask = umask(0); 
mkdir(JBROWSE_USERDATA_PATH.$nameOfFolder,0777, true);
umask($oldmask);
#########
$uploaddir =JBROWSE_USERDATA_PATH.$nameOfFolder."/";
$uploaddir_relative = JBROWSE_USERDATA_RELATIVE_PATH.$nameOfFolder."/";
session_start();
$_SESSION["a"] = $uploaddir;

$filename='';
if($userseq != ''){    #get user input RNA sequence
   $uploadfile = $uploaddir."userseq.fa"; 
   file_put_contents ( $uploadfile , $userseq );
   $filename="userseq.fa";
}

####Creat a file for use of retriving jobs
$retrive_job_file = $uploaddir."retrive_job.txt";
$retrive_job_file_content = $target_pfs_length."\t".$db;
file_put_contents ( $retrive_job_file , $retrive_job_file_content); 
#########################################
system("perl query_seq.pl $uploaddir $filename");#invoke perl to generate query sequence;


######??????????????????????????
system('bowtie2 -x ../bowtie2db/'.$db.'/'.$db.' --score-min L,0,0 -f '.$uploaddir.$filename.' -S '.$uploaddir.'userseq_alignment.sam');
################################

#echo "perl main.pl $mode_name $radio $jbowse_data_path $min_offset $max_offset $uploaddir $filename $target_pfs $offtarget_pfs $db $num_MisAndGap $num_Gap $seed_length $num_seed_MisID $num_seed_Gap $num_seed_consec $num_nonseed_consec $num_BulgeStrand $gRNA_length $seed_mismatch $seed_insertion $seed_deletion $num_seed_consec_specific $nonseed_mismatch $nonseed_insertion $nonseed_deletion $num_nonseed_consec_specific $sensitivity";  
$num_candidate_string = `perl main.pl $mode_name $radio $jbowse_data_path $min_offset $max_offset $uploaddir $filename $target_pfs $offtarget_pfs $db $num_MisAndGap $num_Gap $seed_length $num_seed_MisID $num_seed_Gap $num_seed_consec $num_nonseed_consec $num_BulgeStrand $gRNA_length $seed_mismatch $seed_insertion $seed_deletion $num_seed_consec_specific $nonseed_mismatch $nonseed_insertion $nonseed_deletion $num_nonseed_consec_specific $sensitivity`; #invoke main.pl  
   
preg_match('/^(\d+)/', $num_candidate_string, $num_candidate_array);

$num_candidate=$num_candidate_array[1];

##echo "$num_candidate";

       
?>

<html>
  <head>
    <link href="<?php echo ROOT_PATH.'/layout/css/help.css'?>" rel="stylesheet" type="text/css">
    <link href="./tableview/layout.css" rel="stylesheet" type="text/css" /> 
    <!--<link href="https://cdn.datatables.net/1.10.8/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css" />-->
    <!--<link href="https://cdn.datatables.net/1.10.7/css/jquery.dataTables.css" rel="stylesheet" type="text/css" />-->
    <link href="https://code.jquery.com/ui/1.11.3/themes/smoothness/jquery-ui.css" rel="stylesheet" type="text/css" />	
   <link href="https://cdn.datatables.net/1.10.8/css/dataTables.jqueryui.min.css" rel="stylesheet" type="text/css" />
    <script src="https://code.jquery.com/jquery-1.11.3.min.js" type="text/javascript"></script>
    <script src="https://cdn.datatables.net/1.10.8/js/jquery.dataTables.min.js" type="text/javascript"></script>
    <script src="https://cdn.datatables.net/1.10.8/js/dataTables.jqueryui.min.js" type="text/javascript"></script>

    <script src="https://cdn.datatables.net/plug-ins/1.10.9/sorting/natural.js" type="text/javascript"></script>

  </head>
  <body>
    <a href="./seqview/seqview.php?directory=<?php echo $uploaddir ?>" target="_blank"><button>Input Sequence Viewer</button></a>

    &nbsp&nbsp&nbsp&nbspJob ID: <?php echo $nameOfFolder;?>
    <span class=helper title="
      Users can retrieve the recent job data by entering the Job ID in the &quot;Retrieve Jobs&quot; tab of CRISPR-RT home page. Results will be kept for 7 days after your initial submission.
    ">?</span>

  <a href="<?php echo $uploaddir_relative ?>Candidates_Offtargets.txt" download="Candidate_Targets.txt" style="float:right">Download</a>


    <br>
    </br>
          
    <div id='target'> 	    	    
    </div>


    <br>
    </br>
    
    <div id='content'> 	    	    
    </div>
    
   
  <script type="text/javascript">

var name_mode = "<?php echo $mode_name;?>";
var num_candidate= "<?php echo $num_candidate;?>";


if (name_mode == "C2c2" && num_candidate != 0 ){

  $('#target').html('<table id="example" class="display" width="100%" cellspacing="0" style="font-family: monospace;">'+
        '<thead>'+
            '<tr>'+                
                '<th data-toggle="tooltip" title="  Number">No</th>'+
                '<th data-toggle="tooltip" title="  The target candidate sequence including the protospacer sequence and PFS.\x0A  Direction is from 5' +'\''+ ' to 3' +'\''+ '.">Protospacer+PFS</th>'+
                '<th data-toggle="tooltip" title="  The start position of the target candidate sequence in the user input RNA sequence.">Start</th>'+
                '<th data-toggle="tooltip" title="  The end position of the target candidate sequence in the user input RNA sequence.">End</th>'+
                '<th data-toggle="tooltip" title="  The GC content of the target candidate sequence excluding PFS.">GC</th>'+
                '<th data-toggle="tooltip" title="  The number of transcript target sites in the whole transcriptome for the target candidate.">#Transcript_Targets</th>'+
                '<th data-toggle="tooltip" title="  The number of gene target sites for the target candidate.">#Gene_Targets</th>'+
                
            '</tr>'+
        '</thead>'+
 
        
  '</table>');  
/*
/////////////////////////function format() --- child/////////////////////

  function C2c2_format ( d, column) {
    // `d` is the original data object for the row
    if (column == 5){ 
      var child_dir = "<?php echo $uploaddir_relative;?>";
      var child_file = child_dir + "Candidate" + d.No + "_offtargets_DataTable.txt";

      $('#content').html('<table id="child" class="display" width="100%" cellspacing="0" style="font-family: monospace;">'+
                       '<thead>'+
                          '<tr>'+
                          //  '<th></th>'+
                            '<th data-toggle="tooltip" title="  Identification Number">ID</th>'+
                            '<th data-toggle="tooltip" title="  Nucleotide sequence of potential target site including PAM sequence. Reverse-complemented if aligned to the reverse strand. ">Seq</th>'+
                            '<th data-toggle="tooltip" title="  Chromosome number of potential target site">Chr</th>'+
                            '<th data-toggle="tooltip" title="  Position of potential target site in the chromosome">Pos</th>'+
                            '<th data-toggle="tooltip" title="  Strand of potential target site.\x0A  + is forward strand.\x0A  - is the reverse strand.">Str</th>'+
                            '<th data-toggle="tooltip" title="  The total number of mismatches and gaps between potential target site (except PAM sequence) and gRNA">M&G</th>'+
                            '<th data-toggle="tooltip" title="  The number of mismatches between potential target site (except PAM sequence) and gRNA">M</th>'+
                            '<th data-toggle="tooltip" title="  The number of gaps between potential target site (except PAM sequence) and gRNA">G</th>'+                            
                            '<th data-toggle="tooltip" title="  View potential target site sequence by JBrowse">JB</th>'+
                          '</tr>'+
                       '</thead>'+
            '</table>');
  
	  


		 
      // `d` is the original data object for the row
      $(document).ready(function() {               
         var childtable = $('#child').DataTable( {
          "lengthMenu": [ [5, 10, 25, -1], [5, 10, 25, "All"] ],
          "language": {
            "lengthMenu": "Target Sites _MENU_ per page <span class=helper title=\"    The target sites include on-target and off-target sites in the whole genome.\x0A    Click JB to see visualization of target sites by JBrowser.\x0A    Sort each column by clicking the column header\">?</span>"
            
          },
          "ajax": child_file,
          columnDefs: [
             { type: 'natural', targets: 2 }
          ],
          "columns": [
            
              { "data": "ID" },
              { "data": "Sequence" },
              { "data": "Chromosome" },
              { "data": "Position" },
              { "data": "Strand" },
              { "data": "Mis&Gap" },
              { "data": "Mis" },
              { "data": "Gap" },            
              { "data": "JBrowser", 
                "fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
                    var chr=oData.Chromosome;
                    var start=oData.Position;
                    var end= Number(oData.Position)+55;
                    $(nTd).html('<a href="<?php echo JBROWSE_RELATIVE_PATH?>?data=data%2FuserData%2F<?php echo $nameOfFolder?>&loc=' + chr + '%3A'+ start + '..' + end + '" target="_blank">' + oData.JBrowser + '</a>');
                 }

              }
          ],
          "order": [[0, 'asc']]
         } );
      } );

    }
  }

*/
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

  var dir = "<?php echo $uploaddir_relative;?>";
  var file = dir + "Candidates_Offtargets_DataTable.txt";


  $(document).ready(function() {
    
    var table = $('#example').DataTable( {
        
        "aoColumnDefs": [
                {
                    "aTargets": [5], // the column with num_targets
                    "fnCreatedCell": function(nTd, sData, oData, iRow, iCol)
                    {

                        //$(nTd).html('<a href="#">' + sData + '</a>');
                        var Candidate_ID=oData.No;
                        var uploaddir_relative="<?php echo $uploaddir_relative;?>";
                        var nameOfFolder="<?php echo $nameOfFolder;?>";
                        var upload_dir="<?php echo $uploaddir;?>";
                        var db="<?php echo $db;?>";
                        $(nTd).html("<a style='color:blue' href='target_sites.php?Candidate_ID="+Candidate_ID+"&uploaddir_relative="+uploaddir_relative+"&nameOfFolder="+nameOfFolder+"&upload_dir="+upload_dir+"&db="+db+"' target='_blank'>"+oData.num_targets+"</a>"); 
         
                       
                        if(sData == 1)
                        {
                            $(nTd).css('background-color', '#DFF2BF'); // You can use hex code as well
                        }
                        
                        

 
                    },                   
                },
                

                {
                    "aTargets": [6], // the column with gene_targets
                    "fnCreatedCell": function(nTd, sData, oData, iRow, iCol)
                    {

                        //$(nTd).html('<a href="#">' + sData + '</a>');
                        //var Candidate_ID=oData.No;
                        //var uploaddir_relative="<?php echo $uploaddir_relative;?>";
                        //var nameOfFolder="<?php echo $nameOfFolder;?>";
                        //var upload_dir="<?php echo $uploaddir;?>";
                        //var db="<?php echo $db;?>";
                        //$(nTd).html("<a style='color:blue' href='target_sites.php?Candidate_ID="+Candidate_ID+"&uploaddir_relative="+uploaddir_relative+"&nameOfFolder="+nameOfFolder+"&upload_dir="+upload_dir+"&db="+db+"' target='_blank'>"+oData.num_targets+"</a>"); 
         
                       
                        if(sData == 1)
                        {
                            $(nTd).css('background-color', '#DFF2BF'); // You can use hex code as well
                        }
                        
                        

 
                    },                   
                },

                {
                    "aTargets": [1], // The column with the Protospacer+PFS
                    "fnCreatedCell": function(nTd, sData, oData, iRow, iCol)
                    {
                            
                            var seq=oData.gRNA;
                            var res = seq.split(""); 
                            var index;
                            var gRNA='';
                            var PFS='';
                            
                            for	(index = 0; index < res.length-<?php echo $target_pfs_length ?>; index++) {
                              gRNA += res[index];
                            } 
                            for (index = res.length-<?php echo $target_pfs_length ?>; index < res.length; index++) {                             PFS += res[index];
                            } 
                           // $(nTd).html("<p>"+gRNA+"<span style='color:blue'>"+PFS+"</span></p>"); 
                        
                            //$(nTd).html("<p>"+"<span style='color:purple'>"+gRNA+"</span>"+"<span style='color:red'>"+PFS+"</span>"+"   ["+"<a style='color:blue' href='crRNA_design.php' target='_blank'>"+"crRNA"+"</a>"+"]"+"</p>"); 
                           $(nTd).html("<p>"+"<span style='background-color: #ccffff'>"+gRNA+"</span>"+"<span style='color:#fe7032'><b>"+PFS+"</b></span>"+"   <font color='#3399ff'>[</font>"+"<a style='color:#3399ff' href='crRNA_design.php?seq="+seq+"&gRNA="+gRNA+"&PFS="+PFS+"' target='_blank'>"+"crRNA"+"</a>"+"<font color='#3399ff'>]</font>"+"</p>"); 
                           

 
                    },                   
                },

               
                { "aDataSort": [ 4, 5 ], "aTargets": [ 4 ] },
                { "aDataSort": [ 5, 4 ], "aTargets": [ 5 ] }


       ],

        "lengthMenu": [ [10, 25, 50, -1], [10, 25, 50, "All"] ],
        "language": {
            "lengthMenu": " Target Candidates _MENU_ per page <span class=helper title=\"    The Target Candidates are all the possible sites that crRNAs can target in the user input RNA sequence.\x0A    Sort each column by clicking the column header\">?</span>"
            
        },

        "ajax": file,
        "columns": [
        
            { "data": "No" },
            { "data": "gRNA" },
            { "data": "gRNA_start" },
            { "data": "gRNA_end" },
            { "data": "GC" },
            { "data": "num_targets"},
            { "data": "num_genes"},
            
            
        ],
        "order": [[0, 'asc']]
    } );
     
    
      $('#example tbody').on('click', 'td', function () {
       // var tr = $(this).closest('tr');
      //  var row = table.row( tr );
       // var columnID = table.cell(this).index().column;
        var rowId = table.cell(this).index().row;
        var row = table.row( rowId );

        var column_ID = table.cell(this).index().column;

        


 
        if ( row.child.isShown() ) {
            // This row is already open - close it
            row.child.hide();
     //       tr.removeClass('shown');
        }
        else {
           
          //if(column_ID == 5){  
               
          //     var Candidate_ID=row.data().No;
          //     var uploaddir_relative="<?php echo $uploaddir_relative;?>";
          //     var nameOfFolder="<?php echo $nameOfFolder;?>";
         //      var upload_dir="<?php echo $uploaddir;?>";
          //     var db="<?php echo $db;?>";
          //     var windowReference = window.open();

            
          //     $.ajax({
          //             type: "POST",
         //              url: "target_sites.php",
         //              data: { CandidateID: Candidate_ID, columnID: column_ID, UploaddirRelative: uploaddir_relative, NameFolder: nameOfFolder, uploaddir: upload_dir, ref_genome: db },
          //             success: function() {
                              
                              
          //                    windowReference.location = 'target_sites.php';
          //             }
          //     })

         //  }
        }
      } );
  } );


}

else if (name_mode == "Cas9n" && num_candidate != 0 || name_mode == "RFNs" && num_candidate != 0) {

$('#target').html('<table id="example" class="display" width="100%" cellspacing="0" style="font-family: monospace;">'+
        '<thead>'+
            '<tr>'+                
                '<th data-toggle="tooltip" title="  Number">No</th>'+
                '<th data-toggle="tooltip" title="  Nucleotide sequence 1 of pairs candidate target including PAM sequence.\x0A  Direction is from 5 prime to 3 prime.">gRNAa+PAM</th>'+
                '<th data-toggle="tooltip" title="  GC content of candidate target sequence 1 excluding the PAM sequence">GC</th>'+
                '<th data-toggle="tooltip" title="  GC content of the 6 nucleotides closest to the PAM sequence of candidate target sequence 1">GC6</th>'+
                '<th data-toggle="tooltip" title="  Strand of candidate target sequence 1.\x0A  + is user input strand.\x0A  - is the reverse strand.">Str</th>'+
                '<th data-toggle="tooltip" title="  Start position of candidate target sequence 1 in user input sequence.">Start</th>'+
                '<th data-toggle="tooltip" title="  End position of candidate target sequence 1 in user input sequence.">End</th>'+
                '<th data-toggle="tooltip" title="  Nucleotide sequence 2 of pairs candidate target including PAM sequence.\x0A  Direction is from 5 prime to 3 prime.">gRNAb+PAM</th>'+
                '<th data-toggle="tooltip" title="  GC content of candidate target sequence 2 excluding the PAM sequence">GC</th>'+
                '<th data-toggle="tooltip" title="  GC content of the 6 nucleotides closest to the PAM sequence of candidate target sequence 2">GC6</th>'+
                '<th data-toggle="tooltip" title="  Strand of candidate target sequence 2.\x0A  + is user input strand.\x0A  - is the reverse strand.">Str</th>'+
                '<th data-toggle="tooltip" title="  Start position of candidate target sequence 2 in user input sequence.">Start</th>'+
                '<th data-toggle="tooltip" title="  End position of candidate target sequence 2 in user input sequence.">End</th>'+
                '<th data-toggle="tooltip" title="  Number of target sites in the whole genome for the pair candidate target">#Targets</th>'+
                '<th data-toggle="tooltip" title="  Number of exonic target sites in the whole genome for the candidate target">#ExonicTargets</th>'+
                '<th data-toggle="tooltip" title="  Active score of gRNAa. Only available for NGG PAM and 20-nt gRNA length settings">gRNAa_At</th>'+
                '<th data-toggle="tooltip" title="  Active score of gRNAb. Only available for NGG PAM and 20-nt gRNA length settings">gRNAb_At</th>'+
            '</tr>'+
        '</thead>'+
 
        
'</table>');  

/////////////////////////function format() --- child/////////////////////

 


function pairs_format ( d, column ) {
    // `d` is the original data object for the row
  if (column == 13){ 
     var child_dir = "<?php echo $uploaddir_relative;?>";
     var child_file = child_dir + "Candidate" + d.No + "_offtargets_DataTable.txt";

     $('#content').html('<table id="child" class="display" width="100%" cellspacing="0" style="font-family: monospace;">'+
                       '<thead>'+
                          '<tr>'+
                          //  '<th></th>'+
                            '<th data-toggle="tooltip" title="  Identification Number">ID</th>'+
                            '<th data-toggle="tooltip" title="  Nucleotide sequence 1 of potential pair target site including PAM sequence. Reverse-complemented if aligned to the reverse strand. ">Seq1</th>'+
                            '<th data-toggle="tooltip" title="  Chromosome number of sequence 1 of potential pair target site">Chr</th>'+
                            '<th data-toggle="tooltip" title="  Position of sequence 1 of potential pair target site in the chromosome">Pos</th>'+
                            '<th data-toggle="tooltip" title="  Strand of sequence 1 of potential pair target site.\x0A  + is forward strand.\x0A  - is the reverse strand.">Str</th>'+
                            '<th data-toggle="tooltip" title="  The total number of mismatches and gaps between sequence 1 of potential pair target site (except PAM sequence) and gRNA">M&G</th>'+
                            '<th data-toggle="tooltip" title="  The number of mismatches between sequence 1 of potential pair target site (except PAM sequence) and gRNA">M</th>'+
                            '<th data-toggle="tooltip" title="  The number of gaps between sequence 1 of potential pair target site (except PAM sequence) and gRNA">G</th>'+
                            '<th data-toggle="tooltip" title="  Nucleotide sequence 2 of potential pair target site including PAM sequence. Reverse-complemented if aligned to the reverse strand. ">Seq2</th>'+
                            '<th data-toggle="tooltip" title="  Chromosome number of sequence 2 of potential pair target site">Chr</th>'+
                            '<th data-toggle="tooltip" title="  Position of sequence 2 of potential pair target site in the chromosome">Pos</th>'+
                            '<th data-toggle="tooltip" title="  Strand of sequence 2 of potential pair target site.\x0A  + is forward strand.\x0A  - is the reverse strand.">Str</th>'+
                            '<th data-toggle="tooltip" title="  The total number of mismatches and gaps between sequence 2 of potential pair target site (except PAM sequence) and gRNA">M&G</th>'+
                            '<th data-toggle="tooltip" title="  The number of mismatches between sequence 2 of potential pair target site (except PAM sequence) and gRNA">M</th>'+
                            '<th data-toggle="tooltip" title="  The number of gaps between sequence 2 of potential pair target site (except PAM sequence) and gRNA">G</th>'+
                            '<th data-toggle="tooltip" title="  View potential pair target site by JBrowse">JB</th>'+
                          '</tr>'+
                       '</thead>'+
            '</table>');
  
	  


		 
    // `d` is the original data object for the row
     $(document).ready(function() {
         var childtable = $('#child').DataTable( {
          "lengthMenu": [ [5, 10, 25, -1], [5, 10, 25, "All"] ],
         
          "language": {
            "lengthMenu": "Target Sites _MENU_ per page <span class=helper title=\"    The target sites include on-target and off-target sites in the whole genome.\x0A    Click JB to see visualization of target sites by JBrowser.\x0A    Sort each column by clicking the column header\">?</span>"
            
          },
          "ajax": child_file,
          columnDefs: [
             { type: 'natural', targets: [2,9]}
          ],
          "columns": [
             // {
             //     "className":      'details-control',
             //     "orderable":      false,
             //     "data":           null,
             //     "defaultContent": ''
             // },
              { "data": "ID" },
              { "data": "Sequence_1" },
              { "data": "Chr_1" },
              { "data": "Pos_1" },
              { "data": "Str_1" },
              { "data": "M&G_1" },
              { "data": "M_1" },
              { "data": "G_1" },
              { "data": "Sequence_2" },
              { "data": "Chr_2" },
              { "data": "Pos_2" },
              { "data": "Str_2" },
              { "data": "M&G_2" },
              { "data": "M_2" },
              { "data": "G_2" },
              { "data": "JBrowser", 
                "fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
                    var chr=oData.Chr_1;
                    //var start=oData.Pos_2;
                    //var end= Number(oData.Pos_2)+55;
/////////////////////////// Modify here ////////////////////////////////////////////                 
                    var start;
                    var end;
                    if (oData.Pos_1 > oData.Pos_2){
                        start=oData.Pos_2;
                        end= Number(oData.Pos_1)+30;
                    } else {
                        start=oData.Pos_1;
                        end= Number(oData.Pos_2)+30; 
                    }

/////////////////////////////////////////////////////////////////////////////////////
                    $(nTd).html('<a href="<?php echo JBROWSE_RELATIVE_PATH?>?data=data%2FuserData%2F<?php echo $nameOfFolder?>&loc=' + chr + '%3A'+ start + '..' + end + '" target="_blank">' + oData.JBrowser + '</a>');
                 }

              }
          ],
          "order": [[0, 'asc']]
         } );
     } );
  }else if(column == 14){
     var child_dir = "<?php echo $uploaddir_relative;?>";
     var child_file = child_dir + "Candidate" + d.No + "_offtargets_exon_DataTable.txt";

     $('#content').html('<table id="child" class="display" width="100%" cellspacing="0" style="font-family: monospace;">'+
                       '<thead>'+
                          '<tr>'+
                          //  '<th></th>'+
                            '<th data-toggle="tooltip" title="  Identification Number">ID</th>'+
                            '<th data-toggle="tooltip" title="  Identification Number">GeneID</th>'+
                            '<th data-toggle="tooltip" title="  Nucleotide sequence 1 of potential pair target site including PAM sequence. Reverse-complemented if aligned to the reverse strand. ">Seq1</th>'+
                            '<th data-toggle="tooltip" title="  Chromosome number of sequence 1 of potential pair target site">Chr</th>'+
                            '<th data-toggle="tooltip" title="  Position of sequence 1 of potential pair target site in the chromosome">Pos</th>'+
                            '<th data-toggle="tooltip" title="  Strand of sequence 1 of potential pair target site.\x0A  + is forward strand.\x0A  - is the reverse strand.">Str</th>'+
                            '<th data-toggle="tooltip" title="  The total number of mismatches and gaps between sequence 1 of potential pair target site (except PAM sequence) and gRNA">M&G</th>'+
                            '<th data-toggle="tooltip" title="  The number of mismatches between sequence 1 of potential pair target site (except PAM sequence) and gRNA">M</th>'+
                            '<th data-toggle="tooltip" title="  The number of gaps between sequence 1 of potential pair target site (except PAM sequence) and gRNA">G</th>'+
                            '<th data-toggle="tooltip" title="  Nucleotide sequence 2 of potential pair target site including PAM sequence. Reverse-complemented if aligned to the reverse strand. ">Seq2</th>'+
                            '<th data-toggle="tooltip" title="  Chromosome number of sequence 2 of potential pair target site">Chr</th>'+
                            '<th data-toggle="tooltip" title="  Position of sequence 2 of potential pair target site in the chromosome">Pos</th>'+
                            '<th data-toggle="tooltip" title="  Strand of sequence 2 of potential pair target site.\x0A  + is forward strand.\x0A  - is the reverse strand.">Str</th>'+
                            '<th data-toggle="tooltip" title="  The total number of mismatches and gaps between sequence 2 of potential pair target site (except PAM sequence) and gRNA">M&G</th>'+
                            '<th data-toggle="tooltip" title="  The number of mismatches between sequence 2 of potential pair target site (except PAM sequence) and gRNA">M</th>'+
                            '<th data-toggle="tooltip" title="  The number of gaps between sequence 2 of potential pair target site (except PAM sequence) and gRNA">G</th>'+
                            '<th data-toggle="tooltip" title="  View potential pair target site by JBrowse">JB</th>'+
                          '</tr>'+
                       '</thead>'+
            '</table>');
  
	  


		 
    // `d` is the original data object for the row
     $(document).ready(function() {
         var childtable = $('#child').DataTable( {
          "lengthMenu": [ [5, 10, 25, -1], [5, 10, 25, "All"] ],
         
          "language": {
            "lengthMenu": "Exonic Target Sites _MENU_ per page <span class=helper title=\"    The target sites include on-target and off-target sites in the whole genome.\x0A    Click JB to see visualization of target sites by JBrowser.\x0A    Sort each column by clicking the column header\">?</span>"
            
          },
          "ajax": child_file,
          columnDefs: [
             { type: 'natural', targets: [2,9]}
          ],
          "columns": [
             // {
             //     "className":      'details-control',
             //     "orderable":      false,
             //     "data":           null,
             //     "defaultContent": ''
             // },
              { "data": "ID" },
              { "data": "GeneID" },
              { "data": "Sequence_1" },
              { "data": "Chr_1" },
              { "data": "Pos_1" },
              { "data": "Str_1" },
              { "data": "M&G_1" },
              { "data": "M_1" },
              { "data": "G_1" },
              { "data": "Sequence_2" },
              { "data": "Chr_2" },
              { "data": "Pos_2" },
              { "data": "Str_2" },
              { "data": "M&G_2" },
              { "data": "M_2" },
              { "data": "G_2" },
              { "data": "JBrowser", 
                "fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
                    var chr=oData.Chr_1;
                    //var start=oData.Pos_2;
                    //var end= Number(oData.Pos_2)+55;
/////////////////////////// Modify here ////////////////////////////////////////////                 
                    var start;
                    var end;
                    if (oData.Pos_1 > oData.Pos_2){
                        start=oData.Pos_2;
                        end= Number(oData.Pos_1)+30;
                    } else {
                        start=oData.Pos_1;
                        end= Number(oData.Pos_2)+30; 
                    }

/////////////////////////////////////////////////////////////////////////////////////

                    $(nTd).html('<a href="<?php echo JBROWSE_RELATIVE_PATH?>?data=data%2FuserData%2F<?php echo $nameOfFolder?>&loc=' + chr + '%3A'+ start + '..' + end + '" target="_blank">' + oData.JBrowser + '</a>');
                 }

              }
          ],
          "order": [[0, 'asc']]
         } );
     } );
  }

}


////////////////////////////////////


 
var dir = "<?php echo $uploaddir_relative;?>";
var file = dir + "Candidates_Offtargets_DataTable.txt";


$(document).ready(function() {
    
    var table = $('#example').DataTable( {
        "aoColumnDefs": [
                {
                    "aTargets": [13], // You actual column with the string 'America'
                    "fnCreatedCell": function(nTd, sData, oData, iRow, iCol)
                    {
                        $(nTd).html('<a href="#">' + sData + '</a>');
                        if(sData == 1)
                        {
                            $(nTd).css('background-color', '#DFF2BF'); // You can use hex code as well
                        }
                         
                    },                   
                },

                {
                    "aTargets": [14], // You actual column with the string 'America'
                    "fnCreatedCell": function(nTd, sData, oData, iRow, iCol)
                    {
                        $(nTd).html('<a href="#">' + sData + '</a>');
                        if(sData == 1)
                        {
                            $(nTd).css('background-color', '#DFF2BF'); // You can use hex code as well
                        }
                         
                    },                   
                },
                
                {
                    "aTargets": [1], // You actual column with the string 'America'
                    "fnCreatedCell": function(nTd, sData, oData, iRow, iCol)
                    {

                            var seq=oData.gRNAa;
                            var res = seq.split(""); 
                            var index;
                            var gRNA='';
                            var PAM='';
                           
                            for	(index = 0; index < res.length-<?php echo $target_pfs_length ?>; index++) {
                              gRNA += res[index];
                            } 
                            for (index = res.length-<?php echo $target_pfs_length ?>; index < res.length; index++) {                             PAM += res[index];
                            } 
                            $(nTd).html("<p>"+gRNA+"<span style='color:blue'>"+PAM+"</span></p>"); // You can use hex code as well
                        
                            
                        

 
                    },                   
                },

                {
                    "aTargets": [7], // You actual column with the string 'America'
                    "fnCreatedCell": function(nTd, sData, oData, iRow, iCol)
                    {

                            var seq=oData.gRNAb;
                            var res = seq.split(""); 
                            var index;
                            var gRNA='';
                            var PAM='';
                           
                            for	(index = 0; index < res.length-<?php echo $target_pfs_length ?>; index++) {
                              gRNA += res[index];
                            } 
                            for (index = res.length-<?php echo $target_pfs_length ?>; index < res.length; index++) {                             PAM += res[index];
                            } 
                            $(nTd).html("<p>"+gRNA+"<span style='color:blue'>"+PAM+"</span></p>"); // You can use hex code as well
                        
                            
                        

 
                    },                   
                },
                { "aDataSort": [ 13, 9, 8, 3, 2 ], "aTargets": [ 13 ] },
                { "aDataSort": [ 2, 3, 8, 9, 13 ], "aTargets": [ 2 ] },
                { "aDataSort": [ 3, 2, 8, 9, 13 ], "aTargets": [ 3 ] },
                { "aDataSort": [ 8, 9, 13, 3, 2 ], "aTargets": [ 8 ] },
               { "aDataSort": [ 9, 13, 8, 3, 2 ], "aTargets": [ 9 ] }


       ],


        "lengthMenu": [ [10, 25, 50, -1], [10, 25, 50, "All"] ],
        "language": {
            "lengthMenu": " Target Candidates _MENU_ per page <span class=helper title=\"    The Candidate Targets of user input sequence are all the possible sites that gRNAs can target.\x0A    Click the specific target value to view potential target sites in the whole genome for each canditate target.\x0A    Sort each column by clicking the column header\">?</span>"
            
        },
        "ajax": file,
        "columns": [
         //   {
         //       "className":      'details-control',
         //       "orderable":      false,
         //       "data":           null,
         //       "defaultContent": ''
         //   },
            { "data": "No" },
            { "data": "gRNAa" },
            { "data": "gRNAa_GC" },
            { "data": "gRNAa_GC6" },
            { "data": "gRNAa_strand" },
            { "data": "gRNAa_start" },
            { "data": "gRNAa_end" },
            { "data": "gRNAb" },
            { "data": "gRNAb_GC" },
            { "data": "gRNAb_GC6" },
            { "data": "gRNAb_strand" },
            { "data": "gRNAb_start" },
            { "data": "gRNAb_end" },
            { "data": "num_targets" },
            { "data": "num_exonic_targets" },
            { "data": "gRNAa_score" },
            { "data": "gRNAb_score" }
        ],
        "order": [[0, 'asc']]
    } );
     
    // Add event listener for opening and closing details
    //$('#example tbody').on('click', 'td.details-control', function () {
      $('#example tbody').on('click', 'td', function () {
        // var tr = $(this).closest('tr');
      //  var row = table.row( tr );
       // var columnId = table.cell(this).index().column;
        var rowId = table.cell(this).index().row;
        var row = table.row( rowId );

        var columnId = table.cell(this).index().column;

        


 
        if ( row.child.isShown() ) {
            // This row is already open - close it
            row.child.hide();
     //       tr.removeClass('shown');
        }
        else {
            // Open this row
            row.child( pairs_format(row.data(), columnId) ).show();
            //tr.addClass('shown');
        }
    } );
} );
  
}else{
    $('#target').html('There is no available target candidate for the RNA sequence you input, please try other Target PFS setting or input a new RNA sequence!'+
                       '<button onclick="goBack()">Go Back</button>');  

}
function goBack() {
    window.history.back();
}
  
  </script>
 
</body>
</html>
