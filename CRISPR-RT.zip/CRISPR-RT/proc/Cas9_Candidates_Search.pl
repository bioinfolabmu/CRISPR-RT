#! /usr/bin/perl -w
use strict;

#my $gRNAlength=20;
my $gRNAlength=shift; #changed

my %IUB=(                     #IUB code
           'G'=>'G',
           'A'=>'A',
           'T'=>'T',
           'C'=>'C',
           'R'=>'[AG]',
           'Y'=>'[CT]',
           'M'=>'[AC]',
           'K'=>'[GT]',
           'S'=>'[CG]',
           'W'=>'[AT]',
           'H'=>'[ACT]',
           'B'=>'[CGT]',
           'V'=>'[ACG]',
           'D'=>'[AGT]',
           'N'=>'[ACGT]'   
        );

my %IUB_off=(                     #IUB code
           'G'=>'G',
           'A'=>'A',
           'T'=>'T',
           'C'=>'C',
           'R'=>'AG',
           'Y'=>'CT',
           'M'=>'AC',
           'K'=>'GT',
           'S'=>'CG',
           'W'=>'AT',
           'H'=>'ACT',
           'B'=>'CGT',
           'V'=>'ACG',
           'D'=>'AGT',
           'N'=>'ACGT'   
        );

my %IUB_com=(                 #IUB complementary
           'G'=>'C',
           'A'=>'T',
           'T'=>'A',
           'C'=>'G',
           'R'=>'[TC]',
           'Y'=>'[GA]',
           'M'=>'[TG]',
           'K'=>'[CA]',
           'S'=>'[GC]',
           'W'=>'[TA]',
           'H'=>'[TAG]',
           'B'=>'[GCA]',
           'V'=>'[TGC]',
           'D'=>'[TAC]',
           'N'=>'[ACGT]'   
        );

#print "please input the gene file:\n";
my $file_dir=shift;
my $file_name=shift;
my $file=$file_dir.$file_name;
#print "please input target PAM sequence: \n";
my $targetPAM=shift;
chomp($targetPAM);
my $targetPAM_length=length($targetPAM);
#print "please input off-target PAM sequence:\n";
my $offPAM=shift;
chomp($offPAM);
my $offPAM_length=length($offPAM);

#chomp($targetPAM);


my $pam1_com=reverse $targetPAM; #e.g. GGN
my @array_pam1=split(//,$pam1_com);
my $pam1='';
for (my $i=0;$i<=$#array_pam1;$i++){     #get pam1 CCN
    $pam1=$pam1.$IUB_com{$array_pam1[$i]};

}

#print "pam1:$pam1\n";

my @array_pam2=split(//,$targetPAM);
my $pam2='';
for (my $i=0;$i<=$#array_pam2;$i++){    #get pam2 NGG
    $pam2=$pam2.$IUB{$array_pam2[$i]};

}
#print "pam2:$pam2\n";

open(INPUT,"<$file") or die "Cant't open file: $file\n";
my $seq='';
while (my $line=<INPUT>)  #connect exon fasta file to one sequence
{
    chomp($line);
    $line =~ s/\r$//;
    if($line=~/>/){
    }else{
        $line=uc $line; ##################ADD HERE
        $seq=$seq.$line;
    }

}
close INPUT;
my $seq_len = length($seq); #add here
my @array=split(//,$seq);

my $count=0;

my $output=$file_dir."Target_Candidates.txt";
open (OUT,">$output");

print OUT "No	gRNA	gRNA_strand	gRNA_start	gRNA_end\n";

#for (my $i=0;$i<=$#array-2;$i++){
for (my $i=0;$i<=$#array-$targetPAM_length+1;$i++){
#    my $seq_pam = $array[$i].$array[$i+1].$array[$i+2];
    my $seq_pam = '';
    for (my $num=$i;$num<=$i+$targetPAM_length-1;$num++){
        $seq_pam=$seq_pam.$array[$num];
    }
    if ($seq_pam =~ /^$pam1$/){
        #if($i+$gRNAlength+3-1<=$#array){
        if($i+$gRNAlength+$targetPAM_length-1<=$#array){
            $count++;
            print OUT "$count\t";
            my $gRNA_rev='';
            #for(my $p=$i;$p<$i+3+$gRNAlength;$p++){
            for(my $p=$i;$p<$i+$targetPAM_length+$gRNAlength;$p++){
                $gRNA_rev=$gRNA_rev.$array[$p];
            }
            my $gRNA_com=reverse $gRNA_rev;
            my @com_array=split(//,$gRNA_com);
            my $gRNA='';
            for (my $i=0;$i<=$#com_array;$i++){
                $gRNA=$gRNA.$IUB_com{$com_array[$i]};
            }
            #my $gRNA_start=$i+1;
            #my $gRNA_end=$i+3+$gRNAlength;
            my $gRNA_end=$seq_len-$i-1+1;
            #my $gRNA_start=$seq_len-$i-3-$gRNAlength+1;
            my $gRNA_start=$seq_len-$i-$targetPAM_length-$gRNAlength+1;
            print OUT "$gRNA\t-\t$gRNA_start\t$gRNA_end\n";
        }
     }
     if ($seq_pam =~ /^$pam2$/){
         if($i-$gRNAlength>=0){
            $count++;
            print OUT "$count\t";
            my $gRNA='';
            #for(my $q=$i-$gRNAlength;$q<=$i+2;$q++){
            for(my $q=$i-$gRNAlength;$q<=$i+$targetPAM_length-1;$q++){
               $gRNA=$gRNA.$array[$q];
            }
           # my $gRNA_start=$i-20+1;
            my $gRNA_start=$i-$gRNAlength+1; #changed
            #my $gRNA_end=$i+2+1;
            my $gRNA_end=$i+$targetPAM_length-1+1;
            print OUT "$gRNA\t+\t$gRNA_start\t$gRNA_end\n";
         }

     }

}

close OUT;

print "$count";

open(IN,"<$output") or die "Cant't open file: $output\n";
my $RNA_20n='';
my $offpams='';
my @off_pam=split(//,$offPAM);

=begin
my @chr1=split(//,$IUB_off{$off_pam[0]});
my @chr2=split(//,$IUB_off{$off_pam[1]});
my @chr3=split(//,$IUB_off{$off_pam[2]});
#print @chr1,@chr2,@chr3;
#print "\n";
for (my $i=0;$i<=$#chr1;$i++){
    for (my $j=0;$j<=$#chr2;$j++){
        for (my $k=0;$k<=$#chr3;$k++){
            $offpams=$offpams.$chr1[$i].$chr2[$j].$chr3[$k].";";

        }

    }

}
#print "$offpams\n";
=cut
my @chr;
for(my $i=0;$i<$offPAM_length;$i++){
    @{$chr[$i]}=split(//,$IUB_off{$off_pam[$i]});
}

for (permute(@chr)){
   my $string='';
   for(my $i=0;$i<=$#$_;$i++){
      $string=$string.$$_[$i];
   }
   $offpams=$offpams.$string.";" ;

}

sub permute {
  my $last = pop @_;
  unless (@_) {
    return map [$_], @$last;
  }
  return map { my $left = $_; map [@$left, $_], @$last } permute(@_);
}


my @offpams=split(/;/,$offpams);

my $num=1;

my $filename=$file_dir."Candidates_Search.fa";
open (OUTPUT,">$filename");
while (my $line=<IN>){
    chomp($line);
    $line =~ s/\r$//;
    if ($line=~/^\d/){
       
       my @RNAs_array=split(/\t/,$line);
       my @RNA=split(//,$RNAs_array[1]);
      # for (my $i=0;$i<=19;$i++){
      # for (my $i=0;$i<=$#RNA-3;$i++){  #changed
       for (my $i=0;$i<=$#RNA-$targetPAM_length;$i++){  #changed
           $RNA_20n=$RNA_20n.$RNA[$i];

       }
       my $single_num=1;
       for(my $i=0;$i<=$#offpams;$i++){
           my $RNA_23n=$RNA_20n.$offpams[$i];
           print OUTPUT ">Candidate".$num."_single".$single_num."\n";
           print OUTPUT "$RNA_23n\n";
           $single_num++;
       }
       $RNA_20n='';
       $num++;

    }
    

}

close IN;
close OUTPUT;

