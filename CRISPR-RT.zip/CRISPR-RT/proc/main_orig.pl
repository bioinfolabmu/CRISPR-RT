#!/usr/bin/perl -w
use strict;

my $mode_name=shift;

my $radio=shift;

my $jbrowse_data_path=shift;


my $min_spacer=shift;
my $max_spacer=shift;

my $uploaddir=shift; 
my $filename=shift;  
my $target_pfs=shift;
my $target_pfs_length=length($target_pfs);
my $offtarget_pfs=shift; 
my $offtarget_pfs_length=length($offtarget_pfs);
my $ref_genome=shift; 

my $num_MisAndGap=shift; 
my $num_Gap=shift;  #add


my $seed_length=shift;


my $num_seed_MisID=shift; 
my $num_seed_Gap=shift; #add

my $num_BulgeStrand=shift; 


my $gRNA_length=shift;


my $seed_mismatch=shift; 
my $seed_insertion=shift; 
my $seed_deletion=shift; 
my $nonseed_mismatch=shift; 
my $nonseed_insertion=shift; 
my $nonseed_deletion=shift; 

my $sensitivity=shift;


if ($radio eq "Specific"){
    $num_MisAndGap=$seed_mismatch+$seed_insertion+$seed_deletion+$nonseed_mismatch+$nonseed_insertion+$nonseed_deletion; #count the total number of mismaches and gaps in off target by user input
}

my %min_score=(                     #store min score of bowtie2
                '0'=>'L,0,0',
                '1'=>'L,-6,0',
                '2'=>'L,-12,0',
                '3'=>'L,-18,0', 
                '4'=>'L,-24,0',
                '5'=>'L,-30,0'
              );


=begin
my $user_seq_forward='';       ####forward strand relate to user input sequence
my $user_seq_reverse='';       ####reverse strand relate to user input ssequence
my $user_seq_forward_startgap=0; 
my $user_seq_reverse_startgap=0;

if ($gRNA_length == 20 and $target_pfs eq "NGG"){

####Get the forward and reverse strand extenstion of user input sequence

  my $seq_align=$uploaddir.'userseq_alignment.sam';
  open(IN_align,"<$seq_align") or die "Can't open file: $seq_align\n";
  my $start_pos=0;
  my $align_flag=100;
  my $align_chr=0;
  my $align_len=0;
  while(my $line=<IN_align>){
    chomp($line);
    $line =~ s/\r$//;
    if ($line =~ /^@/){
    }else{
        my @align_array=split(/\t/,$line);
        $align_flag=$align_array[1];
        $align_chr=$align_array[2];
        $start_pos=$align_array[3];
        if ($align_array[5] =~ /(\d+)M/){
            $align_len=$1;
        }
    }
    
    
  }

####Get the the chromosome sequence of user input sequence
  my $refgenome_chr=$jbrowse_data_path.$ref_genome.'/genome/'.$align_chr.'.fa';
  open(IN_file_chr,"<$refgenome_chr") or die "Can't open file: $refgenome_chr\n";
  my $seq='';
  while(my $line=<IN_file_chr>){
   chomp($line);
   $line =~ s/\r$//;
   if ($line =~ /^>/){

   }else{
      $seq=$seq.$line;
   }
  }
#my $seq_forward=substr($seq,$start_pos-1-7,$align_len+14);
  my $seq_length=length($seq);
  my $seq_forward='';
  my $seq_forward_startgap=0;
  my $seq_reverse_startgap=0;


  if ($start_pos-1-4 >=0 and $start_pos+$align_len+4-1 <= $seq_length){
    $seq_forward=substr($seq,$start_pos-1-4,$align_len+8);
    $seq_forward_startgap=4;
    $seq_reverse_startgap=4;
 
  }elsif ($start_pos-1-4 < 0){
    $seq_forward=substr($seq,0,$align_len+8);
    $seq_forward_startgap=4+($start_pos-1-4);
    $seq_reverse_startgap=8-$seq_forward_startgap;

  }elsif ($start_pos+$align_len+4-1 > $seq_length){
    $seq_forward=substr($seq,$seq_length-8-$align_len,$align_len+8);
    $seq_reverse_startgap=4-($start_pos+$align_len+4-1-$seq_length);
    $seq_forward_startgap=8-$seq_reverse_startgap;

  }
#print $seq_forward."\n";
  my %hash=(                     #IUB code
           'G'=>'C',
           'A'=>'T',
           'T'=>'A',
           'C'=>'G',          
           'N'=>'N'   
        );

  my @seq_forward_array=split(//,$seq_forward);

  my $seq_reverse='';
  for (my $i=$#seq_forward_array;$i>=0;$i--){
   $seq_reverse=$seq_reverse.$hash{$seq_forward_array[$i]};   
  }

#print $seq_reverse."\n";
  


  if ($align_flag == 0){

   $user_seq_forward=$seq_forward;
   $user_seq_reverse=$seq_reverse;
   $user_seq_forward_startgap=$seq_forward_startgap;
   $user_seq_reverse_startgap=$seq_reverse_startgap;

  }elsif($align_flag == 16){

   $user_seq_forward=$seq_reverse;  
   $user_seq_reverse=$seq_forward;
   $user_seq_forward_startgap=$seq_reverse_startgap;
   $user_seq_reverse_startgap=$seq_forward_startgap;

  }

}

my $user_seq_forward_length=length($user_seq_forward);
my $user_seq_reverse_length=length($user_seq_reverse);

#print $user_seq_forward."\n";
#print $user_seq_reverse."\n";

######################################################
=cut


if ($mode_name eq "C2c2"){
  single_gRNA();

}else{
  pair_gRNA(); 

}

#####################################################################################################################################################
=begin
sub pair_gRNA {
##################Modify here###########
 my $value;
 if ($mode_name eq "Cas9n"){
   $value=qx(perl Cas9n_Candidates_Search.pl $gRNA_length $min_spacer $max_spacer $uploaddir $filename $target_pfs $offtarget_pfs);
 }else{
   $value=qx(perl Pairs_Candidates_Search.pl $gRNA_length $min_spacer $max_spacer $uploaddir $filename $target_pfs $offtarget_pfs); #Find all the target candidates in user input sequence
 }
########################################
my @RNAsAndPairs=split(/;/,$value);#$RNAsAndPairs[0] is the number of target candidates, #$RNAsAndPairs[1] is the number of pairs for one target candidate according to PAM sequence.
my $num_candidate=$RNAsAndPairs[0]; #number of target candidates
my $num_pairs=$RNAsAndPairs[1];  #number of pairs for one target candidate
print "$num_candidate";

my @chr_array;
my $chr_file='../bowtie2db/'.$ref_genome.'/'.$ref_genome.'_chr.txt';
open(IN_chr_file,"<$chr_file") or die "Can't open file: $chr_file\n";
while(my $line=<IN_chr_file>){
   #if ($line=~/^>(\w+)/){
    if ($line=~/^>(\S+)/){
       push(@chr_array,$1);
   }
}

#print "$genome_name\n";
#print "$num_chrom\n";






my $score_function=$min_score{$num_MisAndGap}; #get the min score function

#print "$score_function\n";











       system('bowtie2 -x ../bowtie2db/'.$ref_genome.'/'.$ref_genome.' -N 1 -L '.$sensitivity.' -i L,1,0 --mp 6,6 --np 6 --rdg 0,6 --rfg 0,6 --score-min '.$score_function.' -f -U '.$uploaddir.'Candidates_Search.fa -a -S '.$uploaddir.'Bowtie2_Offtargets.sam');

system("samtools view -bS ".$uploaddir."Bowtie2_Offtargets.sam -o ".$uploaddir.'Bowtie2_Offtargets.bam');

        system('samtools view -F 16 '.$uploaddir.'Bowtie2_Offtargets.bam -o '.$uploaddir.'forward.sam');
        system('samtools view -f 16 '.$uploaddir.'Bowtie2_Offtargets.bam -o '.$uploaddir.'reverse.sam');
        



       # system('perl countIDel_filterpam.pl '.$uploaddir.'forward.sam '.$uploaddir.'reverse.sam '.$uploaddir);#use countIDel.pl to count the number of InDel in every alignment and delete alignments that InDel happens in PAM 
         system('perl countIDel_filterpam.pl '.$uploaddir.'forward.sam '.$uploaddir.'reverse.sam '.$uploaddir.' '.$offtarget_pfs_length);#use countIDel.pl to count the number of InDel in every alignment and delete alignments that InDel happens in PAM 
        
#print "I AM HERE\n";
#for (my $i=0;$i<=$#chr_array;$i++){
#    print "chr is ".$chr_array[$i];
    
#    print "\n";

#}
my $countIDel_forward_file=$uploaddir.'countIDel_forward.sam';
my $countIDel_reverse_file=$uploaddir.'countIDel_reverse.sam';

system("perl chrs_seperate.pl $mode_name $offtarget_pfs_length $gRNA_length $num_candidate $num_pairs $uploaddir $min_spacer $max_spacer $countIDel_forward_file $countIDel_reverse_file @chr_array");############## Modify here #################################
#qx(perl chrs_seperate.pl $gRNA_length $num_candidate $num_pairs $uploaddir $min_spacer $max_spacer $countIDel_forward_file $countIDel_reverse_file @chr_array);#filter by position
         
#system('perl chrs_seperate.pl '.$gRNA_length.' '.$num_candidate.' '.$num_pairs.' '.$uploaddir.' '.$min_spacer.' '.$max_spacer.' '.$countIDel_forward_file.' '.$countIDel_reverse_file.' '.@chr_array);#filter by position
        


       # system('perl filter_pam.pl '.$uploaddir.'filter_position.sam '.$uploaddir);#filter by PAM sequence

if ($radio eq "General"){
    #system('perl pairs_filter_seed.pl '.$seed_length.' '.$num_seed_MisID.' '.$num_BulgeStrand.' '.$uploaddir.'filter_position.sam '.$uploaddir);#filter by seed region
    system('perl pairs_filter_seed.pl '.$offtarget_pfs_length.' '.$seed_length.' '.$num_seed_MisID.' '.$num_BulgeStrand.' '.$uploaddir.'filter_position.sam '.$uploaddir);#filter by seed region
}elsif($radio eq "Specific"){
    #system('perl pairs_specific_seed_filter.pl '.$seed_length.' '.$seed_mismatch.' '.$seed_insertion.' '.$seed_deletion.' '.$nonseed_mismatch.' '.$nonseed_insertion.' '.$nonseed_deletion.' '.$num_BulgeStrand.' '.$uploaddir.'filter_position.sam '.$uploaddir);#filter by seed region
    system('perl pairs_specific_seed_filter.pl '.$offtarget_pfs_length.' '.$seed_length.' '.$seed_mismatch.' '.$seed_insertion.' '.$seed_deletion.' '.$nonseed_mismatch.' '.$nonseed_insertion.' '.$nonseed_deletion.' '.$num_BulgeStrand.' '.$uploaddir.'filter_position.sam '.$uploaddir);#filter by seed region
}
#######################use samtools to change  filter_seed_genome.sam to bam file as input for jbrowse
my $file_name=$uploaddir.'filter_seed_genome.sam';
open(IN_file,"<$file_name") or die "Can't open file: $file_name\n";

my $outfile_name=$uploaddir.'jbrowse.sam';
open(OUT_file, ">", $outfile_name);


while(my $line=<IN_file>){
    my $new_line='';
    my @array=split(/\t/,$line);
    for (my $i=1;$i<=$#array-1;$i++){
        $new_line=$new_line.$array[$i]."\t";
        
    }
    $new_line=~s/\t$//;
    print OUT_file $new_line;
    print OUT_file "\n";

}

close IN_file;
close OUT_file;

#system('samtools view -bT DataBase/'.$genome_name.'/chrs.fa '.$uploaddir.'jbrowse.sam > '.$uploaddir.'jbrowse.bam');
system('samtools view -bT ../bowtie2db/'.$ref_genome.'/'.$ref_genome.'.fa '.$uploaddir.'jbrowse.sam > '.$uploaddir.'jbrowse.bam');
system('samtools sort '.$uploaddir.'jbrowse.bam '.$uploaddir.'jbrowse_sorted');
system('samtools index '.$uploaddir.'jbrowse_sorted.bam');

 #samtools view -bT chrs.fa Offtarget1.sam > Offtarget1.bam
       #  samtools sort Offtarget1.bam sorted
       #samtools index sorted.bam
######################copy trackList.json and make a softlink for jbrowse
#system('cp trackList.json '.$uploaddir);
my $tracklist_file=$uploaddir.'trackList.json';
open(OUT_tracklist, ">", $tracklist_file);
print OUT_tracklist "{ \"tracks\" : [
      {
         \"category\" : \"Custom tracks\",
         \"storeClass\" : \"JBrowse/Store/SeqFeature/BAM\",
         \"urlTemplate\" : \"jbrowse_sorted.bam\",
         \"baiUrlTemplate\" : \"jbrowse_sorted.bam.bai\",
         \"hideSecondary\" : false,

         \"style\" : {
            \"className\" : \"feature\"
         },
         \"label\" : \"data1.bam\",
         \"key\" : \"Target site\",
         \"type\" : \"JBrowse/View/Track/Alignments2\"
       }



   
   ],
   \"formatVersion\" : 1,
   \"include\" : [
      \"../../".$ref_genome."/trackList.json\"
   ]
}";
#,
#   \"dataset_id\" : \"usr_ID_1\"
close OUT_tracklist;
system('ln -s '.$jbrowse_data_path.$ref_genome.'/seq '.$uploaddir.'seq');
#system('ln -s /var/www/jbrowse/JBrowse-1.11.6/data/TAIR10.27/seq '.$uploaddir.'seq');
#system('ln -s /var/www/html/jbrowse/JBrowse-1.11.6/data/TAIR10/seq '.$uploaddir.'seq');
#system('ln -s /var/www/jbrowse/JBrowse-1.11.6/data/'.$genome_name.'/seq '.$uploaddir.'seq');
#system('ln -s '.$jbrowse_data_path.'TAIR10'.'/seq '.$uploaddir.'seq');

##################filter offtargets .sam file for each candidate
my @file_h;

my @array_count;
for (my $i=0;$i<=$num_candidate;$i++){
    $array_count[$i]=0;

}

for(my $i=1;$i<=$num_candidate;$i++){ 
    my $offtarget_output=$uploaddir.'Candidate'.$i.'_offtarget.sam';
    open($file_h[$i], ">", $offtarget_output);

}


my $file=$uploaddir.'filter_seed_genome.sam';
open(INPUT,"<$file") or die "Can't open file: $file\n";
while(my $line=<INPUT>){
   chomp($line);
   $line =~ s/\r$//;
   my @array=split(/\t/,$line);
   if ($array[1] =~ /^Candidate(\d+)_/){   ###change to 1
        print { $file_h[$1] } $line;
        print { $file_h[$1] } "\n";
        $array_count[$1]=$array_count[$1]+1;
    }
}

for(my $i=1;$i<=$num_candidate;$i++){ 
    close $file_h[$i];
}

close INPUT;

#########find offtargets target to exon for each candidate###########ADD oct 23
my @array_count_exon;
for (my $i=0;$i<=$num_candidate;$i++){
    $array_count_exon[$i]=0;

}

for(my $i=1;$i<=$num_candidate;$i++){ 
    my $out_exon = $uploaddir.'Candidate'.$i.'_offtargets_exon.sam';
    open(out_exon, ">", $out_exon);
    my $in_exon = $uploaddir.'Candidate'.$i.'_offtarget.sam';
    open(in_exon,"<$in_exon") or die "Can't open file: $in_exon\n";
    my $offtargets_geneID='';
    my $forward_line='';
    my $reverse_line='';
    while(my $line=<in_exon>){
        chomp($line);
        $line =~ s/\r$//;
        my @array=split(/\t/,$line);
        
        if ($array[0] eq 'Forward'){
            $forward_line=$line;
            #my $strand = '+';
            my $deletion=0;
            my $insertion=0;
            if($array[6]=~/(\d)D/){
              $deletion=$1;
            }
            if($array[6]=~/(\d)I/){
              $insertion=$1;
            }
            my $cut_pos1=$array[4] + $gRNA_length + $deletion -$insertion - 3; #3 means 3 bp upstream of the pam sequence
            my $cut_pos2=$array[4] + $gRNA_length + $deletion -$insertion - 4; #4 means 4 bp upstream of the pam sequence
            my $genes_file=$jbrowse_data_path.$ref_genome.'/gff/chr'.$array[3].'/genes.txt';
            open(in_genes_file,"<$genes_file") or die "Can't open file: $genes_file\n";
           # my $offtargets_geneID='';
            while(my $line_gene=<in_genes_file>){
                chomp($line_gene);
                $line_gene =~ s/\r$//;
                my @array_gene=split(/\t/,$line_gene);
                
                    
                        if($array_gene[1]<=$cut_pos1 && $cut_pos1<=$array_gene[2] || $array_gene[1]<=$cut_pos2 && $cut_pos2<=$array_gene[2]){
                            my $exons_file=$jbrowse_data_path.$ref_genome.'/gff/chr'.$array[3].'/'.$array_gene[0].'.txt';
                            open(in_exons_file,"<$exons_file") or die "Can't open file: $exons_file\n";
                            
                              while(my $line_exon=<in_exons_file>){
                                 chomp($line_exon);
                                 $line_exon =~ s/\r$//;
                                 my @array_exon=split(/\t/,$line_exon);  
                                 if($array_exon[1]<=$cut_pos1 && $cut_pos1<=$array_exon[2] || $array_exon[1]<=$cut_pos2 && $cut_pos2<=$array_exon[2]){
                                    
                                      $offtargets_geneID=$offtargets_geneID.$array_exon[4].';';
                                      
                                      last;
                                 }

                              }

                            close in_exons_file;
                        }
                    

               
            }
          #  if ($offtargets_geneID ne ''){
          #      $array_count_exon[$i]=$array_count_exon[$i]+1;
          #      $offtargets_geneID =~ s/;$//;
          #      print out_exon $line;
          #      print out_exon "\t";
          #      print out_exon $offtargets_geneID;
          #      print out_exon "\n";

          #  }
           close in_genes_file;  ###Don't forget
           

        }elsif($array[0] eq 'Reverse'){
            $reverse_line=$line;
            #my $strand = '-';
            #my $cut_pos1=$array[4] + 2 + 3; #3 means 3 bp upstream of the pam sequence, 2 means PAM length-1
            my $cut_pos1=$array[4] + $offtarget_pfs_length - 1 + 3; #3 means 3 bp upstream of the pam sequence, 2 means PAM length-1
            #my $cut_pos2=$array[4] + 2 + 4; #4 means 4 bp upstream of the pam
            my $cut_pos2=$array[4] + $offtarget_pfs_length - 1 + 4; #4 means 4 bp upstream of the pam

            my $genes_file=$jbrowse_data_path.$ref_genome.'/gff/chr'.$array[3].'/genes.txt';
            open(in_genes_file,"<$genes_file") or die "Can't open file: $genes_file\n";
           # my $offtargets_geneID='';
            while(my $line_gene=<in_genes_file>){
                chomp($line_gene);
                $line_gene =~ s/\r$//;
                my @array_gene=split(/\t/,$line_gene);
                
                    
                        if($array_gene[1]<=$cut_pos1 && $cut_pos1<=$array_gene[2] || $array_gene[1]<=$cut_pos2 && $cut_pos2<=$array_gene[2]){
                            my $exons_file=$jbrowse_data_path.$ref_genome.'/gff/chr'.$array[3].'/'.$array_gene[0].'.txt';
                            open(in_exons_file,"<$exons_file") or die "Can't open file: $exons_file\n";
                            
                              while(my $line_exon=<in_exons_file>){
                                 chomp($line_exon);
                                 $line_exon =~ s/\r$//;
                                 my @array_exon=split(/\t/,$line_exon);  
                                 if($array_exon[1]<=$cut_pos1 && $cut_pos1<=$array_exon[2] || $array_exon[1]<=$cut_pos2 && $cut_pos2<=$array_exon[2]){
                                    
                                      $offtargets_geneID=$offtargets_geneID.$array_exon[4].';';

                                      last;
                                 }

                              }

                            close in_exons_file;
                        }
                    

               
            }
            if ($offtargets_geneID ne ''){
                $array_count_exon[$i]=$array_count_exon[$i]+1;
                $offtargets_geneID =~ s/;$//;

                my @arr=split(/;/,$offtargets_geneID);
                my @uniqarr;
                foreach my $var ( @arr ){
                  if ( ! grep( /$var/, @uniqarr ) ){
                    push( @uniqarr, $var );
                  }
                }
                my $GeneID='';
                for(my $i=0;$i<=$#uniqarr;$i++){

                    $GeneID=$GeneID.$uniqarr[$i].";";
                }
                $GeneID =~ s/;$//;

                print out_exon $forward_line;
                print out_exon "\t";
                print out_exon $GeneID;
                print out_exon "\n";
                print out_exon $reverse_line;
                print out_exon "\t";
                print out_exon $GeneID;
                print out_exon "\n";
                $offtargets_geneID='';
                $forward_line='';
                $reverse_line='';

            }else{
                $forward_line='';
                $reverse_line='';

            }
           close in_genes_file;  ###Don't forget
        }
        
    }

    close out_exon;
    close in_exon;
}
#######################exonic offtargets .txt file for each candidate
for(my $i=1;$i<=$num_candidate;$i++){ 
     my $output_file=$uploaddir.'Candidate'.$i.'_offtargets_exon.txt';
     open(OUT_exon_txt, ">", $output_file);
     my $input_file=$uploaddir.'Candidate'.$i.'_offtargets_exon.sam';
     open(IN_exon_txt,"<$input_file") or die "Can't open file: $input_file\n";
     print OUT_exon_txt "ID	GeneID	Sequence1	Chr	Pos	Str	M&G	M	G	Sequence2	Chr	Pos	Str	M&G	M	G	JBrowser\n";
     my $id=1;
     while(my $line=<IN_exon_txt>){
        chomp($line);
        $line =~ s/\r$//;
        my @array=split(/\t/,$line);
        my $strand;
        if ($array[0] eq 'Forward'){
          #  if($id != 1){
          #     print OUT_jtable "\n";
          #  }
            $strand='+';
            my @mis_gap=split(/:/,$array[$#array-4]);
            my @gap=split(/:/,$array[$#array-5]);
            my @mis=split(/:/,$array[$#array-7]);
            print OUT_exon_txt $id."\t".$array[$#array]."\t".$array[$#array-1]."\t".$array[3]."\t".$array[4]."\t".$strand."\t".$mis_gap[2]."\t".$mis[2]."\t".$gap[2]."\t";
            
        }
        if($array[0] eq 'Reverse'){
            $strand='-';
            my @mis_gap=split(/:/,$array[$#array-4]);
            my @gap=split(/:/,$array[$#array-5]);
            my @mis=split(/:/,$array[$#array-7]);
            print OUT_exon_txt $array[$#array-1]."\t".$array[3]."\t".$array[4]."\t".$strand."\t".$mis_gap[2]."\t".$mis[2]."\t".$gap[2]."\t"."click";
            print OUT_exon_txt "\n";
            $id++;
        }
        
        
     }

     close OUT_exon_txt;
     close IN_exon_txt;
}




############################Generate offtargets .txt file for each candidate
for(my $i=1;$i<=$num_candidate;$i++){ 
     my $output_file=$uploaddir.'Candidate'.$i.'_offtargets.txt';
     open(OUT_jtable, ">", $output_file);
     my $input_file=$uploaddir.'Candidate'.$i.'_offtarget.sam';
     open(IN_jtable,"<$input_file") or die "Can't open file: $input_file\n";
     print OUT_jtable "ID	Sequence1	Chr	Pos	Str	M&G	M	G	Sequence2	Chr	Pos	Str	M&G	M	G	JBrowser\n";
     my $id=1;
     while(my $line=<IN_jtable>){
        chomp($line);
        $line =~ s/\r$//;
        my @array=split(/\t/,$line);
        my $strand;
        if ($array[0] eq 'Forward'){
          #  if($id != 1){
          #     print OUT_jtable "\n";
          #  }
            $strand='+';
            my @mis_gap=split(/:/,$array[$#array-3]);
            my @gap=split(/:/,$array[$#array-4]);
            my @mis=split(/:/,$array[$#array-6]);
            print OUT_jtable $id."\t".$array[$#array]."\t".$array[3]."\t".$array[4]."\t".$strand."\t".$mis_gap[2]."\t".$mis[2]."\t".$gap[2]."\t";
            
        }
        if($array[0] eq 'Reverse'){
            $strand='-';
            my @mis_gap=split(/:/,$array[$#array-3]);
            my @gap=split(/:/,$array[$#array-4]);
            my @mis=split(/:/,$array[$#array-6]);
            print OUT_jtable $array[$#array]."\t".$array[3]."\t".$array[4]."\t".$strand."\t".$mis_gap[2]."\t".$mis[2]."\t".$gap[2]."\t"."click";
            print OUT_jtable "\n";
            $id++;
        }
        
        
     }

     close OUT_jtable;
     close IN_jtable;
}


####################Generate each each Candidate exonic offtargets ajax file for Datatable
for(my $i=1;$i<=$num_candidate;$i++){ 
  my $output_off=$uploaddir.'Candidate'.$i.'_offtargets_exon_DataTable.txt';
  open(OUT_of,">$output_off");

  my $input_off=$uploaddir.'Candidate'.$i.'_offtargets_exon.txt';
  open(IN_of,"<$input_off") or die "Can't open file: $input_off\n";

  print OUT_of "{\"data\":["; 


  while(my $line=<IN_of>){
    chomp($line);
    $line =~ s/\r$//;
    my @array=split(/\t/,$line);
    if ($array[0]=~/^\d/){
         
         print OUT_of "{";

         print OUT_of "\"ID\":";
         print OUT_of "\"";
         print OUT_of $array[0];
         print OUT_of "\"";
         print OUT_of ",";
         
         print OUT_of "\"GeneID\":";
         print OUT_of "\"";
         print OUT_of $array[1];
         print OUT_of "\"";
         print OUT_of ",";
           
         print OUT_of "\"Sequence_1\":";
         print OUT_of "\"";
         print OUT_of $array[2];
         print OUT_of "\"";
         print OUT_of ",";

         print OUT_of "\"Chr_1\":";
         print OUT_of "\"";
         print OUT_of $array[3];
         print OUT_of "\"";
         print OUT_of ",";

         print OUT_of "\"Pos_1\":";
         print OUT_of "\"";
         print OUT_of $array[4];
         print OUT_of "\"";
         print OUT_of ",";

         print OUT_of "\"Str_1\":";
         print OUT_of "\"";
         print OUT_of $array[5];
         print OUT_of "\"";
         print OUT_of ",";

         print OUT_of "\"M&G_1\":";
         print OUT_of "\"";
         print OUT_of $array[6];
         print OUT_of "\"";
         print OUT_of ",";

         print OUT_of "\"M_1\":";
         print OUT_of "\"";
         print OUT_of $array[7];
         print OUT_of "\"";
         print OUT_of ",";

         print OUT_of "\"G_1\":";
         print OUT_of "\"";
         print OUT_of $array[8];
         print OUT_of "\"";
         print OUT_of ",";

         print OUT_of "\"Sequence_2\":";
         print OUT_of "\"";
         print OUT_of $array[9];
         print OUT_of "\"";
         print OUT_of ",";

         print OUT_of "\"Chr_2\":";
         print OUT_of "\"";
         print OUT_of $array[10];
         print OUT_of "\"";
         print OUT_of ",";

         print OUT_of "\"Pos_2\":";
         print OUT_of "\"";
         print OUT_of $array[11];
         print OUT_of "\"";
         print OUT_of ",";

         print OUT_of "\"Str_2\":";
         print OUT_of "\"";
         print OUT_of $array[12];
         print OUT_of "\"";
         print OUT_of ",";

         print OUT_of "\"M&G_2\":";
         print OUT_of "\"";
         print OUT_of $array[13];
         print OUT_of "\"";
         print OUT_of ",";

         print OUT_of "\"M_2\":";
         print OUT_of "\"";
         print OUT_of $array[14];
         print OUT_of "\""; 
         print OUT_of ",";

         print OUT_of "\"G_2\":";
         print OUT_of "\"";
         print OUT_of $array[15];
         print OUT_of "\"";
         print OUT_of ",";

         print OUT_of "\"JBrowser\":";
         print OUT_of "\"";
         print OUT_of $array[16];
         print OUT_of "\"";
           
         print OUT_of "}";

        if (!eof) {  # check for end of last file
         print OUT_of ",";
        }
                                                     
     }

  }

  print OUT_of "]}";

  close OUT_of;
  close IN_of;


}



#####################Generate each each Candidate offtargets ajax file for Datatable
for(my $i=1;$i<=$num_candidate;$i++){ 
  my $output_off=$uploaddir.'Candidate'.$i.'_offtargets_DataTable.txt';
  open(OUT_off,">$output_off");

  my $input_off=$uploaddir.'Candidate'.$i.'_offtargets.txt';
  open(IN_off,"<$input_off") or die "Can't open file: $input_off\n";

  print OUT_off "{\"data\":["; 


  while(my $line=<IN_off>){
    chomp($line);
    $line =~ s/\r$//;
    my @array=split(/\t/,$line);
    if ($array[0]=~/^\d/){
         
         print OUT_off "{";

         print OUT_off "\"ID\":";
         print OUT_off "\"";
         print OUT_off $array[0];
         print OUT_off "\"";
         print OUT_off ",";

         print OUT_off "\"Sequence_1\":";
         print OUT_off "\"";
         print OUT_off $array[1];
         print OUT_off "\"";
         print OUT_off ",";

         print OUT_off "\"Chr_1\":";
         print OUT_off "\"";
         print OUT_off $array[2];
         print OUT_off "\"";
         print OUT_off ",";

         print OUT_off "\"Pos_1\":";
         print OUT_off "\"";
         print OUT_off $array[3];
         print OUT_off "\"";
         print OUT_off ",";

         print OUT_off "\"Str_1\":";
         print OUT_off "\"";
         print OUT_off $array[4];
         print OUT_off "\"";
         print OUT_off ",";

         print OUT_off "\"M&G_1\":";
         print OUT_off "\"";
         print OUT_off $array[5];
         print OUT_off "\"";
         print OUT_off ",";

         print OUT_off "\"M_1\":";
         print OUT_off "\"";
         print OUT_off $array[6];
         print OUT_off "\"";
         print OUT_off ",";

         print OUT_off "\"G_1\":";
         print OUT_off "\"";
         print OUT_off $array[7];
         print OUT_off "\"";
         print OUT_off ",";

         print OUT_off "\"Sequence_2\":";
         print OUT_off "\"";
         print OUT_off $array[8];
         print OUT_off "\"";
         print OUT_off ",";

         print OUT_off "\"Chr_2\":";
         print OUT_off "\"";
         print OUT_off $array[9];
         print OUT_off "\"";
         print OUT_off ",";

         print OUT_off "\"Pos_2\":";
         print OUT_off "\"";
         print OUT_off $array[10];
         print OUT_off "\"";
         print OUT_off ",";

         print OUT_off "\"Str_2\":";
         print OUT_off "\"";
         print OUT_off $array[11];
         print OUT_off "\"";
         print OUT_off ",";

         print OUT_off "\"M&G_2\":";
         print OUT_off "\"";
         print OUT_off $array[12];
         print OUT_off "\"";
         print OUT_off ",";

         print OUT_off "\"M_2\":";
         print OUT_off "\"";
         print OUT_off $array[13];
         print OUT_off "\""; 
         print OUT_off ",";

         print OUT_off "\"G_2\":";
         print OUT_off "\"";
         print OUT_off $array[14];
         print OUT_off "\"";
         print OUT_off ",";

         print OUT_off "\"JBrowser\":";
         print OUT_off "\"";
         print OUT_off $array[15];
         print OUT_off "\"";
           
         print OUT_off "}";

        if (!eof) {  # check for end of last file
         print OUT_off ",";
        }
                                                     
     }

  }

  print OUT_off "]}";

  close OUT_off;
  close IN_off;


}









#############################################Generate Target Candidates and offtarget number .txt file 
my $out_array_index=1;
my $output=$uploaddir."Candidates_Offtargets.txt";
open(OUT,">$output");
my $candidates_file=$uploaddir."Target_Candidates.txt";
open(IN,"<$candidates_file") or die "Can't open file: $candidates_file\n";
print OUT "No	gRNAa	gRNAa_GC	gRNAa_GC6	gRNAa_strand	gRNAa_start	gRNAa_end	gRNAb	gRNAb_GC	gRNAb_GC6	gRNAb_strand	gRNAb_start	gRNAb_end	num_targets	num_exonic_targets	gRNAa_score	gRNAb_score\n"; #changed
while(my $line=<IN>){
    chomp($line);
    $line =~ s/\r$//;
    my @array=split(/\t/,$line);
    if ($array[0]=~/^\d/){
        
        my $gRNAa_PAM=$array[1];#added start
        my @gRNAa_PAM_array=split(//,$gRNAa_PAM);
        my $gRNAa='';
        #for (my $i=0;$i<=$#gRNAa_PAM_array-3;$i++){
        for (my $i=0;$i<=$#gRNAa_PAM_array-$target_pfs_length;$i++){
            $gRNAa=$gRNAa.$gRNAa_PAM_array[$i];
        }
        my $gRNAa_len=length($gRNAa);
        my $gRNAa_gc_content=($gRNAa=~tr/GC/GC/)/$gRNAa_len;#added end
        

        my $gRNAa_6mer='';
        #for (my $i=$#gRNAa_PAM_array-8;$i<=$#gRNAa_PAM_array-3;$i++){
        for (my $i=$#gRNAa_PAM_array-$target_pfs_length-6+1;$i<=$#gRNAa_PAM_array-$target_pfs_length;$i++){
            $gRNAa_6mer=$gRNAa_6mer.$gRNAa_PAM_array[$i];
        }
        my $gRNAa_6mer_len=length($gRNAa_6mer);
        my $gRNAa_6mer_gc_content=($gRNAa_6mer=~tr/GC/GC/)/$gRNAa_6mer_len;#added end
        
        my $gRNAa_score='N/A';
        my $gRNAa_score_seq='';
        if ($gRNA_length == 20 and $target_pfs eq "NGG"){
         if ($array[2] eq '+'){
          if($array[3]+$user_seq_forward_startgap-4-1 >= 0 and $array[3]+$user_seq_forward_startgap-4-1 + 30 <= $user_seq_forward_length){
            $gRNAa_score_seq=substr($user_seq_forward,$array[3]+$user_seq_forward_startgap-4-1,30);    
            my $gRNAa_score_raw=qx(/home/peil/anaconda2/bin/python2.7 rs2_score_calculator.py --seq $gRNAa_score_seq);
            #print "$gRNA_score_raw";

            if ($gRNAa_score_raw =~ /:\s(\S+)/){
               $gRNAa_score = $1; 
            }        
          }  
         }elsif($array[2] eq '-'){
          if($array[3]+$user_seq_reverse_startgap-4-1 >= 0 and $array[3]+$user_seq_reverse_startgap-4-1 + 30 <= $user_seq_reverse_length){
            $gRNAa_score_seq=substr($user_seq_reverse,$array[3]+$user_seq_reverse_startgap-4-1,30);  
            my $gRNAa_score_raw=qx(/home/peil/anaconda2/bin/python2.7 rs2_score_calculator.py --seq $gRNAa_score_seq);
            #print "$gRNA_score_raw";

            if ($gRNAa_score_raw =~ /:\s(\S+)/){
               $gRNAa_score = $1; 
            }  
          }
         }
        }

        my $gRNAb_PAM=$array[5];#added start
        my @gRNAb_PAM_array=split(//,$gRNAb_PAM);
        my $gRNAb='';
        #for (my $i=0;$i<=$#gRNAb_PAM_array-3;$i++){
        for (my $i=0;$i<=$#gRNAb_PAM_array-$target_pfs_length;$i++){
            $gRNAb=$gRNAb.$gRNAb_PAM_array[$i];
        }
        my $gRNAb_len=length($gRNAb);
        my $gRNAb_gc_content=($gRNAb=~tr/GC/GC/)/$gRNAb_len;


        my $gRNAb_6mer='';
        #for (my $i=$#gRNAb_PAM_array-8;$i<=$#gRNAb_PAM_array-3;$i++){
        for (my $i=$#gRNAb_PAM_array-$target_pfs_length-6+1;$i<=$#gRNAb_PAM_array-$target_pfs_length;$i++){
            $gRNAb_6mer=$gRNAb_6mer.$gRNAb_PAM_array[$i];
        }
        my $gRNAb_6mer_len=length($gRNAb_6mer);
        my $gRNAb_6mer_gc_content=($gRNAb_6mer=~tr/GC/GC/)/$gRNAb_6mer_len;#added end

        my $gRNAb_score='N/A';
        my $gRNAb_score_seq='';

        if ($gRNA_length == 20 and $target_pfs eq "NGG"){
         if ($array[6] eq '+'){
          #if($array[3]+$user_seq_forward_startgap-4-1 >= 0 and $array[3]+$user_seq_forward_startgap-4-1 + 30 <= $user_seq_forward_length){ 
          if($array[7]+$user_seq_forward_startgap-4-1 >= 0 and $array[7]+$user_seq_forward_startgap-4-1 + 30 <= $user_seq_forward_length){ 
            $gRNAb_score_seq=substr($user_seq_forward,$array[7]+$user_seq_forward_startgap-4-1,30);  
            my $gRNAb_score_raw=qx(/home/peil/anaconda2/bin/python2.7 rs2_score_calculator.py --seq $gRNAb_score_seq);
            #print "$gRNA_score_raw";

            if ($gRNAb_score_raw =~ /:\s(\S+)/){
               $gRNAb_score = $1; 
            }          
          }  
         }elsif($array[6] eq '-'){
          if($array[7]+$user_seq_reverse_startgap-4-1 >= 0 and $array[7]+$user_seq_reverse_startgap-4-1 + 30 <= $user_seq_reverse_length){
            $gRNAb_score_seq=substr($user_seq_reverse,$array[7]+$user_seq_reverse_startgap-4-1,30);  
            my $gRNAb_score_raw=qx(/home/peil/anaconda2/bin/python2.7 rs2_score_calculator.py --seq $gRNAb_score_seq);
            #print "$gRNA_score_raw";

            if ($gRNAb_score_raw =~ /:\s(\S+)/){
               $gRNAb_score = $1; 
            }  
          }        
         }
        }

        print OUT $array[0];
        print OUT "\t"; 
        
        print OUT $array[1];
        print OUT "\t"; 

        print OUT sprintf("%.2f",$gRNAa_gc_content);
        print OUT "\t"; 

        print OUT sprintf("%.2f",$gRNAa_6mer_gc_content);
        print OUT "\t"; 
        
        print OUT $array[2];
        print OUT "\t"; 
        
        print OUT $array[3];
        print OUT "\t"; 

        print OUT $array[4];
        print OUT "\t"; 

        print OUT $array[5];
        print OUT "\t"; 

        print OUT sprintf("%.2f",$gRNAb_gc_content);
        print OUT "\t"; 

        print OUT sprintf("%.2f",$gRNAb_6mer_gc_content);
        print OUT "\t"; 
        
        print OUT $array[6];
        print OUT "\t"; 

        print OUT $array[7];
        print OUT "\t"; 

        print OUT $array[8];
        print OUT "\t";         #added end



        print OUT $array_count[$out_array_index]/2;
        print OUT "\t"; #added
        print OUT $array_count_exon[$out_array_index];
        print OUT "\t"; #added
        print OUT $gRNAa_score;
        #print OUT $gRNAa_score_seq;
        print OUT "\t"; #added
        print OUT $gRNAb_score;
        #print OUT $gRNAb_score_seq;
        $out_array_index++;
        print OUT "\n";
     }

}

close OUT;
close IN;

####################################Generate Target Candidates and offtarget number ajax file for Datatable

my $output_candidates=$uploaddir."Candidates_Offtargets_DataTable.txt";
open(OUT_Can,">$output_candidates");

my $input_candidates=$uploaddir."Candidates_Offtargets.txt";
open(IN_Can,"<$input_candidates") or die "Can't open file: $input_candidates\n";

print OUT_Can "{\"data\":["; 


while(my $line=<IN_Can>){
    chomp($line);
    $line =~ s/\r$//;
    my @array=split(/\t/,$line);
    if ($array[0]=~/^\d/){
         
         print OUT_Can "{";

         print OUT_Can "\"No\":";
         print OUT_Can "\"";
         print OUT_Can $array[0];
         print OUT_Can "\"";
         print OUT_Can ",";

         print OUT_Can "\"gRNAa\":";
         print OUT_Can "\"";
         print OUT_Can $array[1];
         print OUT_Can "\"";
         print OUT_Can ",";

         print OUT_Can "\"gRNAa_GC\":";
         print OUT_Can "\"";
         print OUT_Can $array[2];
         print OUT_Can "\"";
         print OUT_Can ",";

         print OUT_Can "\"gRNAa_GC6\":";
         print OUT_Can "\"";
         print OUT_Can $array[3];
         print OUT_Can "\"";
         print OUT_Can ",";

         print OUT_Can "\"gRNAa_strand\":";
         print OUT_Can "\"";
         print OUT_Can $array[4];
         print OUT_Can "\"";
         print OUT_Can ",";

         print OUT_Can "\"gRNAa_start\":";
         print OUT_Can "\"";
         print OUT_Can $array[5];
         print OUT_Can "\"";
         print OUT_Can ",";

         print OUT_Can "\"gRNAa_end\":";
         print OUT_Can "\"";
         print OUT_Can $array[6];
         print OUT_Can "\"";
         print OUT_Can ",";

         print OUT_Can "\"gRNAb\":";
         print OUT_Can "\"";
         print OUT_Can $array[7];
         print OUT_Can "\"";
         print OUT_Can ",";

         print OUT_Can "\"gRNAb_GC\":";
         print OUT_Can "\"";
         print OUT_Can $array[8];
         print OUT_Can "\"";
         print OUT_Can ",";

         print OUT_Can "\"gRNAb_GC6\":";
         print OUT_Can "\"";
         print OUT_Can $array[9];
         print OUT_Can "\"";
         print OUT_Can ",";

         print OUT_Can "\"gRNAb_strand\":";
         print OUT_Can "\"";
         print OUT_Can $array[10];
         print OUT_Can "\"";
         print OUT_Can ",";

         print OUT_Can "\"gRNAb_start\":";
         print OUT_Can "\"";
         print OUT_Can $array[11];
         print OUT_Can "\"";
         print OUT_Can ",";

         print OUT_Can "\"gRNAb_end\":";
         print OUT_Can "\"";
         print OUT_Can $array[12];
         print OUT_Can "\"";
         print OUT_Can ",";

         print OUT_Can "\"num_targets\":";
         print OUT_Can "\"";
         print OUT_Can $array[13];
         print OUT_Can "\"";
         print OUT_Can ",";

         print OUT_Can "\"num_exonic_targets\":";
         print OUT_Can "\"";
         print OUT_Can $array[14];
         print OUT_Can "\"";
         print OUT_Can ",";
           
         print OUT_Can "\"gRNAa_score\":";
         print OUT_Can "\"";
         print OUT_Can $array[15];
         print OUT_Can "\"";
         print OUT_Can ",";

         print OUT_Can "\"gRNAb_score\":";
         print OUT_Can "\"";
         print OUT_Can $array[16];
         print OUT_Can "\"";


         print OUT_Can "}";

        if (!eof) {  # check for end of last file
         print OUT_Can ",";
        }
                                                     
     }

}

print OUT_Can "]}";

close OUT_Can;
close IN_Can;

}  #end of sub pairs

=cut
#####################################################################################################################################################


sub single_gRNA {
    my $num_candidate=qx(perl C2c2_Candidates_Search.pl $gRNA_length $uploaddir $filename $target_pfs $offtarget_pfs); #Find all the target candidates in user input sequence

print "$num_candidate";

my $score_function=$min_score{$num_MisAndGap}; #get the min score function

my $ref_transcriptome=$ref_genome.'.transcripts';
system('bowtie2 -x ../bowtie2db/'.$ref_genome.'/'.$ref_transcriptome.' --norc -N 1 -L '.$sensitivity.' -i L,1,0 --mp 6,6 --np 6 --rdg 0,6 --rfg 0,6 --score-min '.$score_function.' -f -U '.$uploaddir.'Candidates_Search.fa -a -S '.$uploaddir.'Bowtie2_Offtargets_transcriptome.sam'); #Add --norc to align reads only on forward strand





system('perl filter_pfs_gap.pl '.$num_Gap.' '.$offtarget_pfs_length.' '.$uploaddir.'Bowtie2_Offtargets_transcriptome.sam '.$uploaddir);#delete alignments that InDel happens in pfs 
        
if ($radio eq "General"){
    
     system('perl C2c2_filter_seed.pl '.$offtarget_pfs_length.' '.$seed_length.' '.$num_seed_MisID.' '.$num_seed_Gap.' '.$uploaddir.'filter_pfs_gap.sam '.$uploaddir);#filter by seed region

}elsif($radio eq "Specific"){
     
     system('perl C2c2_specific_seed_filter.pl '.$offtarget_pfs_length.' '.$seed_length.' '.$seed_mismatch.' '.$seed_insertion.' '.$seed_deletion.' '.$nonseed_mismatch.' '.$nonseed_insertion.' '.$nonseed_deletion.' '.$uploaddir.'filter_pfs_gap.sam '.$uploaddir); #filter by seed region   
}







#system('perl modify_trans_alignments.pl '.$uploaddir.'Bowtie2_Offtargets_transcriptome.sam '.$uploaddir);

system("samtools view -bS ".$uploaddir."filter_seed.sam -o ".$uploaddir."filter_seed.bam"); #Convert sam result to bam

system('rsem-tbam2gbam ../bowtie2db/'.$ref_genome.'/'.$ref_genome.' '.$uploaddir.'filter_seed.bam '.$uploaddir.'filter_seed_genome.bam'); #onvert transcript BAM file to genome BAM file

system("samtools view -h -o ".$uploaddir."filter_seed_genome.sam ".$uploaddir."filter_seed_genome.bam"); #Convert genome bam file to sam file

#system('perl modify_genome_alignments.pl '.$uploaddir.'Bowtie2_Offtargets_genome.sam '.$uploaddir);
        

=begin
#######################use samtools to change  filter_seed_genome.sam to bam file as input for jbrowse
my $file_name=$uploaddir.'filter_seed_genome.sam';
open(IN_file,"<$file_name") or die "Can't open file: $file_name\n";

my $outfile_name=$uploaddir.'jbrowse.sam';
open(OUT_file, ">", $outfile_name);


while(my $line=<IN_file>){
    chomp($line);
    $line =~ s/\r$//;
    if($line =~ /^@/){
        
    }else{
      my $new_line='';
      my @array=split(/\t/,$line);

      my $YT_index;
    
      for(my $i = 0; $i<=$#array; $i++){
          if($array[$i] =~ /^YT:Z/){
             $YT_index=$i;
          }

      }
      $array[$YT_index] = "YT:Z:UU";

      for (my $i=0;$i<=$#array;$i++){
          $new_line=$new_line.$array[$i]."\t";
        
      }
      $new_line=~s/\t$//;
      print OUT_file $new_line;
      print OUT_file "\n";
    }

}

close IN_file;
close OUT_file;


system('samtools view -bT ../bowtie2db/'.$ref_genome.'/'.$ref_genome.'.fa '.$uploaddir.'jbrowse.sam > '.$uploaddir.'jbrowse.bam');
system('samtools sort '.$uploaddir.'jbrowse.bam '.$uploaddir.'jbrowse_sorted');
system('samtools index '.$uploaddir.'jbrowse_sorted.bam');
=cut
 
######################copy trackList.json and make a softlink for jbrowse

my $tracklist_file=$uploaddir.'trackList.json';
open(OUT_tracklist, ">", $tracklist_file);
print OUT_tracklist "{ \"tracks\" : [
      {
         \"category\" : \"Custom tracks\",
         \"storeClass\" : \"JBrowse/Store/SeqFeature/BAM\",
         \"urlTemplate\" : \"jbrowse_sorted.bam\",
         \"baiUrlTemplate\" : \"jbrowse_sorted.bam.bai\",
         \"hideSecondary\" : false,

         \"style\" : {
            \"className\" : \"feature\"
         },
         \"label\" : \"data1.bam\",
         \"key\" : \"Target site\",
         \"type\" : \"JBrowse/View/Track/Alignments2\"
       }



   
   ],
   \"formatVersion\" : 1,
   \"include\" : [
      \"../../".$ref_genome."/trackList.json\"
   ]
}";
close OUT_tracklist;
system('ln -s '.$jbrowse_data_path.$ref_genome.'/seq '.$uploaddir.'seq');


##################filter offtargets for each candidate
my @file_h;

my @array_count;
for (my $i=0;$i<=$num_candidate;$i++){
    $array_count[$i]=0;

}

for(my $i=1;$i<=$num_candidate;$i++){ 
    my $offtarget_output=$uploaddir.'Candidate'.$i.'_offtarget.sam';
    open($file_h[$i], ">", $offtarget_output);

}


my $file=$uploaddir.'filter_seed_genome.sam';
open(INPUT,"<$file") or die "Can't open file: $file\n";
while(my $line=<INPUT>){
   chomp($line);
   $line =~ s/\r$//;
   if($line =~ /^@/){
    
   }else{
     my @array=split(/\t/,$line);
     if ($array[0] =~ /^Candidate(\d+)_/){        ##change to 1
        print { $file_h[$1] } $line;
        print { $file_h[$1] } "\n";
        $array_count[$1]=$array_count[$1]+1;
     }

   }
}

for(my $i=1;$i<=$num_candidate;$i++){ 
    close $file_h[$i];
}

close INPUT;




############################offtargets file .txt

for(my $i=1;$i<=$num_candidate;$i++){ 
     my $output_file=$uploaddir.'Candidate'.$i.'_offtargets.txt';
     open(OUT_jtable, ">", $output_file);
     my $input_file=$uploaddir.'Candidate'.$i.'_offtarget.sam';
     open(IN_jtable,"<$input_file") or die "Can't open file: $input_file\n";
     print OUT_jtable "ID	Sequence	Chromosome	Position	Strand	Mis&Gap	Mis	Gap JBrowser\n";
     my $id=1;
     while(my $line=<IN_jtable>){
        chomp($line);
        $line =~ s/\r$//;
        my @array=split(/\t/,$line);
        my $strand='';
        if ($array[1] == 0 or $array[1] == 256){
            $strand='+';
        }elsif($array[1] == 16 or $array[1] == 272){
            $strand='-';
        }

        my $NM_index;
        for(my $i = 0; $i<=$#array; $i++){
           if($array[$i] =~ /^NM:i/){
              $NM_index=$i;
           }

        }
        my @mis_gap=split(/:/,$array[$NM_index]);
        
        my $XG_index;
        for(my $i = 0; $i<=$#array; $i++){
           if($array[$i] =~ /^XG:i/){
              $XG_index=$i;
           }

        }
        my @gap=split(/:/,$array[$XG_index]);

        my $XM_index;
        for(my $i = 0; $i<=$#array; $i++){
           if($array[$i] =~ /^XM:i/){
              $XM_index=$i;
           }

        }
        my @mis=split(/:/,$array[$XM_index]);

        my $YT_index;
        for(my $i = 0; $i<=$#array; $i++){
          if($array[$i] =~ /^YT:Z/){
              $YT_index=$i;
          }

        }
        my @yt_seq=split(/:/,$array[$YT_index]);

        print OUT_jtable $id."\t".$yt_seq[3]."\t".$array[2]."\t".$array[3]."\t".$strand."\t".$mis_gap[2]."\t".$mis[2]."\t".$gap[2]."\t"."click";
        print OUT_jtable "\n";
        $id++;
     }

     close OUT_jtable;
     close IN_jtable;
}

#####################Generate each Candidate offtargets ajax file for Datatable
for(my $i=1;$i<=$num_candidate;$i++){ 
  my $output_off=$uploaddir.'Candidate'.$i.'_offtargets_DataTable.txt';
  open(OUT_off,">$output_off");

  my $input_off=$uploaddir.'Candidate'.$i.'_offtargets.txt';
  open(IN_off,"<$input_off") or die "Can't open file: $input_off\n";

  print OUT_off "{\"data\":["; 


  while(my $line=<IN_off>){
    chomp($line);
    $line =~ s/\r$//;
    my @array=split(/\t/,$line);
    if ($array[0]=~/^\d/){
         
         print OUT_off "{";

         print OUT_off "\"ID\":";
         print OUT_off "\"";
         print OUT_off $array[0];
         print OUT_off "\"";
         print OUT_off ",";

         print OUT_off "\"Sequence\":";
         print OUT_off "\"";
         print OUT_off $array[1];
         print OUT_off "\"";
         print OUT_off ",";

         print OUT_off "\"Chromosome\":";
         print OUT_off "\"";
         print OUT_off $array[2];
         print OUT_off "\"";
         print OUT_off ",";

         print OUT_off "\"Position\":";
         print OUT_off "\"";
         print OUT_off $array[3];
         print OUT_off "\"";
         print OUT_off ",";

         print OUT_off "\"Strand\":";
         print OUT_off "\"";
         print OUT_off $array[4];
         print OUT_off "\"";
         print OUT_off ",";

         print OUT_off "\"Mis&Gap\":";
         print OUT_off "\"";
         print OUT_off $array[5];
         print OUT_off "\"";
         print OUT_off ",";

         print OUT_off "\"Mis\":";
         print OUT_off "\"";
         print OUT_off $array[6];
         print OUT_off "\"";
         print OUT_off ",";

         print OUT_off "\"Gap\":";
         print OUT_off "\"";
         print OUT_off $array[7];
         print OUT_off "\"";
         print OUT_off ",";

         print OUT_off "\"JBrowser\":";
         print OUT_off "\"";
         print OUT_off $array[8];
         print OUT_off "\"";
         
           
         print OUT_off "}";

        if (!eof) {  # check for end of last file
         print OUT_off ",";
        }
                                                     
     }

  }

  print OUT_off "]}";

  close OUT_off;
  close IN_off;


}


##########################
my $out_array_index=1;
my $output=$uploaddir."Candidates_Offtargets.txt";
open(OUT,">$output");
my $candidates_file=$uploaddir."Target_Candidates.txt";
open(IN,"<$candidates_file") or die "Can't open file: $candidates_file\n";
print OUT "No	Protospacer+PFS	gRNA_start	gRNA_end	GC	num_targets\n"; #changed
while(my $line=<IN>){
    chomp($line);
    $line =~ s/\r$//;
    my @array=split(/\t/,$line);
    if ($array[0]=~/^\d/){
        my $gRNA_pfs=$array[1];#added start
        my @gRNA_pfs_array=split(//,$gRNA_pfs);
        my $gRNA='';
        for (my $i=0;$i<=$#gRNA_pfs_array-$target_pfs_length;$i++){
            $gRNA=$gRNA.$gRNA_pfs_array[$i];
        }
        my $gRNA_len=length($gRNA);
        my $gc_content=($gRNA=~tr/GC/GC/)/$gRNA_len;#added end

        print OUT $line;
        print OUT "\t"; 
        print OUT sprintf("%.2f",$gc_content); #added
        print OUT "\t"; #added
        
        print OUT $array_count[$out_array_index];
      
        
     
        $out_array_index++;
        print OUT "\n";
     }

}

close OUT;
close IN;


####################################Generate Target Candidates and offtarget number ajax file for Datatable

my $output_candidates=$uploaddir."Candidates_Offtargets_DataTable.txt";
open(OUT_Can,">$output_candidates");

my $input_candidates=$uploaddir."Candidates_Offtargets.txt";
open(IN_Can,"<$input_candidates") or die "Can't open file: $input_candidates\n";

print OUT_Can "{\"data\":["; 


while(my $line=<IN_Can>){
    chomp($line);
    $line =~ s/\r$//;
    my @array=split(/\t/,$line);
    if ($array[0]=~/^\d/){
         
         print OUT_Can "{";

         print OUT_Can "\"No\":";
         print OUT_Can "\"";
         print OUT_Can $array[0];
         print OUT_Can "\"";
         print OUT_Can ",";

         print OUT_Can "\"gRNA\":";
         print OUT_Can "\"";
         print OUT_Can $array[1];
         print OUT_Can "\"";
         print OUT_Can ",";

         print OUT_Can "\"gRNA_start\":";
         print OUT_Can "\"";
         print OUT_Can $array[2];
         print OUT_Can "\"";
         print OUT_Can ",";

         print OUT_Can "\"gRNA_end\":";
         print OUT_Can "\"";
         print OUT_Can $array[3];
         print OUT_Can "\"";
         print OUT_Can ",";

         print OUT_Can "\"GC\":";
         print OUT_Can "\"";
         print OUT_Can $array[4];
         print OUT_Can "\"";
         print OUT_Can ",";

         print OUT_Can "\"num_targets\":";
         print OUT_Can "\"";
         print OUT_Can $array[5];
         print OUT_Can "\"";  
           

         print OUT_Can "}";

        if (!eof) {  # check for end of last file
         print OUT_Can ",";
        }
                                                     
     }

}

print OUT_Can "]}";

close OUT_Can;
close IN_Can;

}#end of sub single_gRNA
