<?php
$seq = $_GET['seq']; 
$protospacer = $_GET['gRNA']; 
$PFS = $_GET['PFS']; 
$Nucleotide = array();
$Nucleotide['A']='U';
$Nucleotide['U']='A';
$Nucleotide['C']='G';
$Nucleotide['G']='C';

$protospacer_array=str_split($protospacer);
$gRNA='';
$length=count($protospacer_array);
$vertical_line='';
for ($i=0; $i<$length; $i++){
    $nucleo=$protospacer_array[$i];
    $gRNA=$gRNA.$Nucleotide[$nucleo];
    $vertical_line=$vertical_line."|";

}

$spacer_pre_protospacer='';
for ($i=0; $i<5+intval(($length-11)/2); $i++){
     $spacer_pre_protospacer=$spacer_pre_protospacer."&nbsp;";   
}

$spacer_aft_protospacer='';
for ($i=0; $i<$length-intval(($length-11)/2)-11; $i++){  //11 is the length of the word "protospacer"
     $spacer_aft_protospacer=$spacer_aft_protospacer."&nbsp;";   
}

$spacer_pre_line='';
for ($i=0; $i<5+$length+8; $i++){
     $spacer_pre_line=$spacer_pre_line."&nbsp;";   
}

$spacer_pre_crRNA='';
for ($i=0; $i<5+intval(($length-5)/2); $i++){
     $spacer_pre_crRNA=$spacer_pre_crRNA."&nbsp;";   
}

$spacer_aft_crRNA='';
for ($i=0; $i<$length-intval(($length-5)/2)-5+2; $i++){
     $spacer_aft_crRNA=$spacer_aft_crRNA."&nbsp;";   
}

$spacer_pre_image='';
for ($i=0; $i<intval((5+$length+17)/2)-15; $i++){
     $spacer_pre_image=$spacer_pre_image."&nbsp;";   
}


?>


<html>
   <head>
     <link href="<?php echo ROOT_PATH.'/layout/css/help.css'?>" rel="stylesheet" type="text/css">
     <link href="./tableview/layout.css" rel="stylesheet" type="text/css" /> 
     <link href="https://code.jquery.com/ui/1.11.3/themes/smoothness/jquery-ui.css" rel="stylesheet" type="text/css" />	
     <link href="https://cdn.datatables.net/1.10.8/css/dataTables.jqueryui.min.css" rel="stylesheet" type="text/css" />
     <script src="https://code.jquery.com/jquery-1.11.3.min.js" type="text/javascript"></script>
     <script src="https://cdn.datatables.net/1.10.8/js/jquery.dataTables.min.js" type="text/javascript"></script>
     <script src="https://cdn.datatables.net/1.10.8/js/dataTables.jqueryui.min.js" type="text/javascript"></script>

     <script src="https://cdn.datatables.net/plug-ins/1.10.9/sorting/natural.js" type="text/javascript"></script>

   </head>

   <body>
     <div id='content'> 	    	    
     </div>
       
       <script type="text/javascript">
 
          var spacer_pre_protospacer = "<?php echo $spacer_pre_protospacer;?>";
          var spacer_aft_protospacer = "<?php echo $spacer_aft_protospacer;?>";
          //var FirstLine = spacer_pre_protospacer+'protospacer'+spacer_aft_protospacer+'PFS';
          var spacer_pre_crRNA = "<?php echo $spacer_pre_crRNA;?>";
          var spacer_aft_crRNA = "<?php echo $spacer_aft_crRNA;?>";
          var protospacer = "<?php echo $protospacer;?>";
          var spacer_pre_line = "<?php echo $spacer_pre_line;?>";
          var spacer_pre_image = "<?php echo $spacer_pre_image;?>";
          
      
          var PFS = "<?php echo $PFS;?>";
          var vertical_line = "<?php echo $vertical_line;?>";
          var gRNA = "<?php echo $gRNA;?>";

          $('#content').html( "<span style='font-family: monospace; font-size: 20;'>"+spacer_pre_protospacer+"<b>Protospacer</b>"+spacer_aft_protospacer+"<font color='#fe7032'><b>PFS</b></font>"+"<br>5'-.."+"<a style='background-color: #ccffff'>"+protospacer+"</a>"+"<font color='#fe7032'>"+PFS+"</font>"+"..-3'<br>"+"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+vertical_line+"<br>3'-.."+"<font color='#cc66db'>"+gRNA+"</font>"+"CAAAAUCAGGGGAAGC<br>"+spacer_pre_line+"||||&nbsp;&nbsp;&nbsp;&nbsp;U<br>"+spacer_pre_crRNA+"<b>crRNA</b>"+spacer_aft_crRNA+"5'-CCACCCCAAUA<br>"+spacer_pre_image+"<img src='../layout/images/c2c2.jpg' alt='c2c2' style='width:700px;height:550px;'></span>" 
          

          );
   

       </script>
      
   </body>
</html>














