#!/usr/bin/perl -w
use strict;

my $uploaddir=shift; 
my $filename=shift;  

my $file_name=$uploaddir.$filename;
open(IN_file,"<$file_name") or die "Can't open file: $file_name\n";

my $outfile_name=$uploaddir.'query_seq.txt';
open(OUT_file, ">", $outfile_name);

my $string='';
while(my $line=<IN_file>){
    chomp($line);
    $line =~ s/\r$//;
    if ($line =~ /^>/){

    }else{
      $line=uc $line;   #add here
      $string=$string.$line;
    }
}
#print OUT_file "\'";
print OUT_file $string;
#print OUT_file "\'";


close IN_file;
close OUT_file;
