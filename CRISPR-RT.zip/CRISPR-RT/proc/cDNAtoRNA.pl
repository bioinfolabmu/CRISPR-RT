#! /usr/bin/perl -w
use strict;

my %IUB_com=(                 #IUB complementary
           'G'=>'C',
           'A'=>'U',
           'T'=>'A',
           'C'=>'G',
           'N'=>'N'
);

my $cDNA_seq = shift;

$cDNA_seq = uc $cDNA_seq;

my $cDNA_seq_rev = reverse $cDNA_seq;

my @array = split(//,$cDNA_seq_rev);

my $RNA_seq = '';
for (my $i = 0; $i <= $#array; $i++){
    $RNA_seq = $RNA_seq.$IUB_com{$array[$i]};    
}

print "$RNA_seq\n";
