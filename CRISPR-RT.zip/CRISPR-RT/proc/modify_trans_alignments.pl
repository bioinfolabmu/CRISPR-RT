#! /usr/bin/perl -w
use strict;

my $Offtargets_transcriptome_file=shift;
my $dir=shift;
my $output=$dir."Bowtie2_Offtargets_transcriptome_modified.sam";
open(IN,"<$Offtargets_transcriptome_file") or die "Can't open file: $Offtargets_transcriptome_file\n";
open(OUT,">$output");

while (my $line=<IN>)  
{
  chomp($line);
  $line =~ s/\r$//;
  
  if($line =~ /^@/){
    print OUT "$line\n";
  }else{
    
    my @array=split(/\t/,$line);
    my $YT_index;
    
    for(my $i = 0; $i<=$#array; $i++){
        if($array[$i] =~ /^YT:Z/){
            $YT_index=$i;
        }

    }

    $array[$YT_index] = $array[$YT_index].":".$array[5];
    my $new_line='';
    for (my $j = 0; $j<=$YT_index; $j++){
        $new_line=$new_line.$array[$j]."\t";
    }
    if ($YT_index<$#array){
        for (my $k = $YT_index+1; $k<=$#array; $k++){
           $new_line=$new_line.$array[$k]."\t";
        }

    }
    $new_line =~ s/\t$//;
    print OUT "$new_line\n";
    
  }
    
}

close IN;
close OUT;
