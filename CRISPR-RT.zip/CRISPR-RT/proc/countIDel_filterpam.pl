#! /usr/bin/perl -w
use strict;

#print "please input the forward strand file:\n";
my $forward_file=shift;

#print "please input the reverse strand file:\n";
my $reverse_file=shift;
my $dir=shift;
my $offtarget_pam_length=shift;
my $output_forward=$dir."countIDel_forward.sam";
open(IN_forward,"<$forward_file") or die "Can't open file: $forward_file\n";
open(OUT_forward,">$output_forward");
#select OUT; 
while (my $line=<IN_forward>)  
{
    chomp($line);
    $line =~ s/\r$//;
    my @array=split(/\t/,$line);
    
    #if ($array[5] =~ /(\d+)M$/ and $1>2){
     if ($array[5] =~ /(\d+)M$/ and $1>=$offtarget_pam_length){
      my @md=split(/:/,$array[$#array-1]);
      #if($md[2] =~ /(\d+)$/ and $1 >= 3){  
      if($md[2] =~ /(\d+)$/ and $1 >= $offtarget_pam_length){  
        my @cigar=split(//,$array[5]);
        my $insertion=0;
        my $deletion=0;
        for (my $i=0;$i<=$#cigar;$i++){
            if ($cigar[$i] eq 'I'){
                $insertion=$insertion+$cigar[$i-1];
            }
            if ($cigar[$i] eq 'D'){
                $deletion=$deletion+$cigar[$i-1];
            }
        }
        print OUT_forward "$line";
        print OUT_forward "\t$insertion\t$deletion\n";
      }
    }
    
}

close IN_forward;
close OUT_forward;

my $output_reverse=$dir."countIDel_reverse.sam";
open(IN_reverse,"<$reverse_file") or die "Can't open file: $reverse_file\n";
open(OUT_reverse,">$output_reverse");
#select OUT; 
while (my $line=<IN_reverse>)  
{
    chomp($line);
    $line =~ s/\r$//;
    my @array=split(/\t/,$line);
    #if ($array[5] =~ /^(\d+)M/ and $1>2){
    if ($array[5] =~ /^(\d+)M/ and $1>=$offtarget_pam_length){
      my @md=split(/:/,$array[$#array-1]);
      #if($md[2] =~ /^(\d+)/ and $1 >= 3){
      if($md[2] =~ /^(\d+)/ and $1 >= $offtarget_pam_length){
        my @cigar=split(//,$array[5]);
        my $insertion=0;
        my $deletion=0;
        for (my $i=0;$i<=$#cigar;$i++){
            if ($cigar[$i] eq 'I'){
                $insertion=$insertion+$cigar[$i-1];
            }
            if ($cigar[$i] eq 'D'){
                $deletion=$deletion+$cigar[$i-1];
            }
        }
        print OUT_reverse "$line";
        print OUT_reverse "\t$insertion\t$deletion\n";
      }
    
    }
    
}
close IN_reverse;
close OUT_reverse;
