#! /usr/bin/perl -w
use strict;

my %IUB=(                     #IUB code for target
           'G'=>'G',
           'A'=>'A',
           'U'=>'U',
           'C'=>'C',
           'R'=>'[AG]',
           'Y'=>'[CU]',
           'M'=>'[AC]',
           'K'=>'[GU]',
           'S'=>'[CG]',
           'W'=>'[AU]',
           'H'=>'[ACU]',
           'B'=>'[CGU]',
           'V'=>'[ACG]',
           'D'=>'[AGU]',
           'N'=>'[ACGU]',
 
        );
######modify
my %IUB_off=(                     #IUB code for off target
           'G'=>'G',
           'A'=>'A',
           'U'=>'T',
           'C'=>'C',
           'R'=>'AG',
           'Y'=>'CT',
           'M'=>'AC',
           'K'=>'GT',
           'S'=>'CG',
           'W'=>'AT',
           'H'=>'ACT',
           'B'=>'CGT',
           'V'=>'ACG',
           'D'=>'AGT',
           'N'=>'ACGT',
 
        );
##############

my %IUB_com=(                 #IUB complementary
           'G'=>'C',
           'A'=>'T',
           'U'=>'A',
           'C'=>'G',
           'R'=>'TC',
           'Y'=>'GA',
           'M'=>'TG',
           'K'=>'CA',
           'S'=>'GC',
           'W'=>'TA',
           'H'=>'TAG',
           'B'=>'GCA',
           'V'=>'TGC',
           'D'=>'TAC',
           'N'=>'ACGT'   
        );


#Input the length of gRNA
my $gRNAlength=shift; 

#Input the location of user's RNA file
my $file_dir=shift;
my $file_name=shift;
my $file=$file_dir.$file_name;

#Input target PFS sequence
my $targetPFS=shift;
chomp($targetPFS);
my $targetPFS_length=length($targetPFS);

################Modify
#Input off-target PFS sequence
my $offPFS=shift;
chomp($offPFS);
my $offPFS_length=length($offPFS);

#my $offPFS_rev=reverse $offPFS;
#my @array_offPFS_rev=split(//,$offPFS_rev);
my @array_offPFS=split(//,$offPFS);
$offPFS='';
for (my $i=0;$i<=$#array_offPFS;$i++){     
    $offPFS=$offPFS.$IUB_off{$array_offPFS[$i]}.":";

}
$offPFS =~ s/:$//;

###################################
#Change target PFS to IUB code
my @array_pfs=split(//,$targetPFS);
my $pfs='';
for (my $i=0;$i<=$#array_pfs;$i++){    
    $pfs=$pfs.$IUB{$array_pfs[$i]};

}

#Open the uesr's RNA file AND connect the sequence to one signle sequence
open(INPUT,"<$file") or die "Cant't open file: $file\n";
my $seq='';
while (my $line=<INPUT>)  
{
    chomp($line);
    $line =~ s/\r$//;
    if($line=~/>/){
    }else{
        $line=uc $line; 
        $seq=$seq.$line;
    }

}
close INPUT;

#Compute all the target candidates and put them into file "Target_Candidates.txt"
my $seq_len = length($seq);
my @array=split(//,$seq);
my $count=0;
my $output=$file_dir."Target_Candidates.txt";
open (OUT,">$output");
print OUT "No	Protospacer+PFS	start	end\n";
for (my $i=0;$i<=$#array-$targetPFS_length+1;$i++){
    my $seq_pfs = '';
    for (my $num=$i;$num<=$i+$targetPFS_length-1;$num++){
        $seq_pfs=$seq_pfs.$array[$num];
    }
    if ($seq_pfs =~ /^$pfs$/){
         if($i-$gRNAlength>=0){
            $count++;
            print OUT "$count\t";
            my $gRNA_PFS='';
            for(my $q=$i-$gRNAlength;$q<=$i+$targetPFS_length-1;$q++){
               $gRNA_PFS=$gRNA_PFS.$array[$q];
            }
            my $gRNA_PFS_start=$i-$gRNAlength+1;
            my $gRNA_PFS_end=$i+$targetPFS_length-1+1;
            print OUT "$gRNA_PFS\t$gRNA_PFS_start\t$gRNA_PFS_end\n";
         }
     }
}
close OUT;

#print out the number of target candidates
print "$count";

#Generate the off-target seaching file for all the target candidates
open(IN,"<$output") or die "Cant't open file: $output\n";
my $off_gRNA='';
my $off_pfses='';
my @off_pfs=split(/:/,$offPFS);

my @chr;
for(my $i=0;$i<$offPFS_length;$i++){
    @{$chr[$i]}=split(//,$off_pfs[$i]);
}

for (permute(@chr)){
   my $string='';
   for(my $i=0;$i<=$#$_;$i++){
      $string=$string.$$_[$i];
   }
   $off_pfses=$off_pfses.$string.";" ;

}

sub permute {
  my $last = pop @_;
  unless (@_) {
    return map [$_], @$last;
  }
  return map { my $left = $_; map [@$left, $_], @$last } permute(@_);
}


my @off_pfses=split(/;/,$off_pfses);

my $num=1;

my $filename=$file_dir."Candidates_Search.fa";
open (OUTPUT,">$filename");
while (my $line=<IN>){
    chomp($line);
    $line =~ s/\r$//;
    if ($line=~/^\d/){
       
       my @RNAs_array=split(/\t/,$line);
       my @RNA_PFS=split(//,$RNAs_array[1]);
       for (my $i=0;$i<=$#RNA_PFS-$targetPFS_length;$i++){  
           $off_gRNA=$off_gRNA.$RNA_PFS[$i];

       }
#########modify
       #my $off_gRNA_rev=reverse $off_gRNA;
           #print "$off_gRNA_rev\n";
       my @array_off_gRNA=split(//,$off_gRNA);
       $off_gRNA='';
       for (my $i=0;$i<=$#array_off_gRNA;$i++){    
            $off_gRNA=$off_gRNA.$IUB_off{$array_off_gRNA[$i]};
 
       }

       my $single_num=1;
       for(my $i=0;$i<=$#off_pfses;$i++){
           #my $off_PFS_RNA=$off_pfses[$i].$off_gRNA; #In CDNA, it's PFS+gRNA
           my $off_RNA_PFS=$off_gRNA.$off_pfses[$i];
           print OUTPUT ">Candidate".$num."_single".$single_num."\n";
           print OUTPUT "$off_RNA_PFS\n";
           $single_num++;
       }
       $off_gRNA='';
       $num++;

    }
    
}

close IN;
close OUTPUT;
