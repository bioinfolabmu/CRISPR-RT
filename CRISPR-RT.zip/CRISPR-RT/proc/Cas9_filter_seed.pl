#! /usr/bin/perl -w
use strict;
my $offtarget_pam_length=shift;
#print "please input the length of seed region:\n";
my $seed_length=shift;
#print "please input the maximum total number of mismatches and Indels in seed region:\n";
my $num_MisID=shift;
##########bulge strand number
#print "please inupt the maximum number of strands that can tolerate bulges:\n";
#my $num_BulgeStrand=<STDIN>;
###########
#print "please input single_pam.sam file:\n";
my $file=shift;
my $out_dir=shift;

open(IN,"<$file") or die "Can't open file: $file\n";

my $out=$out_dir."filter_seed.sam";
open(OUT,">$out");

#my $forward='';
#my $reverse='';
#my $count_BulgeStrand=0;
while (my $line=<IN>)  
{

    chomp($line);
    $line =~ s/\r$//;
    my @array_line=split(/\t/,$line);
    if ($array_line[0] eq 'Forward')    ##################deal with forward strand
    {    
        ######bulge strand number
#        if($array_line[6]=~/I/ or $array_line[6]=~/D/){
#            $count_BulgeStrand=$count_BulgeStrand+1;
#        } 
       ############
        my $read=$array_line[10];
        my @array_read=split(//,$read);
        my $string=$array_line[6];
        my $md=$array_line[$#array_line-1];
        my @mdz=split(/:/,$md);
        $mdz[2] =~ s/\^//g;  #store md tag
#print $mdz[2]."\n";
        my $new_cigar='';
        my @array=split(//,$string);

#######rebuild read##############
for (my $i=0;$i<=$#array;$i++){
    if ($array[$i]=~/\d/){
        $new_cigar=$new_cigar.$array[$i];
    }
    if ($array[$i]=~/[A-Z]/){
        $new_cigar=$new_cigar.$array[$i].";";
    }

}
#print "$new_cigar\n";
my $rebuild_read='';
my $k=0;
my @cigar=split(/;/,$new_cigar);
for (my $i=0;$i<=$#cigar;$i++){
   #print $cigar[$i]."\n";
   if ($cigar[$i]=~/(\d+)([A-Z])/){

      if ($2 ne 'D'){
          for(my $pos=$k;$pos<$k+$1;$pos++){
              $rebuild_read=$rebuild_read.$array_read[$pos];
          }
          $k=$k+$1;
      }else{
              for (my $j=0;$j<$1;$j++){
                  $rebuild_read=$rebuild_read."-";
              }
          }

   }

}
#print "$rebuild_read\n";

###########################################

#######rebuild reference string##########
my $reference='';
my @md_string=split(//,$mdz[2]);
for (my $i=0;$i<=$#md_string;$i++){
   if ($md_string[$i] =~ /[0-9]/){
     if($i+1<=$#md_string){
        if ($md_string[$i+1] =~ /[0-9]/){
            my $digit=$md_string[$i].$md_string[$i+1];
            #print $digit."\n";
            for (my $j=0;$j<$digit;$j++){
               $reference=$reference."M";
            }
            $i=$i+1;
        }
        else{
              for (my $j=0;$j<$md_string[$i];$j++){
                 $reference=$reference."M";
            }
        } 
     } 
     else{
              for (my $j=0;$j<$md_string[$i];$j++){
                 $reference=$reference."M";
              }
     }          
             
   }
   if($md_string[$i] =~ /[A-Z]/){
       $reference=$reference.$md_string[$i];

   }

}
#print "$reference\n";

#print "$new_cigar\n";

my $rebuild_reference='';
my $h=0;
my @array_reference=split(//,$reference);
for (my $i=0;$i<=$#cigar;$i++){
   #print $cigar[$i]."\n";
   if ($cigar[$i]=~/(\d+)([A-Z])/){

      if ($2 ne 'I'){
          for(my $pos=$h;$pos<$h+$1;$pos++){
              $rebuild_reference=$rebuild_reference.$array_reference[$pos];
          }
          $h=$h+$1;
      }
      else{
              for (my $j=0;$j<$1;$j++){
                  $rebuild_reference=$rebuild_reference."-";
              }
      }

   }

}
#print "$rebuild_reference\n";

###########################################
        my @rebuild_reference=split(//,$rebuild_reference);
        my $num_match=0;
        #for(my $i=$#rebuild_reference-3;$i>$#rebuild_reference-3-$seed_length;$i--){
        for(my $i=$#rebuild_reference-$offtarget_pam_length;$i>$#rebuild_reference-$offtarget_pam_length-$seed_length;$i--){
            if($rebuild_reference[$i] eq 'M'){
                $num_match=$num_match+1;
     
            }
        }
        #print "$num_match\n";
        if ($num_match >= $seed_length-$num_MisID){
           # for (my $a=0;$a<=$#array_line;$a++){ 
           #         $forward=$forward.$array_line[$a]."\t";
           #     }  
           # $forward =~ s/\t$//;
            my @read_array=split(//,$rebuild_read);
            my @reference_array=split(//,$rebuild_reference);
            my @origin_ref;
            for (my $position=0;$position<=$#reference_array;$position++){
                if ($reference_array[$position] eq 'M'){
                    push(@origin_ref,$read_array[$position]);
                }elsif ($reference_array[$position] eq '-'){

                }else{
                    push(@origin_ref,$reference_array[$position]);
                }
            }
            print OUT "$line\t";
            print OUT @origin_ref;
            print OUT "\n";
           # $forward='';
        }
=begin
        else{
                  $forward='';
        }
=cut

    }
    if ($array_line[0] eq 'Reverse'){   #######################deal with reverse strand
        ###############bulge strand number
#        if($array_line[6]=~/I/ or $array_line[6]=~/D/){
#            $count_BulgeStrand=$count_BulgeStrand+1;
#        } 
        ###############
        my $read=$array_line[10];
        my @array_read=split(//,$read);
        my $string=$array_line[6];
        my $md=$array_line[$#array_line-1];
        my @mdz=split(/:/,$md);
        $mdz[2] =~ s/\^//g;  #store md tag
#print $mdz[2]."\n";
        my $new_cigar='';
        my @array=split(//,$string);

#######rebuild read##############
for (my $i=0;$i<=$#array;$i++){
    if ($array[$i]=~/\d/){
        $new_cigar=$new_cigar.$array[$i];
    }
    if ($array[$i]=~/[A-Z]/){
        $new_cigar=$new_cigar.$array[$i].";";
    }

}
#print "$new_cigar\n";
my $rebuild_read='';
my $k=0;
my @cigar=split(/;/,$new_cigar);
for (my $i=0;$i<=$#cigar;$i++){
   #print $cigar[$i]."\n";
   if ($cigar[$i]=~/(\d+)([A-Z])/){

      if ($2 ne 'D'){
          for(my $pos=$k;$pos<$k+$1;$pos++){
              $rebuild_read=$rebuild_read.$array_read[$pos];
          }
          $k=$k+$1;
      }else{
              for (my $j=0;$j<$1;$j++){
                  $rebuild_read=$rebuild_read."-";
              }
          }

   }

}
#print "$rebuild_read\n";

###########################################

#######rebuild reference string##########
my $reference='';
my @md_string=split(//,$mdz[2]);
for (my $i=0;$i<=$#md_string;$i++){
   if ($md_string[$i] =~ /[0-9]/){
     if($i+1<=$#md_string){
        if ($md_string[$i+1] =~ /[0-9]/){
            my $digit=$md_string[$i].$md_string[$i+1];
            #print $digit."\n";
            for (my $j=0;$j<$digit;$j++){
               $reference=$reference."M";
            }
            $i=$i+1;
        }
        else{
              for (my $j=0;$j<$md_string[$i];$j++){
                 $reference=$reference."M";
            }
        } 
     } 
     else{
              for (my $j=0;$j<$md_string[$i];$j++){
                 $reference=$reference."M";
              }
     }          
             
   }
   if($md_string[$i] =~ /[A-Z]/){
       $reference=$reference.$md_string[$i];

   }

}
#print "$reference\n";

#print "$new_cigar\n";

my $rebuild_reference='';
my $h=0;
my @array_reference=split(//,$reference);
for (my $i=0;$i<=$#cigar;$i++){
   #print $cigar[$i]."\n";
   if ($cigar[$i]=~/(\d+)([A-Z])/){

      if ($2 ne 'I'){
          for(my $pos=$h;$pos<$h+$1;$pos++){
              $rebuild_reference=$rebuild_reference.$array_reference[$pos];
          }
          $h=$h+$1;
      }
      else{
              for (my $j=0;$j<$1;$j++){
                  $rebuild_reference=$rebuild_reference."-";
              }
      }

   }

}
#print "$rebuild_reference\n";

###########################################
        my @rebuild_reference=split(//,$rebuild_reference);
        my $num_match=0;
        #for(my $i=3;$i<3+$seed_length;$i++){
        for(my $i=$offtarget_pam_length;$i<$offtarget_pam_length+$seed_length;$i++){
            if($rebuild_reference[$i] eq 'M'){
                $num_match=$num_match+1;
            }
        }
        if ($num_match >= $seed_length-$num_MisID){
           # for (my $a=0;$a<=$#array_line;$a++){ 
           #         $reverse=$reverse.$array_line[$a]."\t";
            #    }  
          #      $reverse =~ s/\t$//;
                my @read_array=split(//,$rebuild_read);
                my @reference_array=split(//,$rebuild_reference);
                my @origin_ref;
                for (my $position=0;$position<=$#reference_array;$position++){
                   if ($reference_array[$position] eq 'M'){
                       push(@origin_ref,$read_array[$position]);
                   }elsif ($reference_array[$position] eq '-'){

                   }else{
                       push(@origin_ref,$reference_array[$position]);
                   }
                }
                print OUT "$line\t";
                print OUT @origin_ref;
                print OUT "\n";
              #  $reverse='';
        }
=begin
        else{
                  $reverse='';
        }

        if($count_BulgeStrand<=$num_BulgeStrand and $forward ne '' and $reverse ne ''){   
             print OUT $forward."\n";
             print OUT $reverse."\n";
             $forward='';
             $reverse='';
             $count_BulgeStrand=0;
         }
         else
         {
             $forward='';
             $reverse='';
             $count_BulgeStrand=0;
         }
=cut


    }

}

close IN;
close OUT;

