#!/usr/bin/env python
# -*- coding: UTF-8 -*-

# enable debugging
import sys
import cgitb
cgitb.enable()

print(sys.path)
import numpy
import scipy
import sklearn
print(sklearn.__version__)
import pickle
import pandas
import Bio
print "Content-Type: text/plain;charset=utf-8"
print "Hello World!"



