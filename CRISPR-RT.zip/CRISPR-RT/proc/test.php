<?php
$target_pam_length = 3;
$sring="AGAAAAAAAAAAAAGGGGGTTTCGG";

?>



<html>
  <head>
    <link href="https://code.jquery.com/ui/1.11.3/themes/smoothness/jquery-ui.css" rel="stylesheet" type="text/css" />	
   <link href="https://cdn.datatables.net/1.10.8/css/dataTables.jqueryui.min.css" rel="stylesheet" type="text/css" />
    <script src="https://code.jquery.com/jquery-1.11.3.min.js" type="text/javascript"></script>
    <script src="https://cdn.datatables.net/1.10.8/js/jquery.dataTables.min.js" type="text/javascript"></script>
    <script src="https://cdn.datatables.net/1.10.8/js/dataTables.jqueryui.min.js" type="text/javascript"></script>

    <script src="https://cdn.datatables.net/plug-ins/1.10.9/sorting/natural.js" type="text/javascript"></script>

  </head>

  <body>

<div id='target'> 	    	    
    </div>
  
  
   <script type="text/javascript">




  $('#target').html("<span class='numbers'><?php echo $sring ?></span>");

$('.numbers').each(function() {
    $(this).html(
        $(this).html().substr(0, $(this).html().length-2)
          + "<span style='color: #3399ff'>"
          + $(this).html().substr(-<?php echo $target_pam_length ?>)
          + "</span>");
});





   </script>
   

  

  </body>



</html>
