#! /usr/bin/perl -w
use strict;
my $offtarget_pam_length=shift;
#print "please input the number of pairs:";
my $No_pairs=shift;
#print "please input the low bound of offset:\n";
my $low_offset=shift;
#print "please input the high bound of offset:\n";
my $high_offset=shift;
#print "please input file name of forward strand:";
my $forward=shift;
#print "please input file name of reverse strand:";
my $reverse=shift;
my $out_dir=shift;
my $name_candidate=shift;
my $name_chrom=shift;

my $gRNA_length=shift;

my %forward;     #store forward strand position
my %reverse;     #store reverse strand position

open(IN_forward,"<$forward") or die "Can't open file: $forward\n";
while (my $line=<IN_forward>)            #store forward strand position to %forward
{
    chomp($line);
    $line =~ s/\r$//;
    my @array=split(/\t/,$line);
    if(defined $forward{$array[0]}){
         $forward{$array[0]}=$forward{$array[0]}.$array[3].";";
    }else{
          $forward{$array[0]}=$array[3].";";
         }

}
close IN_forward;

open(IN_reverse,"<$reverse") or die "Can't open file: $reverse\n";
while (my $line=<IN_reverse>)           #store reverse strand position to %reverse
{
    chomp($line);
    $line =~ s/\r$//;
    my @array=split(/\t/,$line);
    #if($array[3]>=0 and $array[20]>=0 and $array[21]>=0){
       my $revise_pos=$array[3]-$array[$#array-1]+$array[$#array]; #revise position accroding to Insertion(-1) and Deletion(+1).
       if(defined $reverse{$array[0]}){
          $reverse{$array[0]}=$reverse{$array[0]}.$revise_pos.";";
       }else{
           $reverse{$array[0]}=$revise_pos.";";
         }
    #}else {
    #   print  $array[3].' '.$array[20].' '.$array[21]."\n";  
    #}

}
close IN_reverse;

#open(Forward,"<$forward") or die "Can't open file: $forward\n"; ##########?????????????
#open(Reverse,"<$reverse") or die "Can't open file: $reverse\n";#########??????????????


#my $output=$out_dir.'candidate'.$name_candidate.'_chr'.$name_chrom.'_filter_position.sam';
#open(OUT,">$output");
my $output=$out_dir.'filter_position.sam';
open(OUT,">>$output");
#print OUT "hello!";
#forward pos minus reverse pos

for (my $i=1;$i<=$No_pairs;$i++){
   if($forward{'Candidate'.$name_candidate.'_pair'.$i.'_a'} and $reverse{'Candidate'.$name_candidate.'_pair'.$i.'_b'}){
    my @array1=split(/;/,$forward{'Candidate'.$name_candidate.'_pair'.$i.'_a'});
    my @array2=split(/;/,$reverse{'Candidate'.$name_candidate.'_pair'.$i.'_b'});
    for(my $j=0;$j<=$#array1;$j++){
        for(my $k=0;$k<=$#array2;$k++){
            my $interval=$array1[$j]-$array2[$k];
            #if($interval>=$low_offset+$gRNA_length+3 and $interval<=$high_offset+$gRNA_length+3){
             if($interval>=$low_offset+$gRNA_length+$offtarget_pam_length and $interval<=$high_offset+$gRNA_length+$offtarget_pam_length){
                #print "forward:"."pair".$i."_a".":".$array1[$j]."\n";
                #print "reverse:"."pair".$i."_b".":".$array2[$k]."\n";
                open(Forward,"<$forward") or die "Can't open file: $forward\n";
                open(Reverse,"<$reverse") or die "Can't open file: $reverse\n";
                while (my $line=<Forward>)            
                {
                   
                    chomp($line);
                    $line =~ s/\r$//;
                    my @array=split(/\t/,$line);
                    
                    if ('Candidate'.$name_candidate.'_pair'.$i.'_a' eq $array[0] and $array1[$j] eq $array[3]){
                        my $forward='';
                        for (my $pos=0;$pos<=$#array-2;$pos++){ 
                            $forward=$forward.$array[$pos]."\t";
                        }  
                        $forward =~ s/\t$//;
                        print OUT "Forward\t$forward\n";
                    }

                 }
                  while (my $line=<Reverse>)            
                {
                    chomp($line);
                    $line =~ s/\r$//;
                    my @array=split(/\t/,$line);
                    if ('Candidate'.$name_candidate.'_pair'.$i.'_b' eq $array[0] and $array2[$k] eq $array[3]-$array[$#array-1]+$array[$#array]){
                        my $reverse='';
                        for (my $pos=0;$pos<=$#array-2;$pos++){ 
                            $reverse=$reverse.$array[$pos]."\t";
                        }  
                        $reverse =~ s/\t$//;
                        print OUT "Reverse\t$reverse\n";
                    }

                 }
                 close Forward;
                 close Reverse;

                
            }

        }
    }
   }
   if($forward{'Candidate'.$name_candidate.'_pair'.$i.'_b'} and $reverse{'Candidate'.$name_candidate.'_pair'.$i.'_a'}){
    my @array3=split(/;/,$forward{'Candidate'.$name_candidate.'_pair'.$i.'_b'});
    my @array4=split(/;/,$reverse{'Candidate'.$name_candidate.'_pair'.$i.'_a'});
    for(my $j=0;$j<=$#array3;$j++){
        for(my $k=0;$k<=$#array4;$k++){
            my $interval=$array3[$j]-$array4[$k];
            #if($interval>=$low_offset+$gRNA_length+3 and $interval<=$high_offset+$gRNA_length+3){
             if($interval>=$low_offset+$gRNA_length+$offtarget_pam_length and $interval<=$high_offset+$gRNA_length+$offtarget_pam_length){
                #print "forward:"."pair".$i."_b".":".$array3[$j]."\n";
                #print "reverse:"."pair".$i."_a".":".$array4[$k]."\n";
                open(Forward,"<$forward") or die "Can't open file: $forward\n";
                open(Reverse,"<$reverse") or die "Can't open file: $reverse\n";
                while (my $line=<Forward>)            
                {

                    
                    chomp($line);
                    $line =~ s/\r$//;
                    my @array=split(/\t/,$line);
                    
                    
              
                    if ('Candidate'.$name_candidate.'_pair'.$i.'_b' eq $array[0] and $array3[$j] eq $array[3]){
                        my $forward='';
                        for (my $pos=0;$pos<=$#array-2;$pos++){ 
                            $forward=$forward.$array[$pos]."\t";
                        }  
                        $forward =~ s/\t$//;
                        print OUT "Forward\t$forward\n";
                    }

                 }
                  while (my $line=<Reverse>)            
                {
                    chomp($line);
                    $line =~ s/\r$//;
                    my @array=split(/\t/,$line);
                  
                    if ('Candidate'.$name_candidate.'_pair'.$i.'_a' eq $array[0] and $array4[$k] eq $array[3]-$array[$#array-1]+$array[$#array]){
                        my $reverse='';
                        for (my $pos=0;$pos<=$#array-2;$pos++){ 
                            $reverse=$reverse.$array[$pos]."\t";
                        }  
                        $reverse =~ s/\t$//;
                        print OUT "Reverse\t$reverse\n";
                    }

                 }
                 close Forward;
                 close Reverse;




            }

        }
    }
   } 
}
close OUT;

