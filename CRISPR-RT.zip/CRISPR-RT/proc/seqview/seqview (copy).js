window.onload=initAll;
var query_seq;        //a global variable for a complete sequence
var flag_ruler=0;     //a global variable for a ruler flag 
var flag_spacer=0;    //a global variable for a spacer flag
var flag_rvcmp=0;     //a global variable for doing seq reverse complementary or not
var motif;            //a global variable for a motif used for search or highlighting

var h={};
h['C']='C';
h['A']='A';
h['T']='T';
h['G']='G';
h['R']='[AG]';
h['Y']='[CT]';
h['M']='[AC]';
h['K']='[GT]';
h['S']='[CG]';
h['W']='[AT]';
h['H']='[ACT]';
h['B']='[CGT]';
h['V']='[ACG]';
h['D']='[AGT]';
h['N']='[ACGT]';



function searchKeyPress(e)
{
    // look for window.event in case event isn't passed in
    e = e || window.event;
    if (e.keyCode == 13)
    {
        document.getElementById('search').click();
        return false;
    }
    return true;
}


function initAll() {
	// Check browser compatiability with javascript
	console.info("initAll() start ..."); 
	console.log("Entering initAll()");
	if (!document.getElementById) {
		alert("Your browser doesn't support this script");
	}
	// Parse parameters passed into this javascript
	var script_tag = document.getElementById('searcher');
	var query = script_tag.src.replace(/^[^\?]+\??/,''); 
	// Parse the querystring into arguments and parameters
	var vars = query.split("&");
	var args = {};
	for (var i=0; i<vars.length; i++) {
	     var pair = vars[i].split("=");
	     // decodeURI doesn't expand "+" to a space.
	     args[pair[0]] = decodeURI(pair[1]).replace(/\+/g, ' ');   
	}
	//two parameters passed by /index.js?flag=1&querySeq=XYZ
	flag_ruler  = args['rulerFlag'];   //initiating value for a global variable
	flag_spacer = args['spacerFlag'];  //initiating value for a global variable
	query_seq = args['querySeq'];        //initiating value for a global variable
	pattern = document.getElementById("motif").value;
	//alert('spacer['+spacerflag+']ruler['+rulerFlag+']Seq['+query_seq+']');     //popping up a message box
	//present sequence with options passed from seqview.php files
	document.getElementById("displayedSeq").innerHTML = getDisplaySeq(query_seq,flag_ruler,flag_spacer,flag_rvcmp,pattern);
    //present sequence with options selected/changed by a user
	document.getElementById("search").onclick=action;
	document.getElementById("revcomp").onclick=action;
	document.getElementById("spacer").onclick=action;
	document.getElementById("ruler").onclick=action;
	//debugging purpose
	//document.getElementById("search").onclick=showMessage;
	//document.getElementById("spacer").onclick=showMessage;
	console.info("initAll() ended"); 
	console.log("Out of initAll()");
}

function action(){
  console.info("action() start ..."); 
  console.log("Entering action()");
  //detection status of three check boxes and one button
  switch(this.id) {
    case "search":
      document.getElementById("motifSeq").innerHTML = document.getElementById("motif").value;	
      break;
    case "revcomp":
      if (document.getElementById("revcomp").checked) {
    	 flag_rvcmp=1;
      //   alert("revcomp checkbox is checked ["+flag_rvcmp+']');
	  }
      else {
    	 flag_rvcmp=0;
        // alert("revcomp checkbox is unchecked ["+flag_rvcmp+']');
      }
      break;
	case "ruler":
	  if (document.getElementById("ruler").checked) {
		 flag_ruler=1;
         //alert("ruler checkbox is checked ["+flag_ruler+']');
	  }
      else {
    	 flag_ruler=0;
         //alert("ruler checkbox is unchecked ["+flag_ruler+']');
      }
	  break;
	case "spacer":
      if (document.getElementById("spacer").checked) {
    	 flag_spacer=1;
    	// alert("spacer checkbox is checked ["+flag_spacer+']');
	  }
      else {
    	 flag_spacer=0;
    	// alert("spacer checkbox is unchecked ["+flag_spacer+']');
      }
	  break;
	  default:
  }  // the endof switch
  var pattern = document.getElementById("motif").value;
  
  if (pattern != ''){
      pattern=pattern.toUpperCase(); //Convert the string to uppercase letters
      document.getElementById("displayedSeq").innerHTML = getDisplaySeq(query_seq,flag_ruler,flag_spacer,flag_rvcmp,pattern);
  }
  console.info("action() ended"); 
  console.log("Out of action()");
}

function showMessage() {
	switch(this.id) {
		case "search":
			alert("Search a motif");
			var ans=prompt("Enter a number","");
		    try {
		    	if (!ans||isNaN(ans)||ans<0){
		    		throw new Error ("Not a valid number");
		    	}
		    	alert("The square root of" + ans + " is " + Math.sqrt(ans));
		    }
		    catch (errMsg) {
		    	alert(errMsg.message);
		    }
			break;
		case "revcomp":
			alert("do reverse complement");
			break;
		case "ruler":
			alert("show ruler");
			break;
		case "spacer":
			alert("show spacer");
			break;
		default:
	}
}

function getDisplaySeq (thisSeq,thisRulerFlag,thisSpacerFlag,thisRvcmpFlag,pattern) 
{
	var inSeq=thisSeq;
	var seq_length=inSeq.length;
	var line_number=Math.ceil(seq_length/100);
	var seqOut=new String("");
	var seq100=new String("");
	var Space='';                  // can be '' or '&nbsp;'
	var space='&nbsp;';            // with fixed value
	var newline_char='<br/>';      // with fixed value
	var margin_space_num=line_number.toString().length+1;
	var margin_ruler='';
	var line_count=0;

	if (thisSpacerFlag==1) 
	{
		Space='&nbsp;';
	}
	else 
	{
		Space=''; 
	}

	if (thisRvcmpFlag==1) 
	{
		inSeq=reverseComplement(inSeq);
	}
	  
	if (thisRulerFlag==1)
	{
		for (var i=0; i<=margin_space_num; i=i+1) 
		{
			margin_ruler+=space;
		}
		seqOut=margin_ruler+
		      space+space+space+space+space+space+space+space+space+'1'+Space+
		      space+space+space+space+space+space+space+space+space+'2'+Space+
		      space+space+space+space+space+space+space+space+space+'3'+Space+
		      space+space+space+space+space+space+space+space+space+'4'+Space+
		      space+space+space+space+space+space+space+space+space+'5'+Space+
		      space+space+space+space+space+space+space+space+space+'6'+Space+
		      space+space+space+space+space+space+space+space+space+'7'+Space+
		      space+space+space+space+space+space+space+space+space+'8'+Space+
		      space+space+space+space+space+space+space+space+space+'9'+Space+
		      space+space+space+space+space+space+space+space+space+'10'+newline_char;  
	}
        
        var pattern_array=pattern.split("");
        var index;
        var new_pattern = "";
        for (index = 0; index < pattern_array.length; index++) {
            new_pattern += h[pattern_array[index]];
        }

	//var patt = new RegExp(pattern,"g");
        var patt = new RegExp(new_pattern,"g");
	var match_pos_arr_right = new Array();
	var match_pos_arr_left = new Array();
	var result;
	var patt_len = pattern.length;
	document.getElementById("motifSeq").innerHTML = "";
	while ((result = patt.exec(inSeq)) != null) 
	{
		match_pos_arr_right.push(patt.lastIndex);
		match_pos_arr_left.push(patt.lastIndex - patt_len);
		document.getElementById("motifSeq").innerHTML += "</br>" + (patt.lastIndex - pattern.length + 1) + " - " + patt.lastIndex;
	}
	console.log(match_pos_arr_right);
	console.log(match_pos_arr_left);

	var color = ['#87cefa','#b3ee3a','#eeee00','#ff83fa'];

	var replace_head = '<span style="background-color:'+color[1]+';">';
	var replace_tail = '</span>';
	var in_pattern_flag = 0;
	var line_count = 0;

	for (var i=0; i<seq_length; i++)
	{
		in_pattern_flag = 0;
		for (var tmp = match_pos_arr_left.length - 1; tmp >= 0; tmp--) 
		{
			if(i >= match_pos_arr_left[tmp])
			{
				if(i < match_pos_arr_right[tmp])
				{
					in_pattern_flag = 1;
				}
			}
		}
		var margin_line='';

		if(i%100 == 0)
		{
			line_count++;
			if(thisRulerFlag == 1)
			{
				n=margin_space_num-line_count.toString().length;
				for (var k=0; k<n; k++) 
				{
				  margin_line+=space;
				}
				seqOut=seqOut+newline_char+margin_line+line_count+space;
			}
			else
			{
				seqOut=seqOut+newline_char;
			}
		}
		else if (i%10 == 0)
		{
			seqOut=seqOut+Space;
		}

		if(in_pattern_flag == 0)
		{
			seqOut=seqOut+inSeq.substr(i,1);
		}
		else
		{
			seqOut=seqOut+replace_head+inSeq.substr(i,1)+replace_tail;
                        
		}
	}
	return seqOut;	
}

function reverseComplement(s) {
  var o = '';
  for (var i = s.length - 1; i >= 0; i--) {
	  if (s[i]=='A'||s[i]=='a'){
		  o += 'T'; 
	  }
	  else if (s[i]=='T'||s[i]=='t'){
		  o += 'A'; 
	  }
	  else if (s[i]=='G'||s[i]=='g'){
		  o += 'C'; 
	  }
	  else if (s[i]=='C'||s[i]=='c'){
		  o += 'G'; 
	  }
	  else {
		  o += s[i]; 
	  }
  }
  return o;
}
