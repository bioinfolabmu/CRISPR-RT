<?php
$uploaddir=$_GET["directory"];
$query_seq = file_get_contents($uploaddir.'query_seq.txt');         //read file content
$query_seq = trim(preg_replace('/\s\s+/', ' ', $query_seq));  //get rid of end-of-line character of the file content
?>
<!DOCTYPE html>
<html>
  <head>
   <title>seqview</title>
   <link href="seqview.css" rel="stylesheet" type="text/css" />
   <script type="text/javascript" id="searcher" src="seqview.js?rulerFlag=1&spacerFlag=1&querySeq=<?php echo $query_seq?>"></script>
  </head>
<body>
  <form>
		<fieldset> <!-- Group these elements (legend, label, span) together -->
			<legend><b>Sequence Viewer</b></legend>
				<span><input type="text" size="32" id="motif" name="motif" value="UG" onkeypress="return searchKeyPress(event);">
				<input type="button" value="Search Motif" id="search"></span> &nbsp&nbsp
				
			<label class="RevcompLable">Reverse Complement</label>
            <input type="checkbox" class="Revcomp" name="Reverse Complement" id="revcomp"/>
			<label class="RulerLable">Ruler</label>
			<input type="checkbox" class="Ruler" name="show Rulers" id="ruler" checked/>
			<label class="SpacerLable">Spacer</label>
			<input type="checkbox" class="Spacer" name="show Spacer" id="spacer" checked/>
		</fieldset>
  </form>      	
  <p id = "displayedSeq"></p>
  <font size="2">
  Motif Search Positions: <h id = "motifSeq"></h>  
  </font>     	
</body>
</html>
