<?php
include_once '../root_path.php';
define('ROOT_PATH','..');

 $CandidateID = $_GET['Candidate_ID']; 

 $UploaddirRelative = $_GET['uploaddir_relative']; 

 $NameFolder = $_GET['nameOfFolder']; 

 $uploaddir = $_GET['upload_dir']; 

 $ref_genome = $_GET['db']; 

 $resource_flag = 0;
 
 if (preg_match ("/phytozome/i", $ref_genome)){
     $resource_flag = 1;
 } else{
     $resource_flag = 0;
 }


system("perl OfftargetToJBrowse.pl $uploaddir $ref_genome $CandidateID"); //Generate specific offtarget sites bam file for JBrowse


?>


<html>
  <head>
    <link href="<?php echo ROOT_PATH.'/layout/css/help.css'?>" rel="stylesheet" type="text/css">
    <link href="./tableview/layout.css" rel="stylesheet" type="text/css" /> 
    <link href="https://code.jquery.com/ui/1.11.3/themes/smoothness/jquery-ui.css" rel="stylesheet" type="text/css" />	
    <link href="https://cdn.datatables.net/1.10.8/css/dataTables.jqueryui.min.css" rel="stylesheet" type="text/css" />
    <script src="https://code.jquery.com/jquery-1.11.3.min.js" type="text/javascript"></script>
    <script src="https://cdn.datatables.net/1.10.8/js/jquery.dataTables.min.js" type="text/javascript"></script>
    <script src="https://cdn.datatables.net/1.10.8/js/dataTables.jqueryui.min.js" type="text/javascript"></script>

    <script src="https://cdn.datatables.net/plug-ins/1.10.9/sorting/natural.js" type="text/javascript"></script>

  </head>
  <body>
<a href="<?php echo $UploaddirRelative ?>Candidate<?php echo $CandidateID;?>_offtargets.txt" download="Candidate<?php echo $CandidateID;?>_offtargets.txt" style="float:right">Download</a><br></br>

   <div id='content'> 	    	    
   </div>
   <script type="text/javascript">
    //var column="<?php echo $columnID;?>";
    var CandidateID="<?php echo $CandidateID;?>";
    
    var resource_flag="<?php echo $resource_flag;?>";

      var child_dir = "<?php echo $UploaddirRelative;?>";
      var child_file = child_dir + "Candidate" + CandidateID + "_offtargets_DataTable.txt";

      $('#content').html('<table id="child" class="display" width="100%" cellspacing="0" style="font-family: monospace;">'+
                       '<thead>'+
                          '<tr>'+
                          
                            '<th data-toggle="tooltip" title="  Number">No</th>'+
                            '<th data-toggle="tooltip" title="  The complementarity cDNA sequence of the target site in the transcriptome. ">cDNA Seq</th>'+
                            '<th data-toggle="tooltip" title="  The corresponding transcript ID of the target site in the transcriptome.">Transcript ID</th>'+
                            '<th data-toggle="tooltip" title="  The corresponding transcript name of the target site in the transcriptome.">Transcript Name</th>'+
                            '<th data-toggle="tooltip" title="  The corresponding gene ID of the target site.">Gene ID</th>'+
                            '<th data-toggle="tooltip" title="  The corresponding gene name of the target site.">Gene Name</th>'+
                            '<th data-toggle="tooltip" title="  The chromosome number of the corresponding gene of the target site.">Chr</th>'+
                            '<th data-toggle="tooltip" title="  The position of the corresponding gene sequence of the target site in the chromosome.">Pos</th>'+
                            '<th data-toggle="tooltip" title="  The strand of the corresponding gene of the target site in the chromosome.\x0A  + is the forward strand.\x0A  - is the reverse strand.">Str</th>'+
                            '<th data-toggle="tooltip" title="  The total number of mismatches and gaps between the target complementarity region of crRNA and the target site in the transcriptome.">M&G</th>'+
                            '<th data-toggle="tooltip" title="  The number of mismatches between the target complementarity region of crRNA and the target site in the transcriptome.">M</th>'+
                            '<th data-toggle="tooltip" title="  The number of gaps between the target complementarity region of crRNA and the target site in the transcriptome.">G</th>'+                            
                            '<th data-toggle="tooltip" title="  Visualizing the target site in JBrowse.">JB</th>'+
                          '</tr>'+
                       '</thead>'+
            '</table>');
  
	  


		 
      // `d` is the original data object for the row
      $(document).ready(function() {               
         var childtable = $('#child').DataTable( {
          "lengthMenu": [ [10, 25, 50, -1], [10, 25, 50, "All"] ],
          "language": {
            "lengthMenu": "Target Sites _MENU_ per page <span class=helper title=\"    This table shows the target sites in the transcriptome for one target cadidate. Because CRISPR-RT has converted the transcriptome mapping result to a genome mapping result, the information of target sites is displayed in genomic context.\x0A    Click JB links to visualize each target site in JBrowser.\x0A    Sort each column by clicking the column header\">?</span>"
            
          },
          "ajax": child_file,
          columnDefs: [
             { type: 'natural', targets: 2 }
          ],
          "columns": [
            
              { "data": "ID" },
              { "data": "Sequence" },
              { "data": "Transcript_Id", 
                "fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
                  if (resource_flag == 0){ 
                    var Transcript_Id=oData.Transcript_Id;
                    $(nTd).html('<a href="http://www.ensemblgenomes.org/id-transcript/' + Transcript_Id + '" target="_blank">' + oData.Transcript_Id + '</a>');
                  } else {
                    var Transcript_Id=oData.Transcript_Id;
                    var array = Transcript_Id.split(".");
                    array_len = array.length;
                    Transcript_Id = "";
                    for (i = 0; i < array_len-1; i++) {
                               Transcript_Id = Transcript_Id + array[i] + ".";
                    }
                    Transcript_Id = Transcript_Id.replace(/\.$/, "");
                    $(nTd).html('<a href="https://phytozome.jgi.doe.gov/pz/portal.html#!results?search=0&crown=1&star=1&method=0&searchText=' + Transcript_Id + '&offset=0" target="_blank">' + oData.Transcript_Id + '</a>');
                    
 
                  }
                } 

              },
              { "data": "Transcript_Name" },
              { "data": "Gene_Id", 
                "fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
                  if (resource_flag == 0){
                    var Gene_Id=oData.Gene_Id;
                    
                    $(nTd).html('<a href="http://www.ensemblgenomes.org/id-gene/' + Gene_Id + '" target="_blank">' + oData.Gene_Id + '</a>');

                    

                  } else {
                    var Gene_Id=oData.Gene_Id;
                    var array = Gene_Id.split(".");
                    array_len = array.length;
                    Gene_Id = "";
                    for (i = 0; i < array_len-1; i++) {
                               Gene_Id = Gene_Id + array[i] + ".";
                    }
                    Gene_Id = Gene_Id.replace(/\.$/, "");
                    $(nTd).html('<a href="https://phytozome.jgi.doe.gov/pz/portal.html#!results?search=0&crown=1&star=1&method=0&searchText=' + Gene_Id + '&offset=0" target="_blank">' + oData.Gene_Id + '</a>');

                  }
                } 

              },
              { "data": "Gene_Name" },
              { "data": "Chromosome" },
              { "data": "Position" },
              { "data": "Strand" },
              { "data": "Mis&Gap" },
              { "data": "Mis" },
              { "data": "Gap" },            
              { "data": "JBrowser", 
                "fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
                    var chr=oData.Chromosome;
                    var start=oData.Position;
                    var end= Number(oData.Position)+55;
                    $(nTd).html('<a href="<?php echo JBROWSE_RELATIVE_PATH?>index.html?data=data%2FuserData%2F<?php echo $NameFolder?>&loc=' + chr + '%3A'+ start + '..' + end + '&tracks=DNA%2CTranscript%2Cdata1.bam" target="_blank">' + oData.JBrowser + '</a>');
                 }

              }
          ],
          "order": [[0, 'asc']]
         } );
      } );

    

   </script>

  </body>
</html>
