<!DOCTYPE html>
<html>
  <head lang="en">
  <meta charset="UTF-8">
  <script language="JavaScript">
    function converter() {
        document.getElementById('RNA').innerHTML = document.getElementById("cDNA").value;
        
    }
  </script>

  </head>
  <body>

    <form>
      <label><b>Enter a cDNA sequence:</b></label><br>
      <textarea id=cDNA name=cDNA rows=10 cols=60 class=mono></textarea>
    </form>

    <input type="cDNAtoRNA" onclick="converter();"><br/>

    <label>Your input: </label>
    <p><textarea id=RNA name=RNA rows=10 cols=60 class=mono></textarea></p>

  </body>
</html>
