#! /usr/bin/perl -w
use strict;


my $offtarget_pfs_length=shift;

my $seed_length=shift;

my $num_MisID=shift;
my $num_Gap=shift;  ###Adddd

my $file=shift;
my $out_dir=shift;

open(IN,"<$file") or die "Can't open file: $file\n";

my $out=$out_dir."filter_seed.sam";
open(OUT,">$out");


while (my $line=<IN>)  
{

    chomp($line);
    $line =~ s/\r$//;
    if($line =~ /^@/){
        print OUT "$line\n";
    }else{
        my @array_line=split(/\t/,$line);
        my $read=$array_line[9];
        my @array_read=split(//,$read);
        my $string=$array_line[5];
        my $md=$array_line[$#array_line-1];
        my @mdz=split(/:/,$md);
        $mdz[2] =~ s/\^//g;  #store md tag

        my $new_cigar='';
        my @array=split(//,$string);

#######rebuild read##############
        for (my $i=0;$i<=$#array;$i++){
          if ($array[$i]=~/\d/){
             $new_cigar=$new_cigar.$array[$i];
          }
          if ($array[$i]=~/[A-Z]/){
             $new_cigar=$new_cigar.$array[$i].";";
          }

        }
#print "$new_cigar\n";
        my $rebuild_read='';
        my $k=0;
        my @cigar=split(/;/,$new_cigar);
        for (my $i=0;$i<=$#cigar;$i++){
        #print $cigar[$i]."\n";
           if ($cigar[$i]=~/(\d+)([A-Z])/){

             if ($2 ne 'D'){
               for(my $pos=$k;$pos<$k+$1;$pos++){
                 $rebuild_read=$rebuild_read.$array_read[$pos];
               }
               $k=$k+$1;
             }else{
               for (my $j=0;$j<$1;$j++){
                  $rebuild_read=$rebuild_read."-";
               }
             }

           }

        }
# print "$rebuild_read\n";

###########################################

#######rebuild reference string##########
        my $reference='';
        my @md_string=split(//,$mdz[2]);
        for (my $i=0;$i<=$#md_string;$i++){
          if ($md_string[$i] =~ /[0-9]/){
            if($i+1<=$#md_string){
               if ($md_string[$i+1] =~ /[0-9]/){
                  my $digit=$md_string[$i].$md_string[$i+1];
              #print $digit."\n";
                  for (my $j=0;$j<$digit;$j++){
                     $reference=$reference."M";
                  }
                  $i=$i+1;
               }else{
                  for (my $j=0;$j<$md_string[$i];$j++){
                     $reference=$reference."M";
                  }
               } 
            }else{
                for (my $j=0;$j<$md_string[$i];$j++){
                    $reference=$reference."M";
                }
            }          
             
          }
          if($md_string[$i] =~ /[A-Z]/){
             $reference=$reference.$md_string[$i];

          }
  
        }
        #print "$reference\n";

        #print "$new_cigar\n";

        my $rebuild_reference='';
        my $h=0;
        my @array_reference=split(//,$reference);
        for (my $i=0;$i<=$#cigar;$i++){
        #print $cigar[$i]."\n";
          if ($cigar[$i]=~/(\d+)([A-Z])/){

             if ($2 ne 'I'){
                for(my $pos=$h;$pos<$h+$1;$pos++){
                    $rebuild_reference=$rebuild_reference.$array_reference[$pos];
                }
                $h=$h+$1;
             }else{
                  for (my $j=0;$j<$1;$j++){
                      $rebuild_reference=$rebuild_reference."-";
                  }
             }

          }

        }
      # print "$rebuild_reference\n";

###########################################
        my @rebuild_reference=split(//,$rebuild_reference);
        my @rebuild_read=split(//,$rebuild_read);
        my $num_match=0;
        my $num_gap=0;#add
        my $gRNA_length=$#rebuild_reference+1-$offtarget_pfs_length;#add
        my $side_length=int(($gRNA_length-$seed_length)/2);
        my $seed_start=$offtarget_pfs_length+$side_length;
        my $seed_end=$seed_start+$seed_length-1;
        for(my $i=$seed_start; $i<=$seed_end; $i++){
             if($rebuild_reference[$i] eq 'M'){
                 $num_match=$num_match+1;
     
             }
             if($rebuild_reference[$i] eq '-'){
                 $num_gap=$num_gap+1;
     
             }
             if($rebuild_read[$i] eq '-'){
                 $num_gap=$num_gap+1;
     
             }
        }
        #print "$num_match $num_Gap\n";
        if ($num_match >= $seed_length-$num_MisID and $num_gap <= $num_Gap){
         
             my @read_array=split(//,$rebuild_read);
             my @reference_array=split(//,$rebuild_reference);
             my @origin_ref;
             for (my $position=0;$position<=$#reference_array;$position++){
                if ($reference_array[$position] eq 'M'){
                    push(@origin_ref,$read_array[$position]);
                }elsif ($reference_array[$position] eq '-'){

                }else{
                     push(@origin_ref,$reference_array[$position]);
                }
             }
             print OUT "$line:";
             print OUT @origin_ref;
             print OUT "\n";
            
         }


    }
    

}

close IN;
close OUT;

