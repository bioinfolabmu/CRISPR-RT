#! /usr/bin/perl -w
my $mode_name=shift; ######################### Modify here ###############
my $offtarget_pam_length=shift;
my $gRNA_length=shift;
my $num_candidate=shift;

my $No_pairs=shift;

my $out_dir=shift;

my $low_offset=shift;

my $high_offset=shift;

my $input_forward=shift;

my $input_reverse=shift;

my @chromosome_array = @ARGV;
=begin
for (my $i=0;$i<=$#chromosome_array;$i++){
    print "pass chr is".$chromosome_array[$i];
    
    print "\n";

}
=cut

for (my $i=0;$i<=$#chromosome_array;$i++){
    my $out_forward=$out_dir.'chr'.$chromosome_array[$i].'_countIDel_forward.sam';
    open($chromosome_array[$i],">$out_forward");
    
}


open(IN_forward,"<$input_forward") or die "Can't open file: $input_forward\n";
while (my $line=<IN_forward>)  
{
        chomp($line);
        $line =~ s/\r$//;
        my @array=split(/\t/,$line);
        if ($array[2] =~ /^(\S+)$/){
             print $1 $line;
             print $1 "\n";
        }
}

close IN_forward;                    #Dont forget close file handlers!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

for (my $i=0;$i<=$#chromosome_array;$i++){  #Dont forget close file handlers!
    close $chromosome_array[$i]; 
}
#########################################
for (my $i=0;$i<=$#chromosome_array;$i++){
    
    my $out_reverse=$out_dir.'chr'.$chromosome_array[$i].'_countIDel_reverse.sam';
    open($chromosome_array[$i],">$out_reverse");
}

open(IN_reverse,"<$input_reverse") or die "Can't open file: $input_reverse\n";
while (my $line=<IN_reverse>)  
{
        chomp($line);
        $line =~ s/\r$//;
        my @array=split(/\t/,$line);
        if ($array[2] =~ /^(\S+)$/){
            print $1 $line;
            print $1 "\n";

        }
}

close IN_reverse;                   #Dont forget close file handlers!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

for (my $i=0;$i<=$#chromosome_array;$i++){  #Dont forget close file handlers!!
    close $chromosome_array[$i]; 
}




for (my $i=0;$i<=$#chromosome_array;$i++){
   for (my $j=1;$j<=$num_candidate;$j++){ 
         my $out_chr_forward=$out_dir.'candidate'.$j.'_chr'.$chromosome_array[$i].'_countIDel_forward.sam';
###################################### Modify here ################################         
        my $fileHandler = $j.'_'.$chromosome_array[$i];
        open($fileHandler,">$out_chr_forward");
        # open($j.$chromosome_array[$i],">$out_chr_forward");
###################################################################################
         #open($j.$chromosome_array[$i],">$out_chr_forward");

   }

}



for (my $i=0;$i<=$#chromosome_array;$i++){
 

       my $input_chr_forward=$out_dir.'chr'.$chromosome_array[$i].'_countIDel_forward.sam';
       open(IN_chr_forward,"<$input_chr_forward") or die "Can't open file: $input_chr_forward\n";
     
       while (my $line=<IN_chr_forward>)  
       {
           chomp($line);
           $line =~ s/\r$//;
           my @array=split(/\t/,$line);
       
           if($array[0] =~ /^Candidate(\d+)_/){
              #   my $file_handler=$1.$chromosome_array[$i];
                 my $file_handler=$1.'_'.$chromosome_array[$i];################### Modify here ###########
                 print $file_handler $line;
                 print $file_handler "\n";

           }
       }
       close IN_chr_forward;     #Dont forget close file handlers!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    
}

for (my $i=0;$i<=$#chromosome_array;$i++){
   for (my $j=1;$j<=$num_candidate;$j++){ 
######################### Modify here ############################
         my $fileHandler = $j.'_'.$chromosome_array[$i];
         close $fileHandler;
         #close $j.$chromosome_array[$i];   #Dont forget close file handlers!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
###################################################################       
         #close $j.$chromosome_array[$i];   #Dont forget close file handlers!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

   }

}

#########################################################

for (my $i=0;$i<=$#chromosome_array;$i++){
   for (my $j=1;$j<=$num_candidate;$j++){ 
         my $out_chr_reverse=$out_dir.'candidate'.$j.'_chr'.$chromosome_array[$i].'_countIDel_reverse.sam';
         #open($j.$chromosome_array[$i],">$out_chr_reverse");
###################################### Modify here ################################         
        my $fileHandler = $j.'_'.$chromosome_array[$i];
        open($fileHandler,">$out_chr_reverse");
        #open($j.$chromosome_array[$i],">$out_chr_reverse");
###################################################################################         
         

   }

}



for (my $i=0;$i<=$#chromosome_array;$i++){

       my $input_chr_reverse=$out_dir.'chr'.$chromosome_array[$i].'_countIDel_reverse.sam';
       open(IN_chr_reverse,"<$input_chr_reverse") or die "Can't open file: $input_chr_reverse\n";
      
       while (my $line=<IN_chr_reverse>)  
       {
           chomp($line);
           $line =~ s/\r$//;
           my @array=split(/\t/,$line);

           if($array[0] =~ /^Candidate(\d+)_/){
                 #my $file_handler=$1.$chromosome_array[$i];
                 my $file_handler=$1.'_'.$chromosome_array[$i]; ################ Modify here #########
                 print $file_handler $line;
                 print $file_handler "\n";

           }
       }
       
       close IN_chr_reverse;   #Dont forget close file handlers!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


}

for (my $i=0;$i<=$#chromosome_array;$i++){
   for (my $j=1;$j<=$num_candidate;$j++){ 
######################### Modify here ############################
         my $fileHandler = $j.'_'.$chromosome_array[$i];
         close $fileHandler;
         #close $j.$chromosome_array[$i];   #Dont forget close file handlers!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
###################################################################
       
         #close $j.$chromosome_array[$i];   #Dont forget close file handlers!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

   }

}









for (my $i=0;$i<=$#chromosome_array;$i++){
   for (my $j=1;$j<=$num_candidate;$j++){ 
        
################################################ Modify here ###################   
     if ($mode_name eq "Cas9n"){
        system('perl Cas9n_filter_position.pl '.$offtarget_pam_length.' '.$No_pairs.' '.$low_offset.' '.$high_offset.' '.$out_dir.'candidate'.$j.'_chr'.$chromosome_array[$i].'_countIDel_forward.sam '.$out_dir.'candidate'.$j.'_chr'.$chromosome_array[$i].'_countIDel_reverse.sam '.$out_dir.' '.$j.' '.$chromosome_array[$i].' '.$gRNA_length);
     }else{
        system('perl filter_position.pl '.$offtarget_pam_length.' '.$No_pairs.' '.$low_offset.' '.$high_offset.' '.$out_dir.'candidate'.$j.'_chr'.$chromosome_array[$i].'_countIDel_forward.sam '.$out_dir.'candidate'.$j.'_chr'.$chromosome_array[$i].'_countIDel_reverse.sam '.$out_dir.' '.$j.' '.$chromosome_array[$i].' '.$gRNA_length);

     }
####################################################################################

        #system('perl filter_position.pl '.$offtarget_pam_length.' '.$No_pairs.' '.$low_offset.' '.$high_offset.' '.$out_dir.'candidate'.$j.'_chr'.$chromosome_array[$i].'_countIDel_forward.sam '.$out_dir.'candidate'.$j.'_chr'.$chromosome_array[$i].'_countIDel_reverse.sam '.$out_dir.' '.$j.' '.$chromosome_array[$i].' '.$gRNA_length);
   }
}


=begin
my $string='';

for (my $i=0;$i<=$#chromosome_array;$i++){
  for (my $j=1;$j<=$num_candidate;$j++){ 
    $string=$string.$out_dir.'candidate'.$j.'_chr'.$chromosome_array[$i].'_filter_position.sam ';
  }
}

system('cat '.$string.' > '.$out_dir.'filter_position.sam');


=cut


















