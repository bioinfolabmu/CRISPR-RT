#! /usr/bin/perl -w
use strict;
my $num_Gap=shift; #ADD
my $offtarget_pfs_length=shift;
my $Offtargets_transcriptome_file=shift;
my $dir=shift;
my $output=$dir."filter_pfs_gap.sam";
open(IN_forward,"<$Offtargets_transcriptome_file") or die "Can't open file: $Offtargets_transcriptome_file\n";
open(OUT,">$output");

while (my $line=<IN_forward>)  
{
  chomp($line);
  $line =~ s/\r$//;
  if($line =~ /^@/){
    print OUT "$line\n";
  }else{
    my @array=split(/\t/,$line);
    for(my $i = 0; $i<=$#array; $i++){
      if($array[$i] =~ /^XG:i:(\d+)$/ and $1 <= $num_Gap){
           
             #if ($array[5] =~ /^(\d+)M/ and $1>=$offtarget_pfs_length){   #just here
             if ($array[5] =~ /(\d+)M$/ and $1>=$offtarget_pfs_length){
                for(my $j = 0; $j<=$#array; $j++){
                  if($array[$j] =~ /^MD:Z/){ 
                         my @md=split(/:/,$array[$j]);
                         #if($md[2] =~ /^(\d+)/ and $1 >= $offtarget_pfs_length){ #just here
                         if($md[2] =~ /(\d+)$/ and $1 >= $offtarget_pfs_length){
                             #print OUT "Forward	$line\n";
                             print OUT "$line\n";
                         }
                   }
                } 
    
             }
       }   
     }
  }
    
}

close IN_forward;
close OUT;
