#! usr/bin/perl -w
use strict;


my $output="Candidates_Offtargets_DataTable.txt";
open(OUT,">$output");

my $candidates_file="Candidates_Offtargets.txt";
open(IN,"<$candidates_file") or die "Can't open file: $candidates_file\n";

print OUT "{\"data\":["; 


while(my $line=<IN>){
    chomp($line);
    $line =~ s/\r$//;
    my @array=split(/\t/,$line);
    if ($array[0]=~/^\d/){
         
         print OUT "{";

         print OUT "\"No\":";
         print OUT "\"";
         print OUT $array[0];
         print OUT "\"";
         print OUT ",";

         print OUT "\"gRNAa\":";
         print OUT "\"";
         print OUT $array[1];
         print OUT "\"";
         print OUT ",";

         print OUT "\"gRNAa_GC\":";
         print OUT "\"";
         print OUT $array[2];
         print OUT "\"";
         print OUT ",";

         print OUT "\"gRNAa_strand\":";
         print OUT "\"";
         print OUT $array[3];
         print OUT "\"";
         print OUT ",";

         print OUT "\"gRNAa_start\":";
         print OUT "\"";
         print OUT $array[4];
         print OUT "\"";
         print OUT ",";

         print OUT "\"gRNAa_end\":";
         print OUT "\"";
         print OUT $array[5];
         print OUT "\"";
         print OUT ",";

         print OUT "\"gRNAb\":";
         print OUT "\"";
         print OUT $array[6];
         print OUT "\"";
         print OUT ",";

         print OUT "\"gRNAb_GC\":";
         print OUT "\"";
         print OUT $array[7];
         print OUT "\"";
         print OUT ",";

         print OUT "\"gRNAb_strand\":";
         print OUT "\"";
         print OUT $array[8];
         print OUT "\"";
         print OUT ",";

         print OUT "\"gRNAb_start\":";
         print OUT "\"";
         print OUT $array[9];
         print OUT "\"";
         print OUT ",";

         print OUT "\"gRNAb_end\":";
         print OUT "\"";
         print OUT $array[10];
         print OUT "\"";
         print OUT ",";

         print OUT "\"num_targets\":";
         print OUT "\"";
         print OUT $array[11];
         print OUT "\"";
           
         print OUT "}";

         if (!eof) {  # check for end of last file
            print OUT ",";
         }
                                                     
     }

}

print OUT "]}";

close OUT;
close IN;
