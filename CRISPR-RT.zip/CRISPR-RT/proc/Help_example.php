<?php
include_once '../root_path.php';
define('ROOT_PATH','..');
$job = "C2c2_TAIR10.33_122616_152210_18"; 

//$job = preg_replace('/\s+/', '', $job); //delete all white space of string

//$mode_name = ; 
/*   Comment out this block
$userseq = $_POST['userseq']; 
$gene_location = $_POST['gene_location']; 

//if ($mode_name == "Cas9n" or "RFNs"){
    $min_offset = $_POST['min_offset']; 
    $max_offset = $_POST['max_offset']; 
//}

$target_pam = $_POST['target_pam']; 
$target_pam = strtoupper($target_pam);
$offtarget_pam = $_POST['offtarget_pam']; 
$offtarget_pam = strtoupper($offtarget_pam);
$num_MisAndGap = $_POST['num_MisAndGap'];
$gRNA_length = $_POST['gRNA_length']; 
$seed_length = $_POST['seed_length']; 
$num_seed_MisID = $_POST['num_seed_MisID']; 

//if ($mode_name == "Cas9n" or "RFNs"){
    $num_BulgeStrand = $_POST['num_BulgeStrand']; 
//}

$db = $_POST['db']; 
$radio = $_POST['seed_setting']; 
$seed_mismatch = $_POST['seed_mismatch']; 
$seed_insertion = $_POST['seed_insertion']; 
$seed_deletion = $_POST['seed_deletion']; 
$nonseed_mismatch = $_POST['nonseed_mismatch']; 
$nonseed_insertion = $_POST['nonseed_insertion']; 
$nonseed_deletion = $_POST['nonseed_deletion']; 
*/
//$jbowse_data_path = JBROWSE_DATA_PATH;

$nameOfFolder = $job;
/*   commment out this block
$nameOfFolder=$mode_name."_".date("mdy_His"); #the name of user upload foler
########make new directory permission seeting!!!very important!!!!!!!!!!!!!!!!!!!!!!!!! 
$oldmask = umask(0); 
#mkdir("uploads/".$nameOfFolder,0777, true); #create user upload folder under uploads/,0777 means all=rwx, true is recursive
mkdir(JBROWSE_USERDATA_PATH.$nameOfFolder,0777, true);
umask($oldmask);
#########
*/
#$uploaddir = "uploads/".$nameOfFolder."/"; #get the relative path of the upload folder
$uploaddir =JBROWSE_DATA_PATH.$nameOfFolder."/";

$retrive_job_file = $uploaddir."retrive_job.txt";
$myfile = fopen($retrive_job_file, "r") or die("Unable to open file!");
$PFS_DB = fgets($myfile);
fclose($myfile);

$PFS_DB = str_replace("\n", "", $PFS_DB);
$PFS_DB = str_replace("\r", "", $PFS_DB);

$PFS_DB_array = explode("\t", $PFS_DB);
$target_pfs_length = $PFS_DB_array[0];
$db = $PFS_DB_array[1];

$uploaddir_relative = JBROWSE_DATA_RELATIVE_PATH.$nameOfFolder."/";
 
$folder_exit = file_exists ( $uploaddir_relative );


session_start();
$_SESSION["a"] = $uploaddir;

/* comment out this block
$filename='';
if ($_FILES['userfile']['name'] != ''){
   $uploadfile = $uploaddir . basename($_FILES['userfile']['name']); 
  // echo "$uploaddir";
   //echo "<pre>";
  // echo $_FILES['userfile']['name'];
  // echo "<pre>";
   if (move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile)) {
     //  echo "File is valid, and was successfully uploaded.\n";
   } else {
     //  echo "Possible file upload attack!\n";
   }
   $filename=$_FILES['userfile']['name'];
}elseif($gene_location != ''){
   $array = explode(':', $gene_location);
   $chr=$array[0];
   $location=$array[1];
   $start_end = explode('-', $location);
   $start_pos = $start_end[0];
   $end_pos = $start_end[1];
  // $output_seq = shell_exec('get-genome -d '.$chr.' '.$start_pos.'..'.$end_pos);
 
   $uploadfile = $uploaddir."retrieve_seq.fa"; 
 
   file_put_contents ( $uploadfile , $output_seq );
   $filename="retrieve_seq.fa";

}elseif($userseq != ''){
   $uploadfile = $uploaddir."userseq.fa"; 
  // echo "$uploadfile";
  // echo "<pre>";
   file_put_contents ( $uploadfile , $userseq );
   $filename="userseq.fa";
}

system("perl query_seq.pl $uploaddir $filename");#################invoke perl to generate query sequence;



//echo "perl main.pl $mode_name $radio $jbowse_data_path $min_offset $max_offset $uploaddir $filename $target_pam $offtarget_pam $db $num_MisAndGap $seed_length $num_seed_MisID $num_BulgeStrand $gRNA_length $seed_mismatch $seed_insertion $seed_deletion $nonseed_mismatch $nonseed_insertion $nonseed_deletion";  
system("perl main.pl $mode_name $radio $jbowse_data_path $min_offset $max_offset $uploaddir $filename $target_pam $offtarget_pam $db $num_MisAndGap $seed_length $num_seed_MisID $num_BulgeStrand $gRNA_length $seed_mismatch $seed_insertion $seed_deletion $nonseed_mismatch $nonseed_insertion $nonseed_deletion");#invoke perl  
   
       

*/

//$resultpath=$uploaddir."Candidates_Offtargets.txt";
//$lines = count(file($resultpath)) - 1;
#echo "$lines";
#echo "<pre>";
//$Output1=fopen( $resultpath, "r" );#open output file and display
//if( $Output1 == false )
//{
//   echo "Error in opening result file";
//   exit();
//}
//$result_filesize = filesize( $resultpath );
//$result_filetext = fread( $Output1, $result_filesize );

//fclose( $Output1 );
//echo "$result_filetext";

//echo "<pre>";

//for ($i=1; $i<=$lines; $i++){
//    echo 'Candidate_'.$i.'_Target&Offtarget_sites<br>';
//    $offtarget_path=$uploaddir.'Candidate'.$i.'_offtarget.sam';
//    $Output2=fopen( $offtarget_path, "r" );#open output file and display
//    if( $Output2 == false )
 //   {
//       echo "Error in opening result file";
//       exit();
//    }
//    $offtarget_filesize = filesize( $offtarget_path );
//    $offtarget_filetext = fread( $Output2, $offtarget_filesize );

//    fclose( $Output2 );
//    echo "$offtarget_filetext";
//    echo "<pre>";
//}

?>





<html>
  <head>
    <link href="<?php echo ROOT_PATH.'/layout/css/help.css'?>" rel="stylesheet" type="text/css">
    <link href="./tableview/layout.css" rel="stylesheet" type="text/css" /> 
    <!--<link href="https://cdn.datatables.net/1.10.8/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css" />-->
    <!--<link href="https://cdn.datatables.net/1.10.7/css/jquery.dataTables.css" rel="stylesheet" type="text/css" />-->
    <link href="https://code.jquery.com/ui/1.11.3/themes/smoothness/jquery-ui.css" rel="stylesheet" type="text/css" />	
   <link href="https://cdn.datatables.net/1.10.8/css/dataTables.jqueryui.min.css" rel="stylesheet" type="text/css" />
    <script src="https://code.jquery.com/jquery-1.11.3.min.js" type="text/javascript"></script>
    <script src="https://cdn.datatables.net/1.10.8/js/jquery.dataTables.min.js" type="text/javascript"></script>
    <script src="https://cdn.datatables.net/1.10.8/js/dataTables.jqueryui.min.js" type="text/javascript"></script>

    <script src="https://cdn.datatables.net/plug-ins/1.10.9/sorting/natural.js" type="text/javascript"></script>

  </head>
  <body>
    <a href="./seqview/seqview.php?directory=<?php echo $uploaddir ?>" target="_blank"><button>Input Sequence Viewer</button></a>

    &nbsp&nbsp&nbsp&nbspJob ID: <?php echo $nameOfFolder;?>
    <span class=helper title="
      You can retrieve your recent job data by entering the Job ID in the &quot;Retrieve Jobs&quot; tab of the left side menu. Results will be kept for 7 days after your initial submission.
    ">?</span>

  <a href="<?php echo $uploaddir_relative ?>Candidates_Offtargets.txt" download="Candidate_Targets.txt" style="float:right">Download</a>


    <br>
    </br>
          
    <div id='target'> 	    	    
    </div>


    <br>
    </br>
    
    <div id='content'> 	    	    
    </div>
    
   
  <script type="text/javascript">


var folder_exit = "<?php echo $folder_exit;?>";

var job = "<?php echo $job;?>";

var patt = new RegExp("C2c2_");


if (folder_exit){

    if (patt.test(job)){
       $('#target').html('<table id="example" class="display" width="100%" cellspacing="0" style="font-family: monospace;">'+
        '<thead>'+
            '<tr>'+                
                '<th data-toggle="tooltip" title="  Number">No</th>'+
                '<th data-toggle="tooltip" title="  The target candidate sequence including the protospacer sequence and PFS.\x0A  Direction is from 5' +'\''+ ' to 3' +'\''+ '.">Protospacer+PFS</th>'+
                '<th data-toggle="tooltip" title="  The start position of the target candidate sequence in the user input RNA sequence.">Start</th>'+
                '<th data-toggle="tooltip" title="  The end position of the target candidate sequence in the user input RNA sequence.">End</th>'+
                '<th data-toggle="tooltip" title="  The GC content of the target candidate sequence excluding PFS.">GC</th>'+
                '<th data-toggle="tooltip" title="  The number of target sites in the whole transcriptome for the target candidate.">#Targets</th>'+
            '</tr>'+
        '</thead>'+
 
        
  '</table>');  
/*
/////////////////////////function format() --- child/////////////////////

  function C2c2_format ( d, column) {
    // `d` is the original data object for the row
    if (column == 5){ 
      var child_dir = "<?php echo $uploaddir_relative;?>";
      var child_file = child_dir + "Candidate" + d.No + "_offtargets_DataTable.txt";

      $('#content').html('<table id="child" class="display" width="100%" cellspacing="0" style="font-family: monospace;">'+
                       '<thead>'+
                          '<tr>'+
                          //  '<th></th>'+
                            '<th data-toggle="tooltip" title="  Identification Number">ID</th>'+
                            '<th data-toggle="tooltip" title="  Nucleotide sequence of potential target site including PAM sequence. Reverse-complemented if aligned to the reverse strand. ">Seq</th>'+
                            '<th data-toggle="tooltip" title="  Chromosome number of potential target site">Chr</th>'+
                            '<th data-toggle="tooltip" title="  Position of potential target site in the chromosome">Pos</th>'+
                            '<th data-toggle="tooltip" title="  Strand of potential target site.\x0A  + is forward strand.\x0A  - is the reverse strand.">Str</th>'+
                            '<th data-toggle="tooltip" title="  The total number of mismatches and gaps between potential target site (except PAM sequence) and gRNA">M&G</th>'+
                            '<th data-toggle="tooltip" title="  The number of mismatches between potential target site (except PAM sequence) and gRNA">M</th>'+
                            '<th data-toggle="tooltip" title="  The number of gaps between potential target site (except PAM sequence) and gRNA">G</th>'+                            
                            '<th data-toggle="tooltip" title="  View potential target site sequence by JBrowse">JB</th>'+
                          '</tr>'+
                       '</thead>'+
            '</table>');
  
	  


		 
      // `d` is the original data object for the row
      $(document).ready(function() {               
         var childtable = $('#child').DataTable( {
          "lengthMenu": [ [5, 10, 25, -1], [5, 10, 25, "All"] ],
          "language": {
            "lengthMenu": "Target Sites _MENU_ per page <span class=helper title=\"    The target sites include on-target and off-target sites in the whole genome.\x0A    Click JB to see visualization of target sites by JBrowser.\x0A    Sort each column by clicking the column header\">?</span>"
            
          },
          "ajax": child_file,
          columnDefs: [
             { type: 'natural', targets: 2 }
          ],
          "columns": [
            
              { "data": "ID" },
              { "data": "Sequence" },
              { "data": "Chromosome" },
              { "data": "Position" },
              { "data": "Strand" },
              { "data": "Mis&Gap" },
              { "data": "Mis" },
              { "data": "Gap" },            
              { "data": "JBrowser", 
                "fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
                    var chr=oData.Chromosome;
                    var start=oData.Position;
                    var end= Number(oData.Position)+55;
                    $(nTd).html('<a href="<?php echo JBROWSE_RELATIVE_PATH?>?data=data%2FuserData%2F<?php echo $nameOfFolder?>&loc=' + chr + '%3A'+ start + '..' + end + '" target="_blank">' + oData.JBrowser + '</a>');
                 }

              }
          ],
          "order": [[0, 'asc']]
         } );
      } );

    }
  }

*/
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

  var dir = "<?php echo $uploaddir_relative;?>";
  var file = dir + "Candidates_Offtargets_DataTable.txt";


  $(document).ready(function() {
    
    var table = $('#example').DataTable( {
        
        "aoColumnDefs": [
                {
                    "aTargets": [5], // the column with num_targets
                    "fnCreatedCell": function(nTd, sData, oData, iRow, iCol)
                    {

                        //$(nTd).html('<a href="#">' + sData + '</a>');
                        var Candidate_ID=oData.No;
                        var uploaddir_relative="<?php echo $uploaddir_relative;?>";
                        var nameOfFolder="<?php echo $nameOfFolder;?>";
                        var upload_dir="<?php echo $uploaddir;?>";
                        var db="<?php echo $db;?>";
                        $(nTd).html("<a style='color:blue' href='Help_example_target_sites.php?Candidate_ID="+Candidate_ID+"&uploaddir_relative="+uploaddir_relative+"&nameOfFolder="+nameOfFolder+"&upload_dir="+upload_dir+"&db="+db+"' target='_blank'>"+oData.num_targets+"</a>"); 
                       
                        if(sData == 1)
                        {
                            $(nTd).css('background-color', '#DFF2BF'); // You can use hex code as well
                        }
                        
                        

 
                    },                   
                },
                

                {
                    "aTargets": [1], // The column with the Protospacer+PFS
                    "fnCreatedCell": function(nTd, sData, oData, iRow, iCol)
                    {
                            
                            var seq=oData.gRNA;
                            var res = seq.split(""); 
                            var index;
                            var gRNA='';
                            var PFS='';
                            
                            for	(index = 0; index < res.length-<?php echo $target_pfs_length ?>; index++) {
                              gRNA += res[index];
                            } 
                            for (index = res.length-<?php echo $target_pfs_length ?>; index < res.length; index++) {                             PFS += res[index];
                            } 
                           // $(nTd).html("<p>"+gRNA+"<span style='color:blue'>"+PFS+"</span></p>"); 
                        
                            //$(nTd).html("<p>"+"<span style='color:purple'>"+gRNA+"</span>"+"<span style='color:red'>"+PFS+"</span>"+"   ["+"<a style='color:blue' href='crRNA_design.php' target='_blank'>"+"crRNA"+"</a>"+"]"+"</p>"); 
                           $(nTd).html("<p>"+"<span style='background-color: #ccffff'>"+gRNA+"</span>"+"<span style='color:#fe7032'><b>"+PFS+"</b></span>"+"   <font color='#3399ff'>[</font>"+"<a style='color:#3399ff' href='crRNA_design.php?seq="+seq+"&gRNA="+gRNA+"&PFS="+PFS+"' target='_blank'>"+"crRNA"+"</a>"+"<font color='#3399ff'>]</font>"+"</p>"); 
                           

 
                    },                   
                },

               
                { "aDataSort": [ 4, 5 ], "aTargets": [ 4 ] },
                { "aDataSort": [ 5, 4 ], "aTargets": [ 5 ] }


       ],

        "lengthMenu": [ [10, 25, 50, -1], [10, 25, 50, "All"] ],
        "language": {
            "lengthMenu": "Candidate Targets _MENU_ per page <span class=helper title=\"    The Candidate Targets of user input sequence are all the possible sites that gRNAs can target.\x0A    Click the specific target value to view potential target sites in the whole genome for each canditate target.\x0A    Sort each column by clicking the column header\">?</span>"
            
        },

        "ajax": file,
        "columns": [
        
            { "data": "No" },
            { "data": "gRNA" },
            { "data": "gRNA_start" },
            { "data": "gRNA_end" },
            { "data": "GC" },
            { "data": "num_targets"},
            
        ],
        "order": [[0, 'asc']]
    } );
     
    
      $('#example tbody').on('click', 'td', function () {
       // var tr = $(this).closest('tr');
      //  var row = table.row( tr );
       // var columnID = table.cell(this).index().column;
        var rowId = table.cell(this).index().row;
        var row = table.row( rowId );

        var column_ID = table.cell(this).index().column;

        


 
        if ( row.child.isShown() ) {
            // This row is already open - close it
            row.child.hide();
     //       tr.removeClass('shown');
        }
        else {
            
          
        }
      } );
  } );

 }



  

} else {
   $('#target').html('Please input a correct Job ID!'+
                       '<button onclick="goBack()">Go Back</button>'); 
 
}

function goBack() {
    window.history.back();
}
  </script>
 
</body>
</html>
