#! /usr/bin/perl -w
use strict;

my %IUB=(                     #IUB code for target
           'G'=>'G',
           'A'=>'A',
           'U'=>'U',
           'C'=>'C',
           'R'=>'[AG]',
           'Y'=>'[CU]',
           'M'=>'[AC]',
           'K'=>'[GU]',
           'S'=>'[CG]',
           'W'=>'[AU]',
           'H'=>'[ACU]',
           'B'=>'[CGU]',
           'V'=>'[ACG]',
           'D'=>'[AGU]',
           'N'=>'[ACGU]',
 
        );

my %IUB_off=(                     #IUB code for off target
           'G'=>'G',
           'A'=>'A',
           'U'=>'U',
           'C'=>'C',
           'R'=>'AG',
           'Y'=>'CU',
           'M'=>'AC',
           'K'=>'GU',
           'S'=>'CG',
           'W'=>'AU',
           'H'=>'ACU',
           'B'=>'CGU',
           'V'=>'ACG',
           'D'=>'AGU',
           'N'=>'ACGU',
 
        );


my %IUB_com=(                 #IUB complementary
           'G'=>'C',
           'A'=>'T',
           'U'=>'A',
           'C'=>'G',
           'R'=>'TC',
           'Y'=>'GA',
           'M'=>'TG',
           'K'=>'CA',
           'S'=>'GC',
           'W'=>'TA',
           'H'=>'TAG',
           'B'=>'GCA',
           'V'=>'TGC',
           'D'=>'TAC',
           'N'=>'ACGT'   
        );



my $gRNAlength=shift;
my $MinSpacer=shift;
my $MaxSpacer=shift;

my $dlen=2*$gRNAlength;

my $filedir=shift;
my $filename=shift;
my $file=$filedir.$filename;

#print "please input target PAM sequence: \n";
my $targetPAM=shift;
my $targetPAM_length=length($targetPAM);
#print "please input off-target PAM sequence:\n";
my $offPAM=shift;
my $offPAM_length=length($offPAM);

my $pam1_com=reverse $targetPAM; #e.g. GGN
my @array_pam1=split(//,$pam1_com);
my $pam1='';
for (my $i=0;$i<=$#array_pam1;$i++){     #get pam1 CCN
    $pam1=$pam1.$IUB_com{$array_pam1[$i]};

}

#print "pam1:$pam1\n";
my @array_pam2=split(//,$targetPAM);
my $pam2='';
for (my $i=0;$i<=$#array_pam2;$i++){    #get pam2 NGG
    $pam2=$pam2.$IUB{$array_pam2[$i]};

}
#print "pam2:$pam2\n";

open(INPUT,"<$file") or die "Cant't open file: $file\n";
my $seq='';
while (my $line=<INPUT>)
{
    chomp($line);
    $line =~ s/\r$//;
    if($line=~/>/){
    }else{
        $line=uc $line; ##################ADD HERE
        $seq=$seq.$line;
    }

}
close INPUT;
#print "$seq\n";
my $seq_len = length($seq); #add here

my @array=split(//,$seq);
my $count=0;

my $output=$filedir."Target_Candidates.txt";
open (OUT,">$output");
#select OUT;
print OUT "No	gRNAa	gRNAa_strand	gRNAa_start	gRNAa_end	gRNAb	gRNAb_strand	gRNAb_start	gRNAb_end\n";
#for (my $i=0;$i<=$#array-$dlen-$MinSpacer-2-3;$i++) #when spacer length is 14bp, 20+20+14+2(CN)+3(NGG)=59
for (my $i=0;$i<=$#array-$dlen-$MinSpacer-$targetPAM_length-$targetPAM_length+1;$i++) #when spacer length is 14bp, 20+20+14+2(CN)+3(NGG)=59
{
 #   my $seq_pam1 = $array[$i].$array[$i+1].$array[$i+2];
    my $seq_pam1 = '';
    for (my $num=$i;$num<=$i+$targetPAM_length-1;$num++){
        $seq_pam1=$seq_pam1.$array[$num];
    }
    if ($seq_pam1 =~ /^$pam1$/){
        
     #   for(my $j=$i+2+$dlen+$MinSpacer+2;$j<=$i+2+$dlen+$MaxSpacer+2;$j++){
         for(my $j=$i+$targetPAM_length-1+$dlen+$MinSpacer+2;$j<=$i+$targetPAM_length-1+$dlen+$MaxSpacer+2;$j++){
          #if(3-1+$gRNAlength<=$j+1 and $j+1<=$#array){
          if($targetPAM_length-1+$gRNAlength<=$j+$targetPAM_length-2 and $j+$targetPAM_length-2<=$#array){         
            #my $seq_pam2=$array[$j-1].$array[$j].$array[$j+1];
            my $seq_pam2='';
            for (my $nu=$j-1;$nu<=$j+$targetPAM_length-2;$nu++){
               $seq_pam2=$seq_pam2.$array[$nu];
            }
            if($seq_pam2 =~ /^$pam2$/ ){
                $count++;
                print OUT "$count\t";
                my $gRNAa_rev='';
                #for(my $p=$i;$p<$i+3+$gRNAlength;$p++){
                for(my $p=$i;$p<$i+$targetPAM_length+$gRNAlength;$p++){
                    $gRNAa_rev=$gRNAa_rev.$array[$p];
                }
                my $gRNAa_com=reverse $gRNAa_rev;
                my @com_array=split(//,$gRNAa_com);
                my $gRNAa='';
                for (my $i=0;$i<=$#com_array;$i++){
                    $gRNAa=$gRNAa.$IUB_com{$com_array[$i]};
                }
                my $gRNAa_end=$seq_len-$i-1+1;
                #my $gRNAa_start=$seq_len-$i-3-$gRNAlength+1;
                my $gRNAa_start=$seq_len-$i-$targetPAM_length-$gRNAlength+1;
                print OUT "$gRNAa\t-\t$gRNAa_start\t$gRNAa_end\t";
                #print OUT "\t";
                my $gRNAb='';
                #for(my $q=$j-1-$gRNAlength;$q<=$j+1;$q++){
                for(my $q=$j-1-$gRNAlength;$q<=$j+$targetPAM_length-2;$q++){
                    $gRNAb=$gRNAb.$array[$q];
                }
                my $gRNAb_start=$j-$gRNAlength;
                #my $gRNAb_end=$j+2;
                my $gRNAb_end=$j+$targetPAM_length-2+1;
                print OUT "$gRNAb\t+\t$gRNAb_start\t$gRNAb_end";
                print OUT "\n";   
            }
          }
        }
    }

}

close OUT;

print "$count;";

open(IN,"<$output") or die "Cant't open file: $output\n";
my $RNAa_20n='';
my $RNAb_20n='';
my $offpams='';
my @off_pam=split(//,$offPAM);
#my @chr1=split(//,$IUB_off{$off_pam[0]});
#my @chr2=split(//,$IUB_off{$off_pam[1]});
#my @chr3=split(//,$IUB_off{$off_pam[2]});
my @chr;
for(my $i=0;$i<$offPAM_length;$i++){
    @{$chr[$i]}=split(//,$IUB_off{$off_pam[$i]});
}

#print @chr1,@chr2,@chr3;
#print "\n";
#for (my $i=0;$i<=$#chr1;$i++){
#    for (my $j=0;$j<=$#chr2;$j++){
#        for (my $k=0;$k<=$#chr3;$k++){
#            $offpams=$offpams.$chr1[$i].$chr2[$j].$chr3[$k].";";
#
#        }
#
#    }
#
#}
for (permute(@chr)){
   my $string='';
   for(my $i=0;$i<=$#$_;$i++){
      $string=$string.$$_[$i];
   }
   $offpams=$offpams.$string.";" ;

}
#print $offpams;
#print "\n";

sub permute {
  my $last = pop @_;
  unless (@_) {
    return map [$_], @$last;
  }
  return map { my $left = $_; map [@$left, $_], @$last } permute(@_);
}

my @offpams=split(/;/,$offpams);
my $num=1;
my $num_pairs=0;
my $filename=$filedir."Candidates_Search.fa";
open (OUTPUT,">$filename");
while (my $line=<IN>)
{
    chomp($line);
    $line =~ s/\r$//;
    if ($line=~/^\d/){
      # my $filename=$filedir."Target_Candidate_".$num.".fa";
      
       my @RNAs_array=split(/\t/,$line);
       my @RNAa=split(//,$RNAs_array[1]);
       my @RNAb=split(//,$RNAs_array[5]);
       #for (my $i=0;$i<=$#RNAa-3;$i++){
       for (my $i=0;$i<=$#RNAa-$targetPAM_length;$i++){
           $RNAa_20n=$RNAa_20n.$RNAa[$i];

       }
       for (my $j=0;$j<=$#RNAb-$targetPAM_length;$j++){
           $RNAb_20n=$RNAb_20n.$RNAb[$j];
       
       }
       my $pair_num=1;
       for(my $i=0;$i<=$#offpams;$i++){
           for(my $j=0;$j<=$#offpams;$j++){
               my $RNAa_23n=$RNAa_20n.$offpams[$i];
               my $RNAb_23n=$RNAb_20n.$offpams[$j];
               print OUTPUT ">Candidate".$num."_pair".$pair_num."_a\n";
               print OUTPUT "$RNAa_23n\n";
               print OUTPUT ">Candidate".$num."_pair".$pair_num."_b\n";
               print OUTPUT "$RNAb_23n\n";
               $pair_num++;

           }

       }
       #print OUTPUT "$RNAa_20n\n";
       #print OUTPUT "$RNAb_20n\n";
       $num_pairs=$pair_num-1;
      


       $RNAa_20n='';
       $RNAb_20n='';
       $num++;
    }
}

print "$num_pairs";

close IN;
close OUTPUT;

