#!/usr/bin/perl -w
use strict;

my $uploaddir=shift;
my $ref_genome=shift;
my $CandidateID=shift;

my $file_name=$uploaddir.'Candidate'.$CandidateID.'_offtarget.sam';
open(IN_file,"<$file_name") or die "Can't open file: $file_name\n";

my $outfile_name=$uploaddir.'jbrowse.sam';
open(OUT_file, ">", $outfile_name);


while(my $line=<IN_file>){
    chomp($line);
    $line =~ s/\r$//;
    if($line =~ /^@/){
        
    }else{
      my $new_line='';
      my @array=split(/\t/,$line);

      my $YT_index;
    
      for(my $i = 0; $i<=$#array; $i++){
          if($array[$i] =~ /^YT:Z/){
             $YT_index=$i;
          }

      }
      $array[$YT_index] = "YT:Z:UU";

      for (my $i=0;$i<=$#array;$i++){
          $new_line=$new_line.$array[$i]."\t";
        
      }
      $new_line=~s/\t$//;
      print OUT_file $new_line;
      print OUT_file "\n";
    }

}

close IN_file;
close OUT_file;


system('samtools view -bT ../bowtie2db/'.$ref_genome.'/'.$ref_genome.'.fa '.$uploaddir.'jbrowse.sam > '.$uploaddir.'jbrowse.bam');
system('samtools sort '.$uploaddir.'jbrowse.bam '.$uploaddir.'jbrowse_sorted');
system('samtools index '.$uploaddir.'jbrowse_sorted.bam');
